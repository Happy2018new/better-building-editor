import mod.client.extraClientApi as scaffold_client_api
info = scaffold_client_api.GetEngineCompFactory().CreateBlockInfo(scaffold_client_api.GetLevelId())
textures = {}
atlas = {}
if hasattr(info, 'GetBlockTextures'):
    for name in ('minecraft:water', 'minecraft:flowing_water', 'minecraft:lava'):
        textures[name] = info.GetBlockTextures(name, 6)
if hasattr(info, 'GetTextureAtlasUV'):
    for name in ('still_water_grey', 'flowing_water_grey', 'water', 'water_still', 'water_flow'):
        atlas[name] = info.GetTextureAtlasUV(name)
_result = {'textures_available': hasattr(info, 'GetBlockTextures'),
           'atlas_available': hasattr(info, 'GetTextureAtlasUV'),
           'textures': textures, 'atlas': atlas,
           'runtime': scaffold_client_api.GetMinecraftVersion(),
           'scope': 'Initial loaded block names and atlas bounds, not active shader identity'}
