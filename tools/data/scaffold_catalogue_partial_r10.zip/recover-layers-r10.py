import sys
import mod.server.extraServerApi as scaffold_api
marker = '_scaffold_support_catalogue_r8'
state = getattr(sys, marker)
assert state['active'] is False
block = scaffold_api.GetEngineCompFactory().CreateBlock(scaffold_api.GetLevelId())
palette = block.GetBlankBlockPalette()
assert palette is not None
assert palette.DeserializeBlockPalette({
    'volume': (1, 1, 1), 'common': {('minecraft:air', 0): [0]},
    'states': {}, 'extra': {('minecraft:air', 0): [0]}, 'extraStates': {},
    'actor': {}, 'void': False, 'eliminateAir': False})
writes = []
for pos in sorted(state['reserved']):
    writes.append({'pos': pos, 'returned': block.SetBlockByBlockPalette(
        palette, state['dimension'], pos, 0, 0)})
remaining = []
for pos in sorted(state['reserved']):
    value = state['info'].GetBlockNew(pos, state['dimension'])
    liquid = state['info'].GetLiquidBlock(pos, state['dimension'])
    if (value is None or value['name'] != 'minecraft:air' or
            liquid is not None and liquid.get('name') not in ('minecraft:air', None)):
        remaining.append({'pos': pos, 'value': value, 'liquid': liquid})
rules_set = state['game'].SetGameRulesInfoServer(
    {'option_info': {'tile_drops': state['tile_drops']}})
rules = state['game'].GetGameRulesInfoServer()
restored = (not remaining and rules_set and
            rules['option_info']['tile_drops'] == state['tile_drops'])
if restored:
    delattr(sys, marker)
_result = {'restored': bool(restored), 'reserved': len(state['reserved']),
           'remaining': remaining, 'writes': writes, 'rules': rules,
           'range': state['range']}
