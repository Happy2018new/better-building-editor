# Round 10 partial scaffold collection

This archive preserves original observations, not an accepted full catalogue.
Game: NEMC 3.9.0.401155 / runtime 1.21.120.0.
Palette SHA256: 6b2d9e961e934a745f5ab30d697cf22fb463fd3792d371a6dd42cb4342062f01.

- All v1 segments are rejected: a foreground air write retained background
  water, potentially contaminating later batches. Recovery cleared both layers.
- Eighteen v2 segments cover [0, 4608), completed and restored individually.
  These are SDK support/readback observations, not rendering or falling tests.
- The v2 segment [4608, 4864) failed at index 4848. The 09:55:00 engine timer
  traceback reported BlockInfoComponentClient.GetBlockNew missing: a concurrent
  read-only client texture query overwrote the timer's shared global info.
  This segment is rejected in full even though its cleanup succeeded.
- final-recovery-audit-v2.json independently checks all 360 reserved positions:
  foreground air, no liquid, tile drops true and collection marker absent.
  The SDK exposes no flow getter; the segment cleanup receipt records that
  restoring allowed flow returned true in this owned fresh default session.
- probe-source-e2abf6e.zip contains the committed source used for v2 collection;
  its tools/verify_scaffold_support_catalogue.py was normalized to LF before
  native use, SHA256 ed6cfaae7eabdc9db00c88b23556067bbb3932e91ca88addf1fd38eea61516a6.
- loaded-water-textures-r10.json records nominal texture names only; it does
  not establish the actual shader texture source. The associated query caused
  the shared-global collision; its result was read before the failure.

Production support data remains the 14-state sample. The local-closure repair
changes the probe fingerprint. The strict merge tool rejects mixing sources:
resume a full run from zero with the fixed source unless a separate reviewed
compatibility policy is deliberately added. Do not change original reports.

The owned session f777b12fd6bc4f788f97b3c67a6fc00b stopped normally; game PID45212
and MCDK PID46256 were independently absent after stop. No foreground fallback.
