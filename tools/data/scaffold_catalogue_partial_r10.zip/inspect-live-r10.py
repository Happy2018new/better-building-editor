import sys
marker = '_scaffold_support_catalogue_r8'
state = getattr(sys, marker, None)
if state is None:
    _result = {'marker_present': False}
else:
    cells = []
    for pos in sorted(state['reserved']):
        value = state['info'].GetBlockNew(pos, state['dimension'])
        if value is None or value['name'] != 'minecraft:air':
            cells.append({'pos': pos, 'value': value})
    _result = {'marker_present': True, 'active': state['active'],
               'range': state['range'], 'remaining': cells,
               'rules': state['game'].GetGameRulesInfoServer(),
               'original_tile_drops': state['tile_drops']}
