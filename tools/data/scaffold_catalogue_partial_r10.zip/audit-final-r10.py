import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / '.agents/skills/pyreact-debugging/scripts'))
from _session import load_session
from mcdk import Client, return_value

parser = argparse.ArgumentParser()
parser.add_argument('--session', required=True)
parser.add_argument('--owner', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists(), 'Preserve the original audit receipt'
binding = load_session(args.session, args.owner, live=True)
import os
os.environ.update(MCDEV_SESSION_FILE=args.session, MCDEV_OWNER=args.owner,
                  MCDEV_MCP_URL=binding['mcp_url'])
code = '''import sys
import mod.server.extraServerApi as api
factory=api.GetEngineCompFactory()
level=api.GetLevelId()
player=api.GetPlayerList()[0]
dimension=factory.CreateDimension(player).GetEntityDimensionId()
info=factory.CreateBlockInfo(level)
origin=(-181,115,-25)
slots=[(origin[0]+(i%4)*3,origin[1],origin[2]+(i//4)*3) for i in range(8)]
reserved=set((pos[0]+x,pos[1]+y,pos[2]+z) for pos in slots
 for x in (-1,0,1) for y in (-1,0,1,2,3) for z in (-1,0,1))
remaining=[]
for pos in sorted(reserved):
 foreground=info.GetBlockNew(pos,dimension)
 liquid=info.GetLiquidBlock(pos,dimension)
 if (foreground is None or foreground['name']!='minecraft:air' or
     liquid is not None and liquid.get('name') not in ('minecraft:air',None)):
  remaining.append({'pos':pos,'foreground':foreground,'liquid':liquid})
rules=factory.CreateGame(level).GetGameRulesInfoServer()
marker_present=hasattr(sys,'_scaffold_support_catalogue_r8')
_result={'restored':not remaining and not marker_present and rules['option_info']['tile_drops'] is True,
 'dimension':dimension,'origin':origin,'reserved':len(reserved),'remaining':remaining,
 'marker_present':marker_present,'rules':rules,
 'flow_limit':'No SDK getter; final owned collector receipt confirms ForbidLiquidFlow(False) returned true.'}
'''
with Client(timeout=60) as client:
    result = return_value(client.call('execute_code', {
        'code': code, 'is_client': False, 'direct_return': True}))
receipt = {'schema': 1, 'owner': args.owner, 'session_id': binding['id'],
           'game_pid': binding['game_pid'], 'game_identity': binding['game_identity'],
           'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'audit': result}
args.output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(receipt))
raise SystemExit(0 if result['restored'] else 1)
