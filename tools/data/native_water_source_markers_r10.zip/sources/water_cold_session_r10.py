"""Route the one cold marker session without printing its routing secret."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[1]
ROOT = PROJECT.parents[1]
BASE = PROJECT / '.runtime/water-cold-r10b-v3'
OWNER = 'water-r10b-cold-rgb-v3'
INSTANCES = ROOT / '.agents/skills/pyreact-debugging/scripts/instances.py'
OLD = Path('C:/Users/Happy2018new/.pyreact-debug/instances/78a2769a6c8946989c1e42bdac3e66a8/session.json')
WGC = ROOT / '.runtime/worktree-archive-r7/p0-blueprint-qa-r3/files/.runtime/native_wgc/build/Release/native_wgc_capture.exe'
RECEIPT = BASE / 'session-receipt.json'

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('step', choices=('launch', 'calibrate', 'capture', 'stop', 'readback'))
args = parser.parse_args()
if args.step == 'launch':
    assert not RECEIPT.exists()
    old = json.loads(OLD.read_text(encoding='utf8'))
    guard = old['noactivation']
    command = [sys.executable, '-X', 'utf8', str(INSTANCES), 'start', '--project', str(PROJECT),
               '--owner', OWNER, '--name', OWNER, '--preset', 'ui', '--mcdk', guard['mcdk']['path'],
               '--noactivate-dll', guard['dll']['path'], '--noactivate-sha256', guard['dll']['sha256'],
               '--noactivate-mcdk-sha256', guard['mcdk']['sha256'], '--game-exe', old['game_executable'], '--wait', '180']
    launched = subprocess.run(command, capture_output=True, text=True, encoding='utf8', check=False)
    (BASE / 'launch-stdout.txt').write_text(launched.stdout, encoding='utf8')
    (BASE / 'launch-stderr.txt').write_text(launched.stderr, encoding='utf8')
    value = json.loads(launched.stdout)
    safe = {key: value.get(key) for key in ('id', 'session_file', 'owner', 'game_pid', 'game_identity',
                                           'mcdk_pid', 'mcdk_identity', 'ready', 'state', 'error')}
    RECEIPT.write_text(json.dumps(safe, indent=2) + '\n', encoding='ascii')
    print(json.dumps(safe), flush=True)
    raise SystemExit(launched.returncode)
receipt = json.loads(RECEIPT.read_text(encoding='ascii'))
session_file = Path(receipt['session_file'])
session = json.loads(session_file.read_text(encoding='utf8'))
assert session['owner'] == OWNER
if args.step == 'stop':
    result = subprocess.run([sys.executable, '-X', 'utf8', str(INSTANCES), 'stop', '--session', str(session_file),
                             '--owner', OWNER], capture_output=True, text=True, encoding='utf8')
    (BASE / 'stop-stdout.txt').write_text(result.stdout, encoding='utf8')
    (BASE / 'stop-stderr.txt').write_text(result.stderr, encoding='utf8')
    final = json.loads(session_file.read_text(encoding='utf8'))
    print(json.dumps({'returncode': result.returncode, 'state': final['state'], 'ready': final['ready'],
                      'game_pid': final.get('game_pid'), 'mcdk_pid': final.get('mcdk_pid')}))
    raise SystemExit(result.returncode)
env = os.environ.copy()
env.update(MCDEV_SESSION_FILE=str(session_file), MCDEV_OWNER=OWNER, MCDEV_MCP_URL=session['mcp_url'],
           MCDEV_GAME_PID=str(session['game_pid']), MCDEV_NATIVE_CAPTURE_HELPER=str(ROOT / 'tools/capture_native_window.py'),
           MCDEV_NATIVE_CAPTURE_EXE=str(WGC))
artifacts = Path(session['artifacts'])
calibration = artifacts / 'camera-water-cold-r10b-v1.json'
if args.step == 'calibrate':
    command = [sys.executable, '-X', 'utf8', str(PROJECT / '.runtime/calibrate_close_water_camera_r9.py'),
               str(calibration), '--native-resolution', '--skyward-tilted', '--fixture-lift-y', '30']
elif args.step == 'capture':
    value = json.loads(calibration.read_text(encoding='utf8'))
    assert value['completed'] and value['passed'] and value['restored'] and not value['cleanup_errors']
    command = [sys.executable, '-X', 'utf8', str(PROJECT / '.runtime/capture_water_cold_rgb_r10.py'),
               str(artifacts / 'native-water-cold-r10b-v1.json'),
               '--case', 'static_water_uniform_pool_depth_0_foreground_quartz_backdrop_r9',
               '--cell-origin', '6', '96', '6', '--capture-helper', str(PROJECT / 'tools/verify_sign_visuals.py'),
               '--camera-calibration', str(calibration), '--fresh-owned-world', '--close-diagonal']
else:
    command = [sys.executable, '-X', 'utf8', str(INSTANCES), 'exec', '--session', str(session_file), '--owner', OWNER,
               '--', 'mcdk.py', 'exec', str(ROOT / '.runtime/scaffold-r10/loaded-water-textures-r10.py')]
result = subprocess.run(command, env=env, capture_output=True, text=True, encoding='utf8')
(BASE / (args.step + '-stdout.txt')).write_text(result.stdout, encoding='utf8')
(BASE / (args.step + '-stderr.txt')).write_text(result.stderr, encoding='utf8')
print(json.dumps({'step': args.step, 'returncode': result.returncode,
                  'stdout': str(BASE / (args.step + '-stdout.txt')),
                  'stderr': str(BASE / (args.step + '-stderr.txt')),
                  'artifacts': str(artifacts)}), flush=True)
raise SystemExit(result.returncode)
