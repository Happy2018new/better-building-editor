"""One cold RGB-marker depth-zero case around the reviewed four-control harness."""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys

WORKTREE = Path(__file__).resolve().parents[1]
PARENT = WORKTREE.parents[1]
sys.path.insert(0, str(WORKTREE / 'tools'))
sys.path.insert(0, str(WORKTREE / 'behavior_pack/modern_projection'))
import verify_dripstone_direct_seed as direct
import capture_static_water_controls_r9 as base
from measure_native_liquid_side_uv import fingerprint

SHANGHAI = timezone(timedelta(hours=8))
DEADLINE = datetime(2026, 10, 12, 13, 35, tzinfo=SHANGHAI)
ASSET_PLAN = WORKTREE / '.runtime/water-cold-r10b-v3/asset-plan.json'
INSTALLED = ASSET_PLAN.with_name('installed.json')
CASE = 'static_water_uniform_pool_depth_0_foreground_quartz_backdrop_r9'
ORIGINAL_EXECUTE = base.frozen.execute_controls
assert direct.ROOT == WORKTREE


def execute(harness, options, runtime_args, report):
    from _session import load_session
    from _window import background_guard_state
    import verify_wet_actor_visuals as wet
    assert datetime.now(SHANGHAI) < DEADLINE
    assert options.case == [CASE] and options.cell_origin == [6, 96, 6]
    assets = json.loads(ASSET_PLAN.read_text(encoding='ascii'))
    installed = json.loads(INSTALLED.read_text(encoding='ascii'))
    assert installed['completed'] and installed['plan'] == fingerprint(ASSET_PLAN)
    for row in assets['assets']:
        assert fingerprint(row['target'])['sha256'] == row['generated']['sha256']
    document = base.source_document(CASE)
    cells = [(tuple(options.cell_origin[i] + pos[i] - base.FOCUS[i] for i in range(3)), base.frozen.encode(value))
             for pos, value in document.blocks.items()]
    platform = wet.camera_side_platform(cells, (-2.5, 2., -3.5))
    source = base.fixture_plan(CASE, tuple(options.cell_origin), platform)
    preflight = runtime_args.output.with_name(runtime_args.output.stem + '_preflight.json')
    assert not preflight.exists()
    plan = {'created_at_shanghai': datetime.now(SHANGHAI).isoformat(),
            'session_binding': report['session_binding'], 'assets': fingerprint(ASSET_PLAN),
            'installed': fingerprint(INSTALLED), 'source': source,
            'controls': list(base.frozen.contained.CONTROLS),
            'camera_offset': [-2.5, 2., -3.5], 'calibration': report['calibration'],
            'runner': fingerprint(Path(__file__)), 'fixture_adapter': fingerprint(Path(base.__file__)),
            'reviewed_harness': fingerprint(base.HARNESS),
            'deadline_shanghai': DEADLINE.isoformat(),
            'resource_metadata_or_shader_edits': False, 'native_uv_accepted': False}
    preflight.write_text(json.dumps(plan, indent=2, allow_nan=False) + '\n', encoding='ascii')
    report.update(cold_rgb_preflight=fingerprint(preflight), cold_asset_plan=fingerprint(ASSET_PLAN),
                  cold_installed_receipt=fingerprint(INSTALLED), cold_marker_sources=assets['assets'],
                  source_channel_diagnostic=True, native_uv_accepted=False,
                  native_cadence_accepted=False, production_accepted=False)
    harness.checkpoint()
    print(json.dumps({'preflight': report['cold_rgb_preflight']}), flush=True)
    original_frame = harness.frame
    def guarded_frame(label, pose):
        assert datetime.now(SHANGHAI) < DEADLINE, 'Cold native capture cutoff reached; restore fixture'
        session = load_session(live=True)
        status = background_guard_state(session['game_pid'], Path(session['game_executable']).name)
        assert status['window_noactivate'] and status['background_safe'], 'Owned background contract changed'
        return original_frame(label, pose)
    harness.frame = guarded_frame
    try:
        return ORIGINAL_EXECUTE(harness, options, runtime_args, report)
    finally:
        harness.frame = original_frame


base.frozen.execute_controls = execute
if __name__ == '__main__':
    raise SystemExit(base.frozen.main())
