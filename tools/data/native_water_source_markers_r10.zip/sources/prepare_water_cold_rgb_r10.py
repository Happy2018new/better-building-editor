"""Prepare and reversibly install only three cold native-water bitmap markers."""
import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image

PROJECT = Path(__file__).resolve().parents[1]
BASE = PROJECT / '.runtime/water-cold-r10b-v3'
MANIFEST = BASE / 'asset-plan.json'
NATIVE = Path('D:/MCStudioDownload/game/MinecraftPE_Netease/3.9.0.401155/data/resource_packs')
ROWS = (('still', 'vanilla', 'water_still_grey.png', (255, 0, 0, 255)),
        ('flow', 'vanilla', 'water_flow_grey.png', (0, 255, 0, 255)),
        ('netease', 'vanilla_netease', 'netease_water_texture.png', (0, 0, 255, 255)))


def fingerprint(path):
    path = Path(path)
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def resource_manifest():
    return {str(path.relative_to(PROJECT / 'resource_pack')).replace('\\', '/'):
            fingerprint(path)['sha256'] for path in sorted((PROJECT / 'resource_pack').rglob('*')) if path.is_file()}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='ascii')


def prepare():
    assert not MANIFEST.exists(), 'Preserve the original private asset plan'
    (BASE / 'assets').mkdir(parents=True, exist_ok=True)
    (BASE / 'backups').mkdir(exist_ok=True)
    rows = []
    for label, pack, name, color in ROWS:
        source = NATIVE / pack / 'textures/blocks' / name
        target = PROJECT / 'resource_pack/textures/blocks' / name
        generated = BASE / 'assets' / name
        with Image.open(source) as image:
            size = image.size
        Image.new('RGBA', size, color).save(generated)
        backup = BASE / 'backups' / name
        original = fingerprint(target) if target.exists() else None
        if original is not None:
            backup.write_bytes(target.read_bytes())
        rows.append({'label': label, 'source': fingerprint(source), 'target': str(target),
                     'generated': fingerprint(generated), 'size': list(size), 'marker_rgba': list(color),
                     'original': original, 'backup': fingerprint(backup) if original else None})
    plan = {'schema_version': 1, 'scope': 'Cold resource source-channel diagnostic only; no geometry/UV/cadence acceptance',
            'project': str(PROJECT), 'source': fingerprint(Path(__file__)), 'assets': rows,
            'baseline_resource_manifest': resource_manifest(), 'baseline_config': fingerprint(PROJECT / '.mcdev.json'),
            'baseline_pack_manifest': fingerprint(PROJECT / 'resource_pack/manifest.json'),
            'atlas_or_flipbook_edits': False, 'shader_edits': False,
            'native_source_name': 'minecraft:water', 'setter': 'SetBlockNew', 'depth': 0,
            'source_origin': [6, 96, 6], 'camera_offset': [-2.5, 2, -3.5],
            'controls': ['supported_positive', 'supported_negative', 'liquid_only', 'empty'],
            'camera_prerequisite': 'Independent same-session stone calibration with original gates',
            'source_gate': 'All exact foreground/background cells unchanged on server and client before/after every capture',
            'channel_plan': {'roi': 'Independent native projected liquid hull excluding dilated support hull; inset north/west grid also scored',
                             'background_transmission': 'Fixed single [0,1] coefficient from the two static positive/negative control deltas',
                             'water_contribution': 'liquid_only - transmission * empty, checked against supported_positive - transmission * supported_negative',
                             'minimum_dominant_channel_fraction': .75, 'minimum_dominant_channel_margin_rgb': 20,
                             'minimum_identifiable_pixels': 80,
                             'ambiguity': 'Reject if channel contributions, controls, cold load, or source gates do not agree'},
            'readiness_retry_basis': 'v2 game entered after the previous 90-second wait; v3 waits at most 180 seconds',
            'native_write_capture_deadline_shanghai': '2026-10-12T13:35:00+08:00',
            'cleanup_stop_deadline_shanghai': '2026-10-12T13:45:00+08:00'}
    write_json(MANIFEST, plan)
    print(json.dumps({'prepared': True, 'plan': fingerprint(MANIFEST), 'assets': rows, 'project_resource_writes': 0}))


def install(plan):
    receipt = BASE / 'installed.json'
    assert not receipt.exists(), 'Installation receipt already exists'
    assert resource_manifest() == plan['baseline_resource_manifest'], 'Frozen resource pack changed before installation'
    assert fingerprint(PROJECT / '.mcdev.json') == plan['baseline_config']
    state = {'plan': fingerprint(MANIFEST), 'installed': [], 'completed': False}
    write_json(receipt, state)
    for row in plan['assets']:
        generated, target = Path(row['generated']['path']), Path(row['target'])
        assert fingerprint(generated) == row['generated']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(generated.read_bytes())
        state['installed'].append(fingerprint(target))
        write_json(receipt, state)
    state['completed'] = True
    state['installed_resource_manifest'] = resource_manifest()
    write_json(receipt, state)
    print(json.dumps({'installed': True, 'receipt': fingerprint(receipt)}))


def restore(plan):
    receipt = BASE / 'restored.json'
    assert not receipt.exists(), 'Preserve the restoration receipt'
    restored = []
    for row in plan['assets']:
        target = Path(row['target'])
        if target.exists():
            assert fingerprint(target)['sha256'] == row['generated']['sha256'], 'Marker changed; do not overwrite another edit'
        if row['original'] is None:
            if target.exists():
                target.unlink()
            restored.append({'target': str(target), 'original_absence_verified': not target.exists()})
        else:
            backup = Path(row['backup']['path'])
            assert fingerprint(backup) == row['backup']
            target.write_bytes(backup.read_bytes())
            restored.append({'target': str(target), 'original_bytes_verified': fingerprint(target) == row['original']})
    actual = resource_manifest()
    state = {'restored': True, 'rows': restored,
             'full_resource_manifest_equal': actual == plan['baseline_resource_manifest'],
             'config_equal': fingerprint(PROJECT / '.mcdev.json') == plan['baseline_config'],
             'pack_manifest_equal': fingerprint(PROJECT / 'resource_pack/manifest.json') == plan['baseline_pack_manifest']}
    assert all(state[name] for name in ('full_resource_manifest_equal', 'config_equal', 'pack_manifest_equal'))
    write_json(receipt, state)
    print(json.dumps({'restored': True, 'receipt': fingerprint(receipt), 'gates': state}))


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('operation', choices=('prepare', 'install', 'restore'))
parser.add_argument('--project-released', action='store_true')
args = parser.parse_args()
if args.operation == 'prepare':
    prepare()
else:
    plan = json.loads(MANIFEST.read_text(encoding='ascii'))
    if args.operation == 'install':
        assert args.project_released, 'Root must release the shared frozen project before marker installation'
        install(plan)
    else:
        restore(plan)
