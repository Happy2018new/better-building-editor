"""Scratch static-water sources around the unchanged reviewed frozen harness."""
from copy import deepcopy
import importlib.util
import hashlib
import ctypes
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
sys.path.insert(0,str(ROOT/'behavior_pack/modern_projection'))
from projection import block_registry as registry
from projection.model import Document
from projection.cell import AIR,background,foreground,make_cell
from projection.debug_liquid_blueprints import VISUAL_CASE as PUBLIC_CASE
from projection.debug_liquid_blueprints import source_document as public_source_document

HARNESS=ROOT.parents[1]/'tools/capture_frozen_liquid_controls.py'
spec=importlib.util.spec_from_file_location('static_water_frozen_r9',HARNESS)
frozen=importlib.util.module_from_spec(spec)
spec.loader.exec_module(frozen)
FOCUS=(3,3,3)
DEPTHS=(0,1,3,7,8)
CASE_DEPTHS={'static_water_depth_%d_foreground_r9' % depth:depth for depth in DEPTHS}
NEIGHBORS={'east':(1,0,0),'west':(-1,0,0),'south':(0,0,1),'north':(0,0,-1)}
for direction in NEIGHBORS:
    CASE_DEPTHS['static_water_depth_3_neighbor_source_'+direction+'_r9']=3
SHAPE_ROWS={}
for kind in ('source_pair','source_pool','liquid_above','solid_side','flow_gradient','flow_corner'):
    public_id='water_'+kind+'_foreground'
    identity='static_water_'+kind+'_foreground_r9'
    SHAPE_ROWS[identity]=next(row for row in PUBLIC_CASE['cases'] if row['id']==public_id)
mixed_id='static_water_mixed_0_1_3_7_foreground_r9'
SHAPE_ROWS[mixed_id]=deepcopy(SHAPE_ROWS['static_water_source_pool_foreground_r9'])
SHAPE_ROWS[mixed_id]['liquid_cells']=tuple((pos,registry.from_states('minecraft:water',{'liquid_depth':depth}))
    for (pos,unused),depth in zip(SHAPE_ROWS[mixed_id]['liquid_cells'],(0,1,3,7)))
for depth in range(16):
    identity='static_water_uniform_pool_depth_%d_foreground_r9' % depth
    SHAPE_ROWS[identity]=deepcopy(SHAPE_ROWS['static_water_source_pool_foreground_r9'])
    SHAPE_ROWS[identity]['liquid_cells']=tuple((pos,registry.from_states('minecraft:water',{'liquid_depth':depth}))
        for pos,unused in SHAPE_ROWS[identity]['liquid_cells'])
BACKDROP_IDS=set()
for depth in range(16):
    identity='static_water_uniform_pool_depth_%d_foreground_quartz_backdrop_r9' % depth
    SHAPE_ROWS[identity]=deepcopy(SHAPE_ROWS['static_water_uniform_pool_depth_%d_foreground_r9' % depth])
    BACKDROP_IDS.add(identity)
FENCE_CASES=('static_water_wet_fence_adjacent_source_r9','static_water_dry_fence_adjacent_source_r9')
CASE_IDS=tuple(CASE_DEPTHS)+tuple(SHAPE_ROWS)+FENCE_CASES


def source_document(identity,isolated=True,control='supported_positive'):
    if not isolated or identity not in CASE_IDS or control not in frozen.contained.CONTROLS:
        raise ValueError('Unknown explicit static-water diagnostic source')
    if identity in FENCE_CASES:
        fence=('minecraft:oak_fence',registry.DEFAULT_AUX['minecraft:oak_fence'])
        water=registry.from_states('minecraft:water',{'liquid_depth':0})
        neighbor=(FOCUS[0]+1,FOCUS[1],FOCUS[2])
        values={}
        if control=='supported_positive':
            values[FOCUS]=make_cell(fence,water) if 'wet_fence' in identity else fence
            values[neighbor]=water
        elif control=='supported_negative':
            values[FOCUS]=fence
        elif control=='liquid_only':
            values[neighbor]=water
            if 'wet_fence' in identity:
                values[FOCUS]=water
        if control in ('supported_positive','supported_negative'):
            values.update(((pos[0],pos[1]-1,pos[2]),('minecraft:stone',0)) for pos in (FOCUS,neighbor))
        return Document((7,7,7),values,name=identity)
    if identity in SHAPE_ROWS:
        source=public_source_document(SHAPE_ROWS[identity]['id'],isolated=True,control=control)
        requested=dict(SHAPE_ROWS[identity]['liquid_cells'])
        values={}
        for pos,value in source.blocks.items():
            if value[0] in ('minecraft:water','minecraft:flowing_water'):
                original_pos=tuple(pos[i]+SHAPE_ROWS[identity]['keep'][i]-FOCUS[i] for i in range(3))
                value=registry.from_states('minecraft:water',
                    {'liquid_depth':registry.states(requested[original_pos])['liquid_depth']})
            values[pos]=value
        return Document((7,7,7),values,name=identity)
    depth=CASE_DEPTHS[identity]
    liquid={FOCUS:registry.from_states('minecraft:water',{'liquid_depth':depth})}
    for direction,offset in NEIGHBORS.items():
        if identity.endswith('_'+direction+'_r9'):
            neighbor=tuple(FOCUS[i]+offset[i] for i in range(3))
            liquid[neighbor]=registry.from_states('minecraft:water',{'liquid_depth':0})
    values={}
    if control in ('supported_positive','liquid_only'):
        values.update(liquid)
    if control in ('supported_positive','supported_negative'):
        values.update(((pos[0],pos[1]-1,pos[2]),('minecraft:stone',0)) for pos in liquid)
    return Document((7,7,7),values,name=identity)


frozen.CASE_IDS=CASE_IDS
frozen.VISUAL_CASE=deepcopy(PUBLIC_CASE)
frozen.VISUAL_CASE.update(fixture='diagnostic.static_water_sources.r9',focus=FOCUS,
    size=(7,7,7),cases=[{'id':identity,'kind':SHAPE_ROWS[identity]['kind'] if identity in SHAPE_ROWS else 'state',
                       'layer':0,'keep':FOCUS} for identity in CASE_IDS],
    registry_version=registry.source_version(),registry_fingerprint=registry.fingerprint())
OPPOSITE='--opposite-diagonal' in sys.argv
CLOSE='--close-diagonal' in sys.argv
if CLOSE:
    sys.argv.remove('--close-diagonal')
    frozen.VISUAL_CASE['camera']['world_offset']=(-2.5,2.,-3.5)
if OPPOSITE:
    sys.argv.remove('--opposite-diagonal')
    offset=frozen.VISUAL_CASE['camera']['world_offset']
    frozen.VISUAL_CASE['camera']['world_offset']=(-offset[0],offset[1],-offset[2])
frozen.source_document=source_document
original_plan=frozen.fixture_plan


def fixture_plan(identity,cell_origin,platform):
    plan=original_plan(identity,cell_origin,platform)
    if identity not in BACKDROP_IDS:
        return plan
    background=[((cell_origin[0]+x,cell_origin[1]-3,cell_origin[2]+z),
        frozen.encode(('minecraft:quartz_block',registry.DEFAULT_AUX['minecraft:quartz_block'])))
        for x in range(-2,9) for z in range(-3,11)]
    liquid_positions=[pos for pos,value in plan['controls']['liquid_only']['cells']]
    separation=min(max(abs(pos[i]-liquid[i]) for i in range(3))
        for pos,unused in background for liquid in liquid_positions)
    assert separation>=2 and tuple(platform) not in {pos for pos,unused in background}
    for control in frozen.contained.CONTROLS:
        cells=sorted(plan['controls'][control]['cells']+background)
        plan['controls'][control].update(cells=cells,native_cells=frozen.native_reference(cells))
    plan.update(background_cells=background,background_changed=True,context_changed=True,
        source_neighbor_context_changed=False,minimum_background_chebyshev_distance=separation,
        background_contract='Fixed remote horizontal quartz board, sourceY-3, X[-2,8],Z[-3,10]; present unchanged in all four controls')
    board={pos for pos,unused in background}
    plan['cavity']=sorted(set(plan['cavity'])|board)
    plan['reserved']=sorted(set(plan['reserved'])|board)
    return plan


frozen.fixture_plan=fixture_plan
original_execute=frozen.execute_controls


def execute_controls(harness,options,runtime_args,report):
    original_frame=harness.frame
    samples=report['native_resource_samples']=[]
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_bool,ctypes.c_ulong]
    kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.GetProcessHandleCount.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
    kernel.GetProcessHandleCount.restype=ctypes.c_bool
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    kernel.CloseHandle.restype=ctypes.c_bool

    def bounded_frame(label,pose):
        handle=kernel.OpenProcess(0x1000,False,harness.session['game_pid'])
        assert handle,'Cannot query owned native process resources'
        try:
            count=ctypes.c_ulong()
            assert kernel.GetProcessHandleCount(handle,ctypes.byref(count))
        finally:
            kernel.CloseHandle(handle)
        samples.append({'capture':label,'game_pid':harness.session['game_pid'],
            'handle_count':count.value,'maximum_handle_count':300000})
        harness.checkpoint()
        if count.value>=300000:
            raise RuntimeError('Owned native process handle budget reached; restore and recycle')
        return original_frame(label,pose)

    harness.frame=bounded_frame
    report.update(diagnostic_source=True,public_case_acceptance=False,
        capture_view=('close_opposite_diagonal' if OPPOSITE else 'close_diagonal') if CLOSE
            else ('opposite_diagonal' if OPPOSITE else 'public_diagonal'),
        source_identity='minecraft:water only; no flowing alias equivalence',
        source_fixture=frozen.VISUAL_CASE,
        static_depth_readback_report=harness.direct.fingerprint(
            Path('C:/Users/Happy2018new/.pyreact-debug/instances/d9584367109d48f7999c32f9ec0481b9/artifacts/static-water-direct-depths-r9-v1.json')),
        direct_setter_readback_scope='Independent earlier exact static depths1/3/7/8 with two documented setters; every current capture independently verifies its own exact declared native context')
    try:
        return original_execute(harness,options,runtime_args,report)
    finally:
        report.pop('public_fixture_source',None)
        if any(identity in BACKDROP_IDS for identity in options.case):
            report.update(background_changed=True,context_changed=True,source_neighbor_context_changed=False)
        report['method']='Diagnostic exact static-water snapshots with SDK flow disabled; no shell'
        report['owned_world_baseline']={
            'newly_created_owner_world':True,
            'previous_probes_fully_restored':[
                path.name for path in options.output.parent.glob('*.json')
                if path!=options.output and
                all(json.loads(path.read_text(encoding='utf8')).get(key) is True
                    for key in ('completed','restored'))],
            'historically_untouched':False,
            'flow_baseline':'Default enabled at owner-world creation; prior probes explicitly requested and verified False on restoration',
            'flow_state_getter_available':False}
        report['diagnostic_generated_source']={identity:{'block_name':'minecraft:water',
            'requested_states':{'liquid_depth':CASE_DEPTHS[identity]} if identity in CASE_DEPTHS else None,
            'neighbor_source_direction':next((direction for direction in NEIGHBORS
                if identity.endswith('_'+direction+'_r9')),None),
            'public_shape_source':SHAPE_ROWS[identity] if identity in SHAPE_ROWS else None,
            'explicit_diagnostic_alias_conversion':[
                {'position':pos,'original':value,'original_states':registry.states(value),
                 'diagnostic':registry.from_states('minecraft:water',
                    {'liquid_depth':registry.states(value)['liquid_depth']})}
                for pos,value in SHAPE_ROWS[identity]['liquid_cells']]
                if identity in SHAPE_ROWS else [],
            'aliases_accepted_equivalent':False} for identity in options.case}
        report['fence_control_limits']={identity:{'waterlogged_background':'minecraft:water liquid_depth0',
            'foreground':'minecraft:oak_fence registry default state',
            'adjacent_pure_source_direction':'east',
            'supported_negative':'Dry fence plus identical stone supports; no adjacent water',
            'liquid_only':'Pure water cells with fence and supports removed',
            'wet_vs_dry_context_comparison':'Compare supported_positive PNGs of the paired wet/dry fence cases',
            'mask_limit':'Dry fence unit cell hull is excluded with supports; independent pixel gate is satisfied only by adjacent water',
            'fence_water_geometry_accepted':False} for identity in options.case if identity in FENCE_CASES}
        source_data=Path(__file__).read_bytes()
        source_sha=hashlib.sha256(source_data).hexdigest()
        preserved=options.output.parent/'experimental_source'/('capture_static_water_controls_r9-'+source_sha+'.py')
        preserved.parent.mkdir(parents=True,exist_ok=True)
        if preserved.exists():
            assert preserved.read_bytes()==source_data
        else:
            preserved.write_bytes(source_data)
        report['diagnostic_fixture_source']=harness.direct.fingerprint(preserved)
        report['diagnostic_fixture_live_path']=str(Path(__file__))
        report['reviewed_harness_source']=harness.direct.fingerprint(HARNESS)
        harness.checkpoint()


frozen.execute_controls=execute_controls

if __name__=='__main__':
    raise SystemExit(frozen.main())
