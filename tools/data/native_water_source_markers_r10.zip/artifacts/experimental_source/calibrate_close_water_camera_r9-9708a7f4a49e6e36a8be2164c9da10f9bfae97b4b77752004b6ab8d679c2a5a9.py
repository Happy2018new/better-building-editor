"""Use the reviewed unit-cube calibration at three fixed close diagonals."""
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
sys.path.insert(0,str(ROOT/'behavior_pack/modern_projection'))
import verify_camera_projection as calibration

ORIGINAL_POSE=calibration.POSE
ORIGINAL_STONE_SIGNAL=calibration.stone_signal
ORIGINAL_FIT=calibration.fit_fov
ORIGINAL_ANALYZE=calibration.analyze_calibration
ORIGINAL_SLEEP=calibration.time.sleep
OFFSETS={
    (0.,0.,6.):(0.,0.,6.),
    (6.,0.,0.):(6.,0.,0.),
    (0.,3.,6.):(-2.5,2.,-3.5),
    (0.,-3.,6.):(-2.5,2.,-3.5)}


class ClosePoses:
    def __mod__(self,values):
        return ORIGINAL_POSE % (OFFSETS[tuple(values[0])],)


def contribution_signal(shown,hidden):
    contribution=calibration.maximum(calibration.signal(shown,hidden)).point(
        lambda value:255 if value>20 else 0)
    center=calibration.Image.new('L',contribution.size)
    width,height=contribution.size
    calibration.ImageDraw.Draw(center).rectangle(
        (width*.3,height*.25,width*.7,height*.75),fill=255)
    isolated=calibration.largest_component(calibration.ImageChops.multiply(contribution,center))
    outline=calibration.fill_enclosed_holes(isolated).filter(calibration.ImageFilter.MedianFilter(3))
    outline=outline.filter(calibration.ImageFilter.MinFilter(3)).filter(calibration.ImageFilter.MaxFilter(3))
    assert calibration.ImageChops.multiply(outline,contribution).histogram()[255]>=1000
    return outline


def convex_stone_signal(shown,hidden):
    measured=ORIGINAL_STONE_SIGNAL(shown,hidden)
    pixels=measured.load()
    x0,y0,x1,y1=measured.getbbox()
    endpoints=[]
    for y in range(y0,y1):
        occupied=[x for x in range(x0,x1) if pixels[x,y]]
        if occupied:
            endpoints.extend(((occupied[0],y),(occupied[-1],y)))
    result=calibration.Image.new('L',measured.size)
    calibration.ImageDraw.Draw(result).polygon(calibration.hull(endpoints),fill=255)
    return result


def compact_projected_mask(pose,size,fov):
    points=[tuple(pose['target'][axis]+offset[axis] for axis in range(3))
        for offset in ((x,y,z) for x in (-.5,.5) for y in (-.5,.5) for z in (-.5,.5))]
    projected=calibration.project_points(points,pose['position'],pose['target'],size,fov)
    polygon=calibration.hull((row['screenX'],row['screenY']) for row in projected)
    box=(max(0,int(calibration.math.floor(min(point[0] for point in polygon)))),
        max(0,int(calibration.math.floor(min(point[1] for point in polygon)))),
        min(size[0],int(calibration.math.floor(max(point[0] for point in polygon)))+1),
        min(size[1],int(calibration.math.floor(max(point[1] for point in polygon)))+1))
    mask=calibration.Image.new('L',(box[2]-box[0],box[3]-box[1]))
    calibration.ImageDraw.Draw(mask).polygon([(x-box[0],y-box[1]) for x,y in polygon],fill=255)
    return box,mask


def exact_compact_fit(actual,pose,fixed_fov=None):
    bounds=actual.getbbox()
    assert bounds is not None,'The native calibration cube is invisible'
    actual_count=actual.crop(bounds).histogram()[255]
    best=None
    candidates=(fixed_fov,) if fixed_fov is not None else (step/10. for step in range(300,1301))
    for fov in candidates:
        box,predicted=compact_projected_mask(pose,actual.size,fov)
        local_bounds=predicted.getbbox()
        expected=tuple(local_bounds[i]+box[i%2] for i in range(4))
        predicted_count=predicted.histogram()[255]
        intersection=calibration.ImageChops.multiply(actual.crop(box),predicted).histogram()[255]
        union=actual_count+predicted_count-intersection
        error=sum((bounds[i]-expected[i])**2 for i in range(4))
        score=(-intersection/max(1,union),error)
        if best is None or score<best[0]:
            best=(score,fov,box,predicted,expected)
    full=calibration.Image.new('L',actual.size)
    full.paste(best[3],best[2][:2])
    native_edges=actual.filter(calibration.ImageFilter.FIND_EDGES).point(lambda value:255 if value else 0)
    predicted_edges=full.filter(calibration.ImageFilter.FIND_EDGES).point(lambda value:255 if value else 0)
    recall=calibration.ImageChops.multiply(native_edges,predicted_edges.filter(calibration.ImageFilter.MaxFilter(5))).histogram()[255]/max(1,native_edges.histogram()[255])
    precision=calibration.ImageChops.multiply(predicted_edges,native_edges.filter(calibration.ImageFilter.MaxFilter(5))).histogram()[255]/max(1,predicted_edges.histogram()[255])
    return {'vertical_fov':best[1],'bounds':bounds,'predicted_bounds':best[4],
        'boundary_rms_pixels':calibration.math.sqrt(best[0][1]/4.),'mask_iou':-best[0][0],
        'outline_recall_2px':recall,'outline_precision_2px':precision,
        'fit_contract':'Complete convex hull of eight world cube corners and native silhouette, not width alone'}


def bounded_common_fit(report):
    ORIGINAL_ANALYZE(report)
    if report['passed']:
        return report
    actual=[convex_stone_signal(row['shown']['path'],row['hidden']['path']) for row in report['views']]
    fitted=report['individual_fitted_vertical_fov']
    viable=[]
    for step in range(int(min(fitted)*10),int(max(fitted)*10)+1):
        fov=step/10.
        fits=[exact_compact_fit(image,row['pose'],fov) for image,row in zip(actual,report['views'])]
        if all(fit['boundary_rms_pixels']<=2 and fit['mask_iou']>=.95 and
                fit['outline_recall_2px']>=.985 and fit['outline_precision_2px']>=.985 for fit in fits):
            viable.append((sum(fit['mask_iou'] for fit in fits),fov,fits))
    report['constrained_common_fov_candidates']=[{'vertical_fov':item[1],'sum_mask_iou':item[0]} for item in viable]
    if viable:
        unused,fov,fits=max(viable,key=lambda item:item[0])
        report.update(passed=True,vertical_fov=fov,
            common_fov_selection='Maximum sum IoU among independently measured unit-cube FOVs satisfying all original full-hull gates; no liquid pixels used')
        for image,row,fit in zip(actual,report['views'],fits):
            row.update(fit=fit,passed=True)
            native=image.filter(calibration.ImageFilter.FIND_EDGES)
            predicted=calibration.projected_mask(row['pose'],image.size,fov).filter(calibration.ImageFilter.FIND_EDGES)
            calibration.Image.merge('RGB',(native,predicted,calibration.Image.new('L',image.size))).save(row['outline_comparison'])
    return report


def fingerprint(path):
    path=Path(path)
    data=path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}


if __name__=='__main__':
    calibration.POSE=ClosePoses()
    calibration.stone_signal=convex_stone_signal
    calibration.fit_fov=exact_compact_fit
    calibration.analyze_calibration=bounded_common_fit
    calibration.time=SimpleNamespace(sleep=lambda value:ORIGINAL_SLEEP(2. if value in (.4,.25) else value))
    output=Path(sys.argv[1])
    try:
        if '--replay' in sys.argv:
            replay=Path(sys.argv[sys.argv.index('--replay')+1])
            report=json.loads(replay.read_text(encoding='utf8'))
            for row in report['views']:
                row['signal']=str(output.with_name(output.stem+'_'+row['view']+'_signal.png'))
                row['outline_comparison']=str(output.with_name(output.stem+'_'+row['view']+'_outline_comparison.png'))
            report['replayed_from']=fingerprint(replay)
            calibration.analyze_calibration(report)
            calibration.write_json(output,report)
            result=0 if report['passed'] else 1
            print(json.dumps({'passed':report['passed'],'vertical_fov':report['vertical_fov']}))
        else:
            result=calibration.main()
    finally:
        if output.exists():
            report=json.loads(output.read_text(encoding='utf8'))
            source_data=Path(__file__).read_bytes()
            preserved=output.parent/'experimental_source'/('calibrate_close_water_camera_r9-'+hashlib.sha256(source_data).hexdigest()+'.py')
            preserved.parent.mkdir(parents=True,exist_ok=True)
            if not preserved.exists():
                preserved.write_bytes(source_data)
            assert preserved.read_bytes()==source_data
            report.update(diagnostic_camera=True,
                declared_close_offsets=[list(OFFSETS[key]) for key in ((0.,0.,6.),(6.,0.,0.),(0.,3.,6.))],
                scratch_calibration_source=fingerprint(preserved),
                camera_and_hidden_settle_seconds=2.,
                reviewed_calibration_source=fingerprint(calibration.__file__),
                independent_cube_mask='Original stone neutral13/brightness50 and shown-hidden contribution20; unchanged central fixed ROI, largest connected component, enclosed-hole fill; measured convex hull of outer row endpoints for known convex unit cube',
                native_geometry_accepted=False)
            calibration.write_json(output,report)
    raise SystemExit(result)
