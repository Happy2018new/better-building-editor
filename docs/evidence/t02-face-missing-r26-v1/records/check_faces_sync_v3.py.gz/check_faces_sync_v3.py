"""Observe two identical actual editor poses; preserve the frozen original and residual."""
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
from frozen_guard import verify
manifest=verify()
original=HERE/'check_faces.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()==manifest['evidence_hosts']['check_faces.py']
source=original.read_text(encoding='utf8')
needle="sys.path[:0]=[str(PROJECT/'tools'),str(PROJECT/'.agents/skills/pyreact-debugging/scripts')]"
replacement="sys.path[:0]=[str(PROJECT/'.agents/skills/pyreact-debugging/scripts'),str(PROJECT/'tools')]"
assert source.count(needle)==1
source=source.replace(needle,replacement)
needle="            state=check.wait('face pose synchronized',lambda row:abs((row['pose'][0]-yaw+180)%360-180)<.03 and abs(row['pose'][1]-pitch)<.03 and abs(row['pose'][2]-zoom)<.003,pose)"
replacement="""            last_actual=[None]
            def stable_actual(row):
                target_close=abs((row['pose'][0]-yaw+180)%360-180)<.03 and abs(row['pose'][1]-pitch)<.03 and abs(row['pose'][2]-zoom)<.003
                same=last_actual[0]==row
                last_actual[0]=row
                return target_close and same
            state=check.wait('two identical actual editor poses within target tolerance',stable_actual,pose)"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
needle="return {'subject':subject,'state':state,'after':after,'capture':image,'pixels_accepted':False}"
replacement="return {'subject':subject,'state':state,'after':after,'requested_pose':(yaw,pitch,zoom),'actual_pose_residual':((state['pose'][0]-yaw+180)%360-180,state['pose'][1]-pitch,state['pose'][2]-zoom),'capture':image,'pixels_accepted':False}"
assert source.count(needle)==1
source=source.replace(needle,replacement)
needle='    def run(self,code):return super().run(p.CLIENT+code)'
replacement="""    def guard(self):
        super().guard()
        if self.cleaning:return
        status=json.loads((HERE/'assert-watch/status.json').read_bytes())
        assert status['owners']==[OWNER]
        assert status['host_sha256']==manifest['host_files']['tools/watch_owned_disabled_skin_assert_r20.py']
        assert (datetime.now(timezone.utc)-datetime.fromisoformat(status['checked_at'])).total_seconds()<5
        assert not status['errors'] and not status['other_assertions'],status
    def run(self,code):return super().run(p.CLIENT+code)"""
assert source.count(needle)==1
source=source.replace(needle,replacement)
receipt={'started_at':datetime.now(timezone.utc).isoformat(),
 'original_driver_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),
 'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'derived_driver_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'original_frozen_unchanged':True,'production_changes':False,
 'prior_failure_preserved':'v2 import stopped before any RPC: tools/mcdk.py shadowed skill scripts/mcdk.py',
 'changes':['Resolve skill scripts/mcdk.py before tools/mcdk.py.', 'Wait for two identical actual poses 0.2 seconds apart within original target tolerance; record residual.',
            'Check fresh (<5 seconds) exact-owner/hash watcher status with no errors/other assertions before every RPC.']}
path=HERE/'sync-v3-receipt.json'
assert not path.exists()
path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
scope={'__name__':'__main__','__file__':str(original),'manifest':manifest}
try:exec(compile(source,str(original),'exec'),scope)
finally:
 receipt['source_unchanged_after']=verify()==manifest
 path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
