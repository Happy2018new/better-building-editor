"""Correct only the frozen host's sample census; keep the original failed preflight."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from frozen_guard import verify
manifest = verify()
import public_entry_host as entry
controls = entry.CONTROLS
assert controls.count('rows=[]') == 1
controls = controls.replace('rows=[]', 'rows=[]\nempty=[]\nactive_seen=set()')
needle = " part=s.tiles.parts[key]\n if not preview.ready(part['name']):continue"
replacement = """ part=s.tiles.parts[key]
 if part['name'] is None:
  counts=[sum(len(value) for value in layer.values()) for layer in part['data'][:3]]
  assert key not in s.tiles.region_owners,key
  assert part['count']==0 and not part['pending'] and counts==[0,0,0],(key,part['count'],part['pending'],counts)
  empty.append({'key':key,'name':None,'count':0,'pending':False,'palette_counts':counts,'region_owner':False})
  continue
 if key in s.tiles.region_owners:
  active_seen.add(key)
  assert preview.ready(part['name']) and not part['pending'],key
  assert part['signature']==s.preview_signature(),key
  assert part['bank'] in part.get('cache',{}) and part['cache'][part['bank']][0]==part['data'] and part['cache'][part['bank']][1]==part['name'] and part.get('source') in part['cache'][part['bank']][2],key
 if not preview.ready(part['name']):continue"""
assert controls.count(needle) == 1
controls = controls.replace(needle, replacement)
needle = "assert rows and all(row['current_signature'] for row in rows)"
assert controls.count(needle) == 1
controls = controls.replace(needle, needle + "\nassert active_seen==s.tiles.region_owners,(active_seen,s.tiles.region_owners)")
controls = controls.replace("'models':rows})", "'models':rows,'verified_empty_slots':empty})")
entry.CONTROLS = controls
