"""Preserve the failed package size gate; keep four redundant full UI trees local."""
import gzip,hashlib,json
from pathlib import Path
from frozen_guard import verify
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OUT=ROOT/'docs/evidence/t02-face-missing-r26-v1'
sha=lambda data:hashlib.sha256(data).hexdigest()
index=json.loads((OUT/'index.json').read_bytes())
assert 'local_only_ui_trees' not in index
removed=[];retained=[]
for row in index['records']:
 if row['raw'].endswith('.tree.json'):
  path=(OUT/row['archived']).resolve(strict=True)
  assert path.parent==OUT.resolve()/'records' and sha(path.read_bytes())==row['archive_sha256']
  assert gzip.decompress(path.read_bytes())==Path(ROOT/row['raw']).read_bytes()
  removed.append({'raw':row['raw'],'raw_sha256':row['raw_sha256'],'raw_bytes':row['raw_bytes'],
    'local_only':True,'not_archived_reason':'Redundant complete UI tree exceeds the 300000-byte per-file compact gate; complete card/semantic/control evidence remains in reports.',
    'failed_archive_bytes':row['archive_bytes'],'failed_archive_sha256':row['archive_sha256']})
  path.unlink()
 else:retained.append(row)
assert len(removed)==4
index['records']=retained
index['local_only_ui_trees']=removed
gate={'first_size_gate_failed':True,'affected_redundant_ui_trees':removed,
 'local_raw_deleted':False,'production_changes':False,'published_before_gate':False,
 'final_package_excludes_raw_ui_trees':True}
(HERE/'package-size-gate.json').write_text(json.dumps(gate,indent=2)+'\n',encoding='utf8')
for source in (HERE/'package-size-gate.json',Path(__file__).resolve()):
 raw=source.read_bytes();packed=gzip.compress(raw,compresslevel=9,mtime=0)
 target=OUT/'records'/(source.name+'.gz');assert not target.exists();target.write_bytes(packed)
 index['records'].append({'raw':source.relative_to(ROOT).as_posix(),'raw_sha256':sha(raw),'raw_bytes':len(raw),
  'archived':target.relative_to(OUT).as_posix(),'archive_sha256':sha(packed),'archive_bytes':len(packed),
  'archive_decoded_sha256':sha(raw),'archive_decodes_to_original_raw':True,
  'credential_redacted_derived_archive':False,'encoding':'gzip'})
assert not [str(path) for path in OUT.rglob('*') if path.is_file() and path.stat().st_size>300000]
assert verify()['source_commit']==index['source_commit']
index['per_file_limit_bytes']=300000
(OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'output':str(OUT),'images':len(index['images']),'records':len(index['records']),
 'local_only_ui_trees':len(removed),'largest_file_bytes':max(path.stat().st_size for path in OUT.rglob('*') if path.is_file()),
 'total_bytes':sum(path.stat().st_size for path in OUT.rglob('*') if path.is_file()),
 'index_sha256':sha((OUT/'index.json').read_bytes()),
 'redacted_records':sum(not row['archive_decodes_to_original_raw'] for row in index['records'])}))
