"""Compact exact T02 followup records, redacting session credentials in derived archives."""
from datetime import datetime,timezone
import gzip,hashlib,json
from pathlib import Path
from PIL import Image
from frozen_guard import verify
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OUT=ROOT/'docs/evidence/t02-face-missing-r26-v1'
manifest=verify()
assert not OUT.exists()
OUT.mkdir(parents=True)
(OUT/'records').mkdir();(OUT/'images').mkdir()
sha=lambda data:hashlib.sha256(data).hexdigest()
stop=json.loads((HERE/'stop/report.json').read_bytes())
check=json.loads((HERE/'check/report.json').read_bytes())
notes=json.loads((HERE/'visual-review.json').read_bytes())
secrets=set()
def tokens(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key=='token' and isinstance(item,str) and item:secrets.add(item)
   tokens(item)
 elif isinstance(value,list):
  for item in value:tokens(item)
tokens(stop)
index={'owner':manifest['owner'],'source_commit':manifest['source_commit'],
 'created_at':datetime.now(timezone.utc).isoformat(),'manual_issues_closed':0,'records':[],'images':[]}
sources=list(HERE.glob('*.py'))+list(HERE.glob('*.json'))
sources+=list((HERE/'check').glob('*.json'))
sources+=list((HERE/'button0-diag').glob('*.json'))
sources+=[HERE/relative for relative in ('launch/report.json','launch/exact-exit.json','stop/report.json','assert-watch/status.json')]
sources+=list((HERE/'assert-watch').glob('recovery-*.json'))
for source in sorted(set(sources)):
 assert source.is_file(),source
 raw=source.read_bytes();decoded=raw
 if source.suffix=='.json':
  for secret in secrets:decoded=decoded.replace(secret.encode(),b'<redacted>')
  json.loads(decoded)
 relative=source.relative_to(HERE).as_posix()
 name=relative.replace('/','__')
 if decoded!=raw:name=name.replace('.json','.redacted.json')
 target=OUT/'records'/(name+'.gz')
 packed=gzip.compress(decoded,compresslevel=9,mtime=0);assert gzip.decompress(packed)==decoded
 target.write_bytes(packed)
 index['records'].append({'raw':source.relative_to(ROOT).as_posix(),'raw_sha256':sha(raw),'raw_bytes':len(raw),
  'archived':target.relative_to(OUT).as_posix(),'archive_sha256':sha(packed),'archive_bytes':len(packed),
  'archive_decoded_sha256':sha(decoded),'archive_decodes_to_original_raw':decoded==raw,
  'credential_redacted_derived_archive':decoded!=raw,'encoding':'gzip'})
for source in sorted(list((HERE/'check').glob('*.png'))+list((HERE/'button0-diag').glob('*.png'))):
 label=('button0diag__' if source.parent.name=='button0-diag' else '')+source.stem
 target=OUT/'images'/(label+'.jpg')
 with Image.open(source) as image:
  image=image.convert('RGB');image.thumbnail((1280,800));image.save(target,'JPEG',quality=83,optimize=True)
 index['images'].append({'label':label,'raw':source.relative_to(ROOT).as_posix(),'raw_sha256':sha(source.read_bytes()),
  'review_jpeg':target.relative_to(OUT).as_posix(),'review_sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,
  'agent_opened_raw_image':source.relative_to(HERE).as_posix() in notes.get('opened_raw_images',[]),'human_acceptance':False})
summary={'owner':manifest['owner'],'source_commit':manifest['source_commit'],
 'source_manifest_sha256':sha((HERE/'source-manifest.json').read_bytes()),'source_unchanged':verify()==manifest,
 'completed':check['completed'],'restored':check.get('restored',False),'error':check.get('error'),
 'manual_issues_closed':0,'manual_acceptance':False,'candidate_profile_assignment':False,
 'world_write_performed':False,'native_world_occupancy':False,'actual_public_card_callbacks':True,
 'fixture_cells':check.get('fixture_cells'),'direction_samples':check.get('direction_samples'),
 'fixture_material_counts':check.get('fixture_material_counts'),
 'editor_faces_observed':len(check['editor_faces']),
 'operations':[{'operation':row['operation'],'data_equal':row['data']['equal'],'subject':row.get('subject'),
  'missing_completed':row.get('missing_completed',False),'observer_restored':row.get('observer_restored',False),
  'stages':[{'label':stage['label'],'observations':stage['final']['observations'],
   'commits':stage['final']['commits'],'player_stable':stage['state']['player']==stage['final']['player'],
   'native_camera_stable':stage['camera_before']==stage['camera_after'],
   'typed_snapshot_equal':stage['document_verification']['equal']} for stage in row['stages'] if 'final' in stage]}
  for row in check['operations']],
 'independent_restore_audit_count':len(check.get('independent_restore_audits',[])),
 'independent_external_audits':{phase:json.loads((HERE/('face-restore-'+phase+'.json')).read_bytes())['completed'] for phase in ('before','after1','after2')},
 'bottom_button_diagnostic':{'completed':json.loads((HERE/'button0-diag/report.json').read_bytes())['completed'],
  'restored':json.loads((HERE/'button0-diag/report.json').read_bytes()).get('restored',False),
  'external_final_audits':{phase:json.loads((HERE/('button0-final-restore-'+phase+'.json')).read_bytes())['completed'] for phase in ('after1','after2')},
  'display_only':True,'complete_document_and_support_preserved':True},
 'visual_review':notes,'lifecycle':{'ordinary_stop_and_finalize_completed':stop['completed'],
  'registry_state':stop['registry_final']['state'],'actual_exit_codes':stop['actual_exit_codes'],
  'normal_shutdown_qualified':stop['normal_shutdown_qualified'],'force_executed':stop['force_executed'],
  'watcher_retired':json.loads((HERE/'assert-watch-close.json').read_bytes())['completed']},
 'frozen_source_or_evidence_overwritten':False,'credential_redaction':'Local raw retained; derived repository archive has raw, archive and decoded hashes; exactness is explicit.'}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
index['summary_sha256']=sha((OUT/'summary.json').read_bytes())
(OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
oversize=[str(path) for path in OUT.rglob('*') if path.is_file() and path.stat().st_size>300000]
assert not oversize,oversize
print(json.dumps({'output':str(OUT),'images':len(index['images']),'records':len(index['records']),
 'total_bytes':sum(path.stat().st_size for path in OUT.rglob('*') if path.is_file()),'index_sha256':sha((OUT/'index.json').read_bytes()),
 'redacted_records':sum(not row['archive_decodes_to_original_raw'] for row in index['records'])}))
