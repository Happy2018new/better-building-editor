"""Offline full typed oracle + independent attachment matrices; no game or RPC."""
import ast,hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
from frozen_guard import verify
manifest=verify()
PROJECT=Path(manifest['project'])
sys.path[:0]=[str(PROJECT/'tools'),str(PROJECT/'.agents/skills/pyreact-debugging/scripts')]
import verify_transform_runtime_r23 as base
from projection.cell import foreground
from face_plan import subjects
from lifecycle_helpers import memory
report={'owner':manifest['owner'],'source_commit':manifest['source_commit'],
 'source_manifest_sha256':hashlib.sha256((HERE/'source-manifest.json').read_bytes()).hexdigest(),
 'started_at':datetime.now(timezone.utc).isoformat(),'game_started':False,'rpc_called':False,
 'candidate_profile_assignment':False,'world_write_performed':False,'production_changes':False,
 'manual_issues_closed':0,'rows':[]}
for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
oracle=base.Editor(base.build('test.transforms.acceptance.t02'))
base.prepare(oracle,'test.transforms.acceptance.t02')
original=base.document_semantics(oracle.document.to_data())
assert len(oracle.document.blocks)==60
for operation in (None,'mirror_y','rotate_y90'):
 if operation:oracle.run(operation)
 rows=subjects(operation)
 assert len(rows)==10
 for row in rows:
  assert foreground(oracle.document.get(row['position']))[0]==row['material'],row
  assert foreground(oracle.document.get(row['support']))[0]=='minecraft:stone',row
  assert tuple(row['position'][i]-row['normal'][i] for i in range(3))==row['support']
 report['rows'].append({'operation':operation or 'initial','subjects':rows,'cells':len(oracle.document.blocks),
  'semantic_document_sha256':hashlib.sha256(json.dumps(base.document_semantics(oracle.document.to_data()),sort_keys=True).encode()).hexdigest()})
 if operation:
  transformed=base.document_semantics(oracle.document.to_data())
  oracle.undo();assert base.document_semantics(oracle.document.to_data())==original
  oracle.redo();assert base.document_semantics(oracle.document.to_data())==transformed
  oracle.undo();assert base.document_semantics(oracle.document.to_data())==original
report['memory']=memory()
assert report['memory']['headroom_bytes']>=6*1024**3
report['source_unchanged']=verify()==manifest
report['completed']=True
(HERE/'preflight.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({key:report[key] for key in ('owner','source_commit','completed','source_unchanged','game_started')}))
