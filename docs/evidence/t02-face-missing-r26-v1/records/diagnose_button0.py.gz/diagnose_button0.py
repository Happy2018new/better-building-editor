"""Same cold owner: existing full/single display API isolates bottom button without changing its document."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent
inherited=HERE/'check_faces_sync_v3.py'
scope={'__file__':str(inherited)}
exec(compile(inherited.read_text(encoding='utf8').split("receipt={'started_at'")[0],str(inherited),'exec'),scope)
source=scope['source']
source=source.replace("OUT=HERE/'check'","OUT=HERE/'button0-diag'")
start=source.index('            for subject in subjects():')
end=source.index('        except Exception as error:',start)
body="""            report['diagnostic_only']=True
            report['display_only_api']=['Session.layer(3)','Session.display_mode(full/single)']
            report['fixture_data_before']=check.run('_result=json.dumps(s.editor.document.to_data())')
            subject=next(value for value in subjects() if value['name']=='button_0')
            for mode,pitch in (('full',-45.),('single',-80.),('single',-45.)):
                check.run('s.layer(3)\\ns.display_mode(%r)\\n_result=True' % mode)
                check.editor_preview('button0 existing '+mode+' API')
                sample=dict(subject,name='button_0_'+mode+'_pitch'+str(abs(int(pitch))),editor_pitch=pitch)
                row=editor_face(sample)
                row['document_verification']=base.verify(check,oracle,'bottom-button display diagnostic',report)
                row['display_state']=check.run('_result=json.dumps({"mode":s.current_display_mode(),"layer":s.editor.layer,"solo_layer":s.solo_layer,"section":s.section,"view":s.view,"complete_document":s.editor.document.to_data(),"support_cell":s.editor.document.get((3,4,27)),"target_cell":s.editor.document.get((3,3,27))})')
                assert row['display_state']['complete_document']==report['fixture_data_before']
                assert row['display_state']['layer']==3 and row['display_state']['mode']==mode
                report['editor_faces'].append(row);save()
            report['completed']=len(report['editor_faces'])==3
"""
source=source[:start]+body+source[end:]
receipt={'started_at':datetime.now(timezone.utc).isoformat(),
 'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'inherited_wrapper_sha256':hashlib.sha256(inherited.read_bytes()).hexdigest(),
 'original_frozen_driver_sha256':hashlib.sha256((HERE/'check_faces.py').read_bytes()).hexdigest(),
 'derived_driver_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'production_changes':False,'world_write_performed':False,'same_cold_owner':True,
 'document_unchanged_display_filter_only':True,'manual_issues_closed':0}
path=HERE/'button0-diag-receipt.json';assert not path.exists()
path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
try:exec(compile(source,str(HERE/'check_faces.py'),'exec'),dict(__name__='__main__',__file__=str(HERE/'check_faces.py'),manifest=scope['manifest']))
finally:
 receipt['source_unchanged_after']=scope['verify']()==scope['manifest']
 path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
