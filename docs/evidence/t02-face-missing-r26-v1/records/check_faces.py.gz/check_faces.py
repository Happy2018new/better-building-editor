"""Actual public T02 callback, ten attached-face closeups and two controlled missing representatives."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from datetime import datetime, timezone
from collections import Counter
import hashlib,json,sys,time,traceback,uuid
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OWNER='r26-t02-face-missing-v1'
PROJECT=ROOT/'.runtime/projects'/OWNER
sys.path[:0]=[str(PROJECT/'tools'),str(PROJECT/'.agents/skills/pyreact-debugging/scripts')]
from _session import load_session
from mcdk import Client
import verify_debug_blueprints as blue
import verify_transform_runtime_r23 as base
import transform_missing_r23 as missing
from run_transform_final import bounded_world
import public_entry_host as entry
import strict_controls
from frozen_guard import verify
import payloads as p
from face_plan import subjects
from projection.cell import foreground

OUT=HERE/'check'
IDENTITY='test.transforms.acceptance.t02'

class FaceCheck(entry.EntryCheck):
    def run(self,code):return super().run(p.CLIENT+code)

def main():
    manifest=verify()
    assert manifest['source_commit']=='c531b2f4802577e160b26105c6d73cd8322ff89f'
    binding=load_session(Path(json.loads((HERE/'launch/report.json').read_bytes())['session_file']),OWNER,live=True)
    assert Path(binding['project']).resolve()==PROJECT.resolve()
    os.environ.update(MCDEV_SESSION_FILE=binding['session_file'],MCDEV_OWNER=OWNER,
                      MCDEV_MCP_URL=binding['mcp_url'],MCDEV_GAME_PID=str(binding['game_pid']),MCDEV_ALLOW_USER_FOREGROUND='0')
    OUT.mkdir(exist_ok=False)
    report={'owner':OWNER,'source_commit':manifest['source_commit'],'completed':False,'manual_issues_closed':0,
      'manual_acceptance':False,'candidate_profile_assignment':False,'native_mouse_clicked':False,
      'actual_public_card_callbacks':True,'world_write_performed':False,'native_world_occupancy':False,
      'source_manifest_sha256':hashlib.sha256((HERE/'source-manifest.json').read_bytes()).hexdigest(),
      'started_at':datetime.now(timezone.utc).isoformat(),'editor_faces':[],'operations':[]}
    def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    save()
    installed=snapshot=tool_saved=visual_saved=False
    with Client(timeout=35) as client:
        check=FaceCheck(client,OUT,binding,report)
        def editor_face(subject):
            position=tuple(subject['position']);yaw=subject['editor_yaw'];pitch=subject['editor_pitch'];zoom=12.
            check.run('s.grid=False\ns.focused=%r\ns.camera_focus_request=%r\n_result=True' %
                      (position,tuple(value+.5 for value in position)))
            check.wait('face focus consumed',lambda row:row['request'] is None and row['pivot'] is not None,
                       lambda:check.run('_result=json.dumps({"request":s.camera_focus_request,"pivot":s.camera_pivot})'))
            check.run('s.camera_view(%r,%r,%r)\n_result=True' % (yaw,pitch,zoom))
            def pose():return check.run('_result=json.dumps({"pose":s.camera_pose,"pivot":s.camera_pivot,"focus":s.focused,"document_id":id(s.editor.document)})')
            state=check.wait('face pose synchronized',lambda row:abs((row['pose'][0]-yaw+180)%360-180)<.03 and abs(row['pose'][1]-pitch)<.03 and abs(row['pose'][2]-zoom)<.003,pose)
            check.editor_preview('stable attached face '+subject['name'])
            time.sleep(.25)
            image=check.capture('t02_'+subject['name']+'_editor')
            after=pose()
            assert state==after,(state,after)
            return {'subject':subject,'state':state,'after':after,'capture':image,'pixels_accepted':False}
        def world_pose(subject):
            return check.run('focus=%r\noffset=%r\ntarget=tuple(s.origin[i]+focus[i]+.5 for i in range(3))\nposition=tuple(target[i]+offset[i] for i in range(3))\nrotation=api.GetRotFromDir(tuple(target[i]-position[i] for i in range(3)))\ncam=factory.CreateCamera(level)\ncam.DepartCamera()\ncam.LockModCameraPitch(True)\ncam.LockModCameraYaw(True)\nassert cam.SetCameraPos(position)\nassert cam.SetCameraRotation((rotation[0],rotation[1]+180.,0.))\n_result=json.dumps({"target":target,"position":cam.GetPosition(),"rotation":cam.GetCameraRotation(),"normal":%r})' %
                             (tuple(subject['position']),tuple(subject['world_offset']),tuple(subject['normal'])))
        def world_restore_workspace():
            check.run('b.stop_projection()\nowner.open_workspace()\n_result=True')
            check.wait('workspace restored',lambda row:row['open'] and not row['transition'],check.navigation)
        try:
            report['baseline']=check.run(p.SNAPSHOT);snapshot=True
            check.run(blue.INSTALL_PROBE);installed=True
            check.run(base.SAVE_VISUAL);visual_saved=True
            check.run(base.SAVE_TOOL);tool_saved=True
            report['card']=check.load_card(IDENTITY)
            oracle=base.Editor(base.build(IDENTITY));base.prepare(oracle,IDENTITY)
            counts=Counter(foreground(cell)[0] for cell in oracle.document.blocks.values())
            assert len(oracle.document.blocks)==60
            expected={'minecraft:oak_stairs':8,'minecraft:oak_slab':2,'minecraft:trapdoor':8,'minecraft:ladder':4,'minecraft:stone_button':6}
            assert {key:counts[key] for key in expected}==expected
            report.update(fixture_cells=60,direction_samples=28,fixture_material_counts=dict(counts))
            report['initial_data']=base.verify(check,oracle,'actual public T02 initial',report)
            for subject in subjects():
                assert foreground(oracle.document.get(subject['position']))[0]==subject['material']
                assert foreground(oracle.document.get(subject['support']))[0]=='minecraft:stone'
                report['editor_faces'].append(editor_face(subject));save()
            for operation,name in (('mirror_y','button_0'),('rotate_y90','ladder_2')):
                if datetime.now(timezone.utc)>=datetime.fromisoformat('2026-10-21T14:54:00+08:00'):break
                row={'operation':operation,'data':base.transform(check,oracle,operation,evidence=report),'stages':[]}
                report['operations'].append(row);save()
                subject=next(value for value in subjects(operation) if value['name']==name)
                point=tuple(subject['position']);support=tuple(subject['support'])
                assert foreground(oracle.document.get(point))[0]==subject['material']
                assert foreground(oracle.document.get(support))[0]=='minecraft:stone'
                row['subject']=subject
                check.run("sys._t02_face_r26['camera_mutated']=True\n_result=True")
                row['full']=bounded_world(check,'t02_'+operation,point,subject['world_offset'],1.)
                world_restore_workspace()
                token=uuid.uuid4().hex;attempted=False
                try:
                    attempted=True;check.run(missing.INSTALL % ((point,),token))
                    check.run('s.projection_missing=True\nb.project()\n_result=True')
                    check.wait('missing starts',missing.ready,lambda:check.run(missing.STATE))
                    check.run('navigator.pop()\n_result=True')
                    check.wait('world workspace closed',lambda nav:not nav['open'] and not nav['transition'],check.navigation)
                    row['native_camera']=world_pose(subject)
                    time.sleep(.3)
                    target=base.document_semantics(missing.snapshot_document(oracle.document))
                    previous=None
                    for stage,occupied in (('empty',()),('occupied',(point,)),('restored',())):
                        expected_state=[2 if occupied else 1]
                        if previous is not None:
                            check.run('sys._transform_missing_r23_occupied.clear()\nsys._transform_missing_r23_occupied.update(%r)\nfor pos in sys._transform_missing_r23_saved["points"]:b.projection_occupancy.read(pos)\n_result=True' % (occupied,))
                            check.wait('new occupancy commit',lambda state:missing.ready(state) and state['commits']>previous and state['observations']==expected_state,lambda:check.run(missing.STATE))
                        before_cam=check.run('_result=json.dumps({"position":factory.CreateCamera(level).GetPosition(),"rotation":factory.CreateCamera(level).GetCameraRotation()})')
                        record={'label':stage,'expected_observations':expected_state,'camera_before':before_cam}
                        row['stages'].append(record)
                        missing.capture(check,'t02_'+operation+'_missing_'+stage,expected_state,base.document_semantics,target,record)
                        record['camera_after']=check.run('_result=json.dumps({"position":factory.CreateCamera(level).GetPosition(),"rotation":factory.CreateCamera(level).GetCameraRotation()})')
                        assert record['camera_after']==before_cam
                        record['document_verification']=base.verify(check,oracle,operation+':missing:'+stage,report)
                        previous=record['final']['commits'];save()
                    row['missing_completed']=True
                finally:
                    check.run('b.stop_projection()\n_result=True')
                    if attempted:check.run(missing.restore_owned(token))
                    world_restore_workspace()
                    row['observer_restored']=True;save()
                oracle.undo();check.run('assert s.action(s.editor.undo)\n_result=True')
                row['undo']=base.verify(check,oracle,operation+':undo',report);save()
            report['completed']=len(report['editor_faces'])==10 and len(report['operations'])==2 and all(row.get('missing_completed') for row in report['operations'])
        except Exception as error:
            report['error']=type(error).__name__+': '+str(error);report['traceback']=traceback.format_exc()
        finally:
            check.cleaning=True
            try:
                if tool_saved:check.run(base.CANCEL_JOB);check.run(base.RESTORE_TOOL)
                if snapshot:check.run(p.RESTORE_PRE)
                if installed:check.run(blue.RESTORE)
                if tool_saved:check.run('del sys._transform_r23_saved\n_result=True')
                if visual_saved:check.run('del sys._blueprint_visual_saved\n_result=True')
                if snapshot:
                    check.run(p.RESTORE_POST)
                    report['independent_restore_audits']=[]
                    for unused in range(2):
                        report['independent_restore_audits'].append(check.wait('original session restored',lambda row:row['preview_ready'],lambda:check.run(p.AUDIT)))
                        time.sleep(.3)
                    check.run(p.REMOVE_AUDIT);report['restored']=True
            except Exception as error:
                report['restored']=False;report['restore_error']=repr(error);report['restore_traceback']=traceback.format_exc()
            report['source_unchanged']=verify()==manifest;save()
    print(json.dumps({key:report.get(key) for key in ('completed','restored','source_unchanged','error')}))
    return 0 if report['completed'] and report.get('restored') and report['source_unchanged'] else 1

if __name__=='__main__':raise SystemExit(main())
