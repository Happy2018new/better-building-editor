"""Prepare a distinct c531 T02 followup; no game start or production mutation."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = HERE.parent / 't02-normal-cold-v1'
OWNER = 'r26-t02-face-missing-v1'
derivation = {}
for name in ('freeze.py', 'frozen_guard.py', 'launch_owned.py', 'stop_owned.py',
             'close_final_watch.py', 'lifecycle_helpers.py', 'public_entry_host.py',
             'run_transform_final.py', 'payloads.py'):
    original = OLD / name
    source = original.read_text(encoding='utf8')
    source = source.replace('r25-t02-normal-v1', OWNER).replace('t02-normal-cold-v1', 't02-face-missing-cold-v1')
    source = source.replace('_t02_normal_r25', '_t02_face_r26')
    target = HERE / name
    assert not target.exists()
    ast.parse(source)
    target.write_text(source, encoding='utf8')
    derivation[name] = {'original': original.relative_to(ROOT).as_posix(),
                        'original_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
                        'new_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
source = (OLD / 'audit_t04_resume_v2.py').read_text(encoding='utf8')
source = source.replace('r25-t02-normal-v1', OWNER).replace('_t02_normal_r25','_t02_face_r26')
source = source.replace('t02-restore-v2-', 'face-restore-').replace('t02-restore-before.json','face-restore-before.json')
(HERE / 'audit_restore.py').write_text(source, encoding='utf8')
source = (OLD / 'start_watch_resume_v2.py').read_text(encoding='utf8')
source = source.replace('r25-t02-normal-v1', OWNER).replace('2026-10-21T13:35:00+08:00','2026-10-21T14:59:00+08:00')
source = source.replace("resume_reason='Work was interrupted 10:32-12:56; root assigned resumed closeout 13:35 and total 13:50, no frozen source or original host changes.'", "resume_reason='New distinct c531 T02 followup owner; diagnostic watcher SHA separately bound from production runtime.'")
(HERE / 'start_watch.py').write_text(source, encoding='utf8')
source = (OLD / 'check_t02_resume_v2.py').read_text(encoding='utf8').split("original = HERE / 'check_t02.py'")[0]
(HERE / 'strict_controls.py').write_text(source, encoding='utf8')
(HERE / 'derivation.json').write_text(json.dumps({'owner': OWNER,
 'sources': derivation, 'production_changes': False, 'candidate_assignment': False,
 'no_game_started': True, 'cold_commit': 'c531b2f4802577e160b26105c6d73cd8322ff89f'}, indent=2) + '\n', encoding='utf8')
print('New T02 followup hosts prepared; no game launched')
