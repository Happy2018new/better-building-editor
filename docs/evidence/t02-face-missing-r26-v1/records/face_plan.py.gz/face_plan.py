"""Independent attached-cell positions, supports, normals and transform matrices."""
import math

FACES = ((0,-1,0),(0,1,0),(0,0,-1),(0,0,1),(-1,0,0),(1,0,0))
ROWS = [('ladder_%d' % facing, 'minecraft:ladder', facing, (x,3,23))
        for x,facing in zip((3,8,13,18),(2,3,4,5))]
ROWS += [('button_%d' % facing, 'minecraft:stone_button', facing, pos)
         for facing,pos in enumerate(((3,3,27),(8,3,27),(13,3,27),(18,3,27),(3,3,29),(8,3,29)))]

def transform_point(point, operation):
    x,y,z = point
    if operation == 'mirror_y': return x,7-y,z
    if operation == 'rotate_y90': return 31-z,y,x
    return point

def transform_normal(normal, operation):
    x,y,z = normal
    if operation == 'mirror_y': return x,-y,z
    if operation == 'rotate_y90': return -z,y,x
    return normal

def subjects(operation=None):
    result=[]
    for name,material,facing,point in ROWS:
        normal=FACES[facing]
        support=tuple(point[i]-normal[i] for i in range(3))
        target=transform_point(point,operation)
        normal=transform_normal(normal,operation)
        support=transform_point(support,operation)
        assert tuple(target[i]-normal[i] for i in range(3)) == support
        yaw=math.degrees(math.atan2(normal[0],normal[2])) if normal[1]==0 else 35.
        pitch=80.*normal[1] if normal[1] else 5.
        offset=tuple(4.*value for value in normal)
        if normal[1]: offset=(.6,offset[1],.8)
        result.append({'name':name,'material':material,'original_facing':facing,
                       'original_position':point,'position':target,'normal':normal,'support':support,
                       'editor_yaw':yaw,'editor_pitch':pitch,'world_offset':offset})
    return result
