# -*- coding: utf-8 -*-
"""Run the new public fixtures through true Py2/Py3, no engine imports or writes."""
from __future__ import print_function, unicode_literals
import hashlib
import json
import os
import sys

root = os.getcwdu() if sys.version_info[0] == 2 else os.getcwd()
sys.path.insert(0, os.path.join(root, 'behavior_pack', 'modern_projection'))
from projection.debug_transform_acceptance import build, PREFIX, prepare
from projection.model import Document, Editor
from projection.cell import encode_cell

operations = ('rotate_y90', 'rotate_y180', 'rotate_y270', 'mirror_x', 'mirror_y', 'mirror_z')
inverse = dict(zip(operations, ('rotate_y270', 'rotate_y180', 'rotate_y90', 'mirror_x', 'mirror_y', 'mirror_z')))


def fingerprint(document):
    data = {'size': document.size, 'name': document.name, 'biome': document.biome,
            'cells': [(pos, encode_cell(cell)) for pos, cell in sorted(document.blocks.items())]}
    raw = json.dumps(data, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode('ascii')
    return hashlib.sha256(raw).hexdigest()


rows = []
for short in ('t03', 't03_half', 't06'):
    identity = PREFIX + short
    document = build(identity)
    initial = fingerprint(document)
    reopened = Document.from_data(json.loads(json.dumps(document.to_data())))
    assert fingerprint(reopened) == initial
    row = {'identity': identity, 'cells': len(document.blocks), 'document_sha256': initial,
           'reload_equal': True, 'operations': []}
    for operation in operations:
        editor = Editor(build(identity))
        assert prepare(editor, identity)
        selected = sorted(editor.selection)
        editor.run(operation)
        changed = fingerprint(editor.document)
        transformed_selection = sorted(editor.selection)
        if editor.undo_stack:
            assert editor.undo()
            assert fingerprint(editor.document) == initial
            assert sorted(editor.selection) == selected
            assert editor.redo()
            assert fingerprint(editor.document) == changed
            assert sorted(editor.selection) == transformed_selection
        editor.run(inverse[operation])
        assert fingerprint(editor.document) == initial
        assert sorted(editor.selection) == selected
        row['operations'].append({'operation': operation, 'transformed_sha256': changed,
                                  'selection': transformed_selection, 'inverse_restored': True})
    rows.append(row)
output = {'schema': 1, 'scope': 'offline public fixtures typed data and transactions only',
          'manual_issues_closed': 0, 'fixtures': rows}
with open(sys.argv[1], 'w') as stream:
    stream.write(json.dumps(output, ensure_ascii=True, sort_keys=True, indent=2) + '\n')
print('Passed 3 public fixtures x 6 transforms, typed reload, inverse and available undo/redo.')
