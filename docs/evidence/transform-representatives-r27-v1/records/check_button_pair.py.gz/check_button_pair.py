"""Keep the public T02 document identity/volume; erase only unrelated cells and undo."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import check_runtime as original
from check_runtime import (Check, OWNER, PROJECT, PREFIX, base, blue, p, pose,
                           native_material, NATIVE_SNAPSHOT, verify, Client, load_session)

OUT = HERE / 'button-pair'
manifest = verify()
probe = blue.INSTALL_PROBE
needle = '  data=palette.SerializeBlockPalette()\n'
assert probe.count(needle) == 1
probe = probe.replace(needle, needle +
    '  import hashlib\n'
    '  from modern_projection.projection.bridge import _stable_palette\n'
    '  serialized_repr=repr(_stable_palette(data))\n'
    '  serialized_sha256=hashlib.sha256(serialized_repr.encode("utf8")).hexdigest()\n')
needle = "   'volume':data.get('volume'),"
assert probe.count(needle) == 1
probe = probe.replace(needle,
    "   'serialized_palette_repr':serialized_repr,'serialized_palette_sha256':serialized_sha256,\n" + needle)


def main():
    binding = load_session(Path(json.loads((HERE / 'launch/report.json').read_bytes())['session_file']), OWNER, live=True)
    assert Path(binding['project']).resolve() == PROJECT.resolve()
    os.environ.update(MCDEV_SESSION_FILE=binding['session_file'], MCDEV_OWNER=OWNER,
                      MCDEV_MCP_URL=binding['mcp_url'], MCDEV_GAME_PID=str(binding['game_pid']),
                      MCDEV_ALLOW_USER_FOREGROUND='0')
    OUT.mkdir(exist_ok=False)
    report = {'owner': OWNER, 'source_commit': manifest['source_commit'], 'completed': False,
              'manual_issues_closed': 0, 'world_write_performed': False,
              'candidate_profile_assignment': False, 'original_driver_unchanged': True,
              'source_manifest_sha256': hashlib.sha256((HERE / 'source-manifest.json').read_bytes()).hexdigest(),
              'existing_probe_sha256': hashlib.sha256(blue.INSTALL_PROBE.encode()).hexdigest(),
              'read_only_sha_probe_sha256': hashlib.sha256(probe.encode()).hexdigest(),
              'stages': []}
    def save():
        (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
    save()
    installed = snapshot = tool_saved = visual_saved = False
    with Client(timeout=35) as client:
        check = Check(client, OUT, binding, report)
        try:
            report['baseline'] = check.run(p.SNAPSHOT)
            snapshot = True
            check.run(probe)
            installed = True
            check.run(base.SAVE_VISUAL)
            visual_saved = True
            check.run(base.SAVE_TOOL)
            tool_saved = True
            report['card'] = check.load_card(PREFIX + 't02')
            oracle = base.Editor(base.build(PREFIX + 't02'))
            base.prepare(oracle, PREFIX + 't02')
            report['before'] = base.verify(check, oracle, 'T02 pair before erase', report)
            original_document = base.document_semantics(oracle.document.to_data())
            keep = ((3, 3, 27), (3, 4, 27))
            remove = sorted(set(oracle.document.blocks) - set(keep))
            assert len(remove) == 58
            report['pose'] = pose(check, (3, 3, 27), 35., -80., 12., 'pair_pose', capture=False)
            stable = check.run('_result=json.dumps({"document_id":id(s.editor.document),"size":s.editor.document.size,"editor_id":id(s.editor),"camera_pose":s.camera_pose,"camera_pivot":s.camera_pivot,"camera_pan":s.camera_pan})')
            oracle.selection = set(remove)
            oracle.sync_selection_bounds()
            oracle.run('erase')
            erased = check.run('s.editor.selection=set(%r)\ns.editor.sync_selection_bounds()\nassert s.action(lambda:s.editor.run("erase"))\nsys._blueprint_qa_expected["metadata"]={"name":s.editor.document.name,"size":s.editor.document.size,"blocks":len(s.editor.document.blocks)}\n_result=json.dumps({"cells":len(s.editor.document.blocks),"undo":len(s.editor.undo_stack)})' % (remove,))
            assert erased == {'cells': 2, 'undo': 1}, erased
            report['erase'] = {'removed': remove, 'data': base.verify(check, oracle, 'only pair retained', report)}
            assert set(oracle.document.blocks) == set(keep)
            previous = 0
            for label, mode in (('A_full', 'full'), ('B_single_y3', 'single'), ('A2_full', 'full')):
                check.run('s.layer(3)\ns.display_mode(%r)\n_result=True' % mode)
                ready = check.editor_preview('only pair ' + label)
                state = check.run(NATIVE_SNAPSHOT)
                assert base.document_semantics(state['document']) == base.document_semantics(oracle.document.to_data())
                actual = {key: state[key] for key in ('document_id', 'editor_id', 'camera_pose', 'camera_pivot', 'camera_pan')}
                assert actual == {key: stable[key] for key in actual}, (actual, stable)
                assert state['document']['size'] == stable['size']
                button, support = native_material(state, keep[0]), native_material(state, keep[1])
                assert button['material'] == ['minecraft:stone_button', 0]
                assert support['material'] == (None if mode == 'single' else ['minecraft:stone', 0])
                for part in state['parts']:
                    native_call = part['native_call']
                    raw = native_call['serialized_palette_repr'].encode('utf8')
                    assert hashlib.sha256(raw).hexdigest() == native_call['serialized_palette_sha256']
                report['stages'].append({'label': label, 'snapshot': state, 'button': button,
                    'support': support, 'ready': ready, 'new_native_record_count': state['native_records_count'] - previous,
                    'capture': check.capture('button_pair_' + label), 'pixels_accepted': False})
                previous = state['native_records_count']
                save()
            assert oracle.undo()
            check.run('assert s.action(s.editor.undo)\nsys._blueprint_qa_expected["metadata"]={"name":s.editor.document.name,"size":s.editor.document.size,"blocks":len(s.editor.document.blocks)}\n_result=True')
            report['erase_undo'] = base.verify(check, oracle, 'all original 60 typed cells restored', report)
            assert base.document_semantics(oracle.document.to_data()) == original_document
            report['same_document_id_after_undo'] = check.run('_result=id(s.editor.document)') == stable['document_id']
            assert report['same_document_id_after_undo']
            report['A2_reuses_A_model'] = report['stages'][0]['button']['name'] == report['stages'][2]['button']['name']
            report['completed'] = True
        except Exception as error:
            report['error'] = type(error).__name__ + ': ' + str(error)
            report['traceback'] = traceback.format_exc()
        finally:
            check.cleaning = True
            try:
                if tool_saved:
                    check.run(base.CANCEL_JOB)
                    check.run(base.RESTORE_TOOL)
                if snapshot:
                    check.run(p.RESTORE_PRE)
                if installed:
                    check.run(blue.RESTORE)
                if tool_saved:
                    check.run('del sys._transform_r23_saved\n_result=True')
                if visual_saved:
                    check.run('del sys._blueprint_visual_saved\n_result=True')
                if snapshot:
                    check.run(p.RESTORE_POST)
                    report['restore_audits'] = []
                    for unused in range(2):
                        report['restore_audits'].append(check.wait('original session restored', lambda row: row['preview_ready'], lambda: check.run(p.AUDIT)))
                        time.sleep(.3)
                    check.run(p.REMOVE_AUDIT)
                    report['restored'] = True
            except Exception as error:
                report['restored'] = False
                report['restore_error'] = repr(error)
                report['restore_traceback'] = traceback.format_exc()
            report['source_unchanged'] = verify() == manifest
            save()
    print(json.dumps({key: report.get(key) for key in ('completed', 'restored', 'source_unchanged', 'error')}))
    return 0 if report['completed'] and report.get('restored') and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
