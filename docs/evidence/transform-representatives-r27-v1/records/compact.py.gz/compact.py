"""Archive exact R27 transform evidence with explicit credential and image derivatives."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

from PIL import Image
from frozen_guard import verify

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = ROOT / 'docs/evidence/transform-representatives-r27-v1'
manifest = verify()
assert not OUT.exists()
OUT.mkdir(parents=True)
(OUT / 'records').mkdir()
(OUT / 'images').mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda rel: json.loads((HERE / rel).read_bytes())
runs = {name: read(name + '/report.json') for name in
        ('check', 'check-v2', 'check-v3', 'check-v4', 'button-pair')}
stop = read('stop/report.json')
secrets = set()


def tokens(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in ('token', 'api_key', 'authorization') and isinstance(item, str) and item:
                secrets.add(item)
            tokens(item)
    elif isinstance(value, list):
        for item in value:
            tokens(item)


tokens(stop)
tokens(read('launch/report.json'))
index = {'owner': manifest['owner'], 'source_commit': manifest['source_commit'],
         'created_at': datetime.now(timezone.utc).isoformat(), 'manual_issues_closed': 0,
         'records': [], 'images': [], 'local_only_ui_trees': [], 'per_file_limit_bytes': 300000}
sources = list(HERE.glob('*.py')) + list(HERE.glob('*.json'))
for name in runs:
    sources += list((HERE / name).glob('*.json'))
sources += [HERE / rel for rel in ('launch/report.json', 'launch/exact-exit.json',
                                   'stop/report.json', 'assert-watch/status.json')]
for source in sorted(set(sources)):
    raw = source.read_bytes()
    rel = source.relative_to(HERE).as_posix()
    if source.name.endswith('.tree.json'):
        index['local_only_ui_trees'].append({
            'raw': source.relative_to(ROOT).as_posix(), 'raw_sha256': sha(raw), 'raw_bytes': len(raw),
            'local_only': True,
            'reason': 'Complete native UI tree retained locally; public callback and semantic records are archived separately.'})
        continue
    decoded = raw
    if source.suffix == '.json':
        for secret in sorted(secrets, key=len, reverse=True):
            decoded = decoded.replace(secret.encode(), b'<redacted>')
        json.loads(decoded)
    name = rel.replace('/', '__')
    if decoded != raw:
        name = name.replace('.json', '.redacted.json')
    target = OUT / 'records' / (name + '.gz')
    packed = gzip.compress(decoded, compresslevel=9, mtime=0)
    assert gzip.decompress(packed) == decoded
    assert len(packed) < 300000, rel
    target.write_bytes(packed)
    index['records'].append({
        'raw': source.relative_to(ROOT).as_posix(), 'raw_sha256': sha(raw), 'raw_bytes': len(raw),
        'archived': target.relative_to(OUT).as_posix(), 'archive_sha256': sha(packed),
        'archive_bytes': len(packed), 'archive_decoded_sha256': sha(decoded),
        'archive_decodes_to_original_raw': decoded == raw,
        'credential_redacted_derived_archive': decoded != raw, 'encoding': 'gzip'})

opened = ['check/' + name + '.png' for name in ('t02_A_full', 't02_B_single_y3', 't02_A2_full')]
opened += ['check-v2/' + name + '.png' for name in
           ('t03_before', 't03_after', 't03_world_closeup', 't03_missing_empty',
            't03_missing_single_half', 't03_missing_occupied', 't03_missing_restored')]
opened += ['check-v4/' + name + '.png' for name in
           ('t06_before', 't06_after', 't06_world_closeup', 't06_missing_empty',
            't06_missing_occupied', 't06_missing_restored')]
opened.append('check-v3/t03_half_before.png')
notes = {
    'opened_raw_images': opened,
    'manual_acceptance': False,
    'manual_issues_closed': 0,
    't02': 'Full and A2 show the support face with button obscured. Single Y3 shows button thickness. Actual submitted aux0 remains intact. Mesh/depth/scene cause unresolved.',
    't03': 'Representative editor/full and controlled missing images opened. Both target door halves vanish under occupied and return together; support and other door remain. Some overview objects clipped; no full visual matrix claimed.',
    't06': 'Representative editor/full and controlled missing images opened. Center pane vanishes under occupied and returns; neighboring panes/bars/wall/gate persist. Some stairs clipped; no complete stair appearance matrix claimed.',
    't03_half': 'Only before editor image exists for v3. After transform precheck blocked; no after/full/missing qualification.',
    'two_cell_button': 'Initial public T02 load failed before erase. No two-cell A/B/A screenshots; experiment not performed.',
    'reopened_after_context_resume': ['check-v2/t03_missing_occupied.png', 'check-v2/t03_missing_restored.png',
                                      'check-v4/t06_missing_occupied.png', 'check-v4/t06_missing_restored.png']}
(HERE / 'visual-review.json').write_text(json.dumps(notes, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
raw = (HERE / 'visual-review.json').read_bytes()
packed = gzip.compress(raw, compresslevel=9, mtime=0)
(OUT / 'records/visual-review.json.gz').write_bytes(packed)
index['records'].append({'raw': (HERE / 'visual-review.json').relative_to(ROOT).as_posix(),
                         'raw_sha256': sha(raw), 'raw_bytes': len(raw),
                         'archived': 'records/visual-review.json.gz', 'archive_sha256': sha(packed),
                         'archive_bytes': len(packed), 'archive_decoded_sha256': sha(raw),
                         'archive_decodes_to_original_raw': True,
                         'credential_redacted_derived_archive': False, 'encoding': 'gzip'})
for run in runs:
    for source in sorted((HERE / run).glob('*.png')):
        label = run + '__' + source.stem
        target = OUT / 'images' / (label + '.jpg')
        with Image.open(source) as image:
            original_size = list(image.size)
            image = image.convert('RGB')
            image.thumbnail((1280, 800))
            image.save(target, 'JPEG', quality=83, optimize=True)
            review_size = list(image.size)
        assert target.stat().st_size < 300000
        index['images'].append({
            'label': label, 'raw': source.relative_to(ROOT).as_posix(),
            'raw_sha256': sha(source.read_bytes()), 'raw_bytes': source.stat().st_size,
            'raw_size': original_size, 'review_jpeg': target.relative_to(OUT).as_posix(),
            'review_sha256': sha(target.read_bytes()), 'review_size': review_size,
            'review_bytes': target.stat().st_size, 'lossy_derivative': True,
            'agent_opened_raw_image': source.relative_to(HERE).as_posix() in opened,
            'human_acceptance': False})


def representative(run):
    row = runs[run]['representatives'][0]
    return {'identity': row['identity'], 'operation': row['operation'],
            'completed': row.get('completed', False), 'typed_initial': row['initial_data'],
            'typed_transform': row['transform'], 'typed_undo': row.get('undo'),
            'points': row.get('points'), 'editor_before_and_after_captured':
                'before_editor' in row and 'after_editor' in row,
            'full_native_evidence': row.get('full', {}).get('native_evidence'),
            'full_native_calls': len(row.get('full', {}).get('native_calls', [])),
            'missing_completed': row.get('missing_completed', False),
            'observer_restored': row.get('observer_restored', False),
            'stages': [{'label': st['label'], 'observations': st['final']['observations'],
                        'commits': st['final']['commits'],
                        'typed_equal': st['typed_document']['equal'],
                        'player_stable': st['state']['player'] == st['final']['player'],
                        'snapshot_preserved': st['final']['snapshot_preserved'],
                        'document_preserved': st['final']['document_preserved'],
                        'source': st['source'], 'pixels_accepted': False}
                       for st in row.get('stages', [])], 'manual_acceptance': False}


t02 = runs['check']['t02']
summary = {
    'owner': manifest['owner'], 'source_commit': manifest['source_commit'],
    'source_manifest_sha256': sha((HERE / 'source-manifest.json').read_bytes()),
    'source_unchanged': verify() == manifest, 'manual_issues_closed': 0,
    'manual_acceptance': False, 'candidate_profile_assignment': False,
    'world_write_performed': False, 'native_world_occupancy': False,
    'actual_public_card_callbacks': True,
    'run_outcomes': {name: {'completed': run['completed'], 'restored': run.get('restored', False),
                           'source_unchanged': run.get('source_unchanged', False),
                           'error': run.get('error'), 'representatives_completed':
                           [r['identity'] for r in run.get('representatives', []) if r.get('completed')]}
                     for name, run in runs.items()},
    't02_actual_full_single_full': {
        'completed': t02['completed'], 'document_modified': t02['document_modified'],
        'button_survives_actual_native_submission': t02['button_survives_actual_native_submission'],
        'A2_reuses_A_model': t02['A2_reuses_A_model'],
        'stages': [{k: st[k] for k in ('label', 'button', 'support', 'new_native_record_count')}
                   for st in t02['stages']], 'full_visibility_resolved': False},
    't03': representative('check-v2'), 't06': representative('check-v4'),
    't03_half': {'typed_transform_equal': runs['check-v3']['representatives'][0]['transform']['equal'],
                 'runtime_after_precheck_blocked': True,
                 'full_or_missing_completed': False,
                 'prior_nonce_relaxation_does_not_qualify_native_cache_reuse': True,
                 'requires': 'Bind prior immutable model, full prepared/serialized palette and current source/cache/signature before qualifying reuse.'},
    'two_cell_button': {'completed': False, 'erase_executed': False,
                        'captured_ab_a_images': 0, 'error': runs['button-pair']['error'],
                        'restored': runs['button-pair']['restored']},
    'independent_restore': {phase: {k: read('face-restore-' + phase + '.json').get(k)
                                   for k in ('completed', 'changed_keys', 'source_unchanged', 'camera_rotation_delta')}
                            for phase in ('before', 'after1', 'after2', 'after3')},
    'lifecycle': {'ordinary_stop_and_finalize_completed': stop['completed'],
                  'registry_state': stop['registry_final']['state'],
                  'actual_exit_codes': stop['actual_exit_codes'],
                  'game_exit_code_hex': '0x%08X' % stop['actual_exit_codes']['game'],
                  'normal_shutdown_qualified': stop['normal_shutdown_qualified'],
                  'force_executed': stop['force_executed'],
                  'watcher_retired': read('assert-watch-close.json')['completed'],
                  'known_assertions': read('assert-watch/status.json')['known_assert_recoveries'],
                  'other_assertions': read('assert-watch/status.json')['other_assertions']},
    'visual_review': notes,
    'raw_evidence_retained': True,
    'credential_redaction': 'Local raw retained. Marked derived archives redact credentials; raw, archive and decoded SHA values recorded separately.',
    'image_derivatives': 'JPEG previews are lossy. Exact original PNGs remain local with original SHA values.'}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
index['summary_sha256'] = sha((OUT / 'summary.json').read_bytes())
(OUT / 'index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
files = [x for x in OUT.rglob('*') if x.is_file()]
assert all(x.stat().st_size < 300000 for x in files)
assert not any(secret.encode() in x.read_bytes() for secret in secrets for x in files)
print(json.dumps({'output': str(OUT), 'records': len(index['records']), 'images': len(index['images']),
                  'local_only_ui_trees': len(index['local_only_ui_trees']),
                  'largest_file_bytes': max(x.stat().st_size for x in files),
                  'total_bytes': sum(x.stat().st_size for x in files),
                  'redacted_records': sum(x['credential_redacted_derived_archive'] for x in index['records']),
                  'index_sha256': sha((OUT / 'index.json').read_bytes())}))
