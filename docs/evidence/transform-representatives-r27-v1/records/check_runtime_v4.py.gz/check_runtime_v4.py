"""Cold public T03/T06 representatives and the bounded T02 native-submit A/B/A."""
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OWNER = 'r27-transform-runtime-v1'
PROJECT = ROOT / '.runtime/projects' / OWNER
sys.path[:0] = [str(PROJECT / '.agents/skills/pyreact-debugging/scripts'), str(PROJECT / 'tools')]
from _session import load_session
from mcdk import Client
import verify_debug_blueprints as blue
import verify_transform_runtime_r23 as base
import transform_missing_r23 as missing
from run_transform_final import bounded_world
import public_entry_host as entry
import strict_controls
from frozen_guard import verify
import payloads as p
from projection.cell import foreground
from projection import block_registry as registry

OUT = HERE / 'check-v4'
PREFIX = 'test.transforms.acceptance.'
manifest = verify()


class Check(entry.EntryCheck):
    def guard(self):
        super().guard()
        if self.cleaning:
            return
        assert datetime.now(timezone.utc) < datetime.fromisoformat('2026-10-22T07:30:00+08:00')
        status = json.loads((HERE / 'assert-watch/status.json').read_bytes())
        assert status['owners'] == [OWNER]
        assert status['host_sha256'] == manifest['host_files']['tools/watch_owned_disabled_skin_assert_r20.py']
        assert (datetime.now(timezone.utc) - datetime.fromisoformat(status['checked_at'])).total_seconds() < 5
        assert not status['errors'] and not status['other_assertions'], status

    def run(self, code):
        return super().run(p.CLIENT + code)


NATIVE_SNAPSHOT = '''rows=[]
for key,part in sorted(s.tiles.parts.items()):
 if key not in s.tiles.region_owners or not part.get('name'):continue
 calls=[row for row in sys._blueprint_qa_records if row.get('result')==part['name']]
 assert calls,(key,part['name'])
 rows.append({'key':key,'origin':part['origin'],'size':part['size'],'name':part['name'],
  'signature_current':part['signature']==s.preview_signature(),'native_call':calls[-1]})
assert rows and all(row['signature_current'] for row in rows)
_result=json.dumps({'document':s.editor.document.to_data(),'document_id':id(s.editor.document),
 'editor_id':id(s.editor),'view':s.view,'layer':s.editor.layer,'solo_layer':s.solo_layer,
 'camera_pose':s.camera_pose,'camera_pivot':s.camera_pivot,'camera_pan':s.camera_pan,
 'native_records_count':len(sys._blueprint_qa_records),'parts':rows})
'''


def native_material(snapshot, point):
    matches = []
    for part in snapshot['parts']:
        local = tuple(point[i] - part['origin'][i] for i in range(3))
        if not all(0 <= local[i] < part['size'][i] for i in range(3)):
            continue
        call = part['native_call']
        sz, sx, sy = call['volume']
        index = local[1] * sx * sz + local[0] * sz + local[2]
        values = [row['material'] for row in call['submitted_materials'] if index in row['indices']]
        assert len(values) <= 1, values
        matches.append({'part': part['key'], 'name': part['name'], 'local': local,
                        'native_volume': call['volume'], 'native_index': index,
                        'material': values[0] if values else None, 'native_result': call['result']})
    assert len(matches) == 1, matches
    return matches[0]


def pose(check, focus, yaw, pitch, zoom, label, capture=True):
    check.run('s.grid=False\ns.focused=%r\ns.camera_focus_request=%r\n_result=True' %
              (tuple(focus), tuple(value + .5 for value in focus)))
    check.wait('focus consumed ' + label, lambda row: row['request'] is None and row['pivot'] is not None,
               lambda: check.run('_result=json.dumps({"request":s.camera_focus_request,"pivot":s.camera_pivot})'))
    check.run('s.camera_view(%r,%r,%r)\n_result=True' % (yaw, pitch, zoom))
    previous = [None]
    def stable(row):
        near = (abs((row['pose'][0] - yaw + 180.) % 360. - 180.) < .03 and
                abs(row['pose'][1] - pitch) < .03 and abs(row['pose'][2] - zoom) < .003)
        same, previous[0] = row == previous[0], row
        return near and same
    state = check.wait('two equal actual poses ' + label, stable, lambda: check.run(
        '_result=json.dumps({"pose":s.camera_pose,"pivot":s.camera_pivot,"pan":s.camera_pan})'))
    check.editor_preview('pose settled ' + label)
    return {'actual': state, 'requested': (yaw, pitch, zoom),
            'capture': check.capture(label) if capture else None}


def t02(check, report, save):
    row = {'identity': PREFIX + 't02', 'single_variable': 'display full/single layer Y3/full',
           'document_modified': False, 'stages': []}
    report['t02'] = row
    row['card'] = check.load_card(PREFIX + 't02')
    oracle = base.Editor(base.build(PREFIX + 't02'))
    base.prepare(oracle, PREFIX + 't02')
    row['initial_data'] = base.verify(check, oracle, 'T02 public baseline', report)
    row['pose'] = pose(check, (3, 3, 27), 35., -80., 12., 't02_pose', capture=False)
    fixed = None
    count = 0
    for label, mode in (('A_full', 'full'), ('B_single_y3', 'single'), ('A2_full', 'full')):
        check.run('s.layer(3)\ns.display_mode(%r)\n_result=True' % mode)
        ready = check.editor_preview('T02 native A/B/A ' + label)
        snapshot = check.run(NATIVE_SNAPSHOT)
        semantic = base.document_semantics(snapshot['document'])
        assert semantic == base.document_semantics(oracle.document.to_data())
        current = {key: snapshot[key] for key in ('document_id', 'editor_id', 'camera_pose',
                                                  'camera_pivot', 'camera_pan')}
        if fixed is None:
            fixed = current
        assert fixed == current, (fixed, current)
        button, support = native_material(snapshot, (3, 3, 27)), native_material(snapshot, (3, 4, 27))
        assert button['material'] == ['minecraft:stone_button', 0], button
        assert registry.states(tuple(button['material'])) == {'facing_direction': 0, 'button_pressed_bit': False}
        assert support['material'] == (None if mode == 'single' else ['minecraft:stone', 0]), support
        stage = {'label': label, 'snapshot': snapshot, 'ready': ready, 'button': button,
                 'support': support, 'new_native_record_count': snapshot['native_records_count'] - count,
                 'capture': check.capture('t02_' + label), 'pixels_accepted': False}
        count = snapshot['native_records_count']
        row['stages'].append(stage)
        save()
    row['A2_reuses_A_model'] = row['stages'][0]['button']['name'] == row['stages'][2]['button']['name']
    row['button_survives_actual_native_submission'] = True
    row['completed'] = True
    save()


def workspace(check):
    check.run('b.stop_projection()\nowner.open_workspace()\n_result=True')
    check.wait('workspace restored', lambda nav: nav['open'] and not nav['transition'], check.navigation)


def representative(check, report, short, operation, originals, save):
    identity = PREFIX + short
    row = {'identity': identity, 'operation': operation, 'stages': [], 'manual_acceptance': False}
    report['representatives'].append(row)
    row['card'] = check.load_card(identity)
    oracle = base.Editor(base.build(identity))
    base.prepare(oracle, identity)
    row['initial_data'] = base.verify(check, oracle, short + ' public baseline', report)
    row['before_editor'] = pose(check, base.CASES[identity]['focus'], 35., 25., 4., short + '_before')
    row['transform'] = base.transform(check, oracle, operation, evidence=report)
    row['after_editor'] = pose(check, base.CASES[identity]['focus'], 35., 25., 4., short + '_after')
    lo, hi = base.CASES[identity]['selection']
    points = tuple((lo[0] + hi[2] - point[2], point[1], lo[2] + point[0] - lo[0])
                   if operation == 'rotate_y90' else
                   (hi[0] + lo[0] - point[0], point[1], point[2]) for point in originals)
    row['points'] = points
    focus = points[0]  # Integer native cell anchor; camera target adds .5 separately.
    offset = (-5., 4., -7.)
    check.run("sys._transforms_r27['camera_mutated']=True\n_result=True")
    row['full'] = bounded_world(check, short, focus, offset, 1.)
    workspace(check)
    save()
    token = uuid.uuid4().hex
    attempted = False
    try:
        attempted = True
        check.run(missing.INSTALL % (points, token))
        check.run('s.projection_missing=True\nb.project()\n_result=True')
        check.wait('controlled missing starts', missing.ready, lambda: check.run(missing.STATE))
        check.run('navigator.pop()\n_result=True')
        check.wait('world workspace closed', lambda nav: not nav['open'] and not nav['transition'], check.navigation)
        row['native_camera'] = check.run('focus=%r\noffset=%r\ntarget=tuple(s.origin[i]+focus[i]+.5 for i in range(3))\nposition=tuple(target[i]+offset[i] for i in range(3))\nrotation=api.GetRotFromDir(tuple(target[i]-position[i] for i in range(3)))\ncam=factory.CreateCamera(level)\ncam.DepartCamera()\ncam.LockModCameraPitch(True)\ncam.LockModCameraYaw(True)\nassert cam.SetCameraPos(position)\nassert cam.SetCameraRotation((rotation[0],rotation[1]+180.,0.))\n_result=json.dumps({"target":target,"position":cam.GetPosition(),"rotation":cam.GetCameraRotation()})' % (focus, offset))
        stages = [('empty', ())]
        if len(points) > 1:
            stages.append(('single_half', points[:1]))
        stages.extend((('occupied', points), ('restored', ())))
        previous = None
        target = base.document_semantics(missing.snapshot_document(oracle.document))
        for label, occupied in stages:
            expected = [2 if point in occupied else 1 for point in points]
            if previous is not None:
                check.run('sys._transform_missing_r23_occupied.clear()\nsys._transform_missing_r23_occupied.update(%r)\nfor pos in sys._transform_missing_r23_saved["points"]:b.projection_occupancy.read(pos)\n_result=True' % (occupied,))
                check.wait('new occupancy commit', lambda state: missing.ready(state) and state['commits'] > previous and state['observations'] == expected, lambda: check.run(missing.STATE))
            record = {'label': label, 'expected_observations': expected}
            row['stages'].append(record)
            missing.capture(check, short + '_missing_' + label, expected, base.document_semantics, target, record)
            record['typed_document'] = base.verify(check, oracle, short + ':missing:' + label, report)
            previous = record['final']['commits']
            save()
        row['missing_completed'] = True
    finally:
        check.run('b.stop_projection()\n_result=True')
        if attempted:
            check.run(missing.restore_owned(token))
        workspace(check)
        row['observer_restored'] = True
        save()
    assert oracle.undo()
    check.run('assert s.action(s.editor.undo)\n_result=True')
    row['undo'] = base.verify(check, oracle, short + ':undo', report)
    row['completed'] = True
    save()


def main():
    binding = load_session(Path(json.loads((HERE / 'launch/report.json').read_bytes())['session_file']), OWNER, live=True)
    assert Path(binding['project']).resolve() == PROJECT.resolve()
    os.environ.update(MCDEV_SESSION_FILE=binding['session_file'], MCDEV_OWNER=OWNER,
                      MCDEV_MCP_URL=binding['mcp_url'], MCDEV_GAME_PID=str(binding['game_pid']), MCDEV_ALLOW_USER_FOREGROUND='0')
    OUT.mkdir(exist_ok=False)
    report = {'owner': OWNER, 'source_commit': manifest['source_commit'], 'completed': False,
              'manual_issues_closed': 0, 'candidate_profile_assignment': False,
              'world_write_performed': False, 'native_world_occupancy': False,
              'actual_public_card_callbacks': True, 'representatives': [],
              'source_manifest_sha256': hashlib.sha256((HERE / 'source-manifest.json').read_bytes()).hexdigest(),
              'started_at': datetime.now(timezone.utc).isoformat()}
    def save():
        (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
    save()
    installed = snapshot = tool_saved = visual_saved = False
    with Client(timeout=35) as client:
        check = Check(client, OUT, binding, report)
        try:
            report['baseline'] = check.run(p.SNAPSHOT)
            snapshot = True
            check.run(blue.INSTALL_PROBE)
            installed = True
            check.run(base.SAVE_VISUAL)
            visual_saved = True
            check.run(base.SAVE_TOOL)
            tool_saved = True
            report['t02_previous_run'] = {'report': str(HERE / 'check/report.json'), 'sha256': hashlib.sha256((HERE / 'check/report.json').read_bytes()).hexdigest(), 'repeated': False}
            for args in (('t06', 'rotate_y90', ((15, 2, 22),)),):
                representative(check, report, *args, save)
            report['completed'] = True
        except Exception as error:
            report['error'] = type(error).__name__ + ': ' + str(error)
            report['traceback'] = traceback.format_exc()
        finally:
            check.cleaning = True
            try:
                if tool_saved:
                    check.run(base.CANCEL_JOB)
                    check.run(base.RESTORE_TOOL)
                if snapshot:
                    check.run(p.RESTORE_PRE)
                if installed:
                    check.run(blue.RESTORE)
                if tool_saved:
                    check.run('del sys._transform_r23_saved\n_result=True')
                if visual_saved:
                    check.run('del sys._blueprint_visual_saved\n_result=True')
                if snapshot:
                    check.run(p.RESTORE_POST)
                    report['independent_restore_audits'] = []
                    for unused in range(2):
                        report['independent_restore_audits'].append(check.wait('original session restored', lambda row: row['preview_ready'], lambda: check.run(p.AUDIT)))
                        time.sleep(.3)
                    check.run(p.REMOVE_AUDIT)
                    report['restored'] = True
            except Exception as error:
                report['restored'] = False
                report['restore_error'] = repr(error)
                report['restore_traceback'] = traceback.format_exc()
            report['source_unchanged'] = verify() == manifest
            save()
    print(json.dumps({key: report.get(key) for key in ('completed', 'restored', 'source_unchanged', 'error')}))
    return 0 if report['completed'] and report.get('restored') and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
