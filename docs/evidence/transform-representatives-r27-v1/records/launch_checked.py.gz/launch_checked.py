"""Fresh exact-owner assertion observer gate around the unchanged frozen launcher."""
from datetime import datetime,timezone
import hashlib,json,runpy
from pathlib import Path
HERE=Path(__file__).resolve().parent
from frozen_guard import verify
manifest=verify()
status=json.loads((HERE/'assert-watch/status.json').read_bytes())
age=(datetime.now(timezone.utc)-datetime.fromisoformat(status['checked_at'])).total_seconds()
assert 0<=age<5,status['checked_at']
assert status['owners']==[manifest['owner']]
assert status['host_sha256']==manifest['host_files']['tools/watch_owned_disabled_skin_assert_r20.py']
assert not status['errors'] and not status['other_assertions'],status
report={'started_at':datetime.now(timezone.utc).isoformat(),'watch_status_age_seconds':age,
 'watch_owner_exact':True,'watch_host_sha256':status['host_sha256'],
 'no_errors_or_other_assertions':True,'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'frozen_launcher_unchanged':True,'production_changes':False}
target=HERE/'launch-checked-receipt.json';assert not target.exists()
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
runpy.run_path(str(HERE/'launch_owned.py'),run_name='__main__')
