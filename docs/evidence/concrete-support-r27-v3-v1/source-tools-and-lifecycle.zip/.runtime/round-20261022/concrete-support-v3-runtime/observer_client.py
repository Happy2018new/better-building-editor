"""Read-only native receipts; complete values exported, hashes stay on host."""
import base64
import json
import sys
from modern_projection.projection.cell import freeze, encode as encode_cell
from modern_projection.projection.storage import integer_types


def concrete_wire(value):
    def plain(item):
        if isinstance(item, dict):
            return dict((key, plain(child)) for key, child in item.items())
        if isinstance(item, (list, tuple)):
            return tuple(plain(child) for child in item)
        if type(item).__name__ == 'IntegerBuffer':
            return ('IntegerBuffer-values', tuple(item))
        return item
    raw = repr(freeze(plain(value), budget=[1000000, 64 * 1024 * 1024])).encode('utf8')
    return {'codec': 'cell.freeze-repr-utf8-base64',
            'base64': base64.b64encode(raw).decode('ascii'), 'bytes': len(raw)}


def concrete_document(doc):
    return concrete_wire({'size': doc.size, 'biome': doc.biome,
        'palette': tuple(encode_cell(value) for value in doc.blocks.palette),
        'chunks': tuple((key, ('constant', value) if isinstance(value, integer_types)
                         else ('IntegerBuffer-values', tuple(value)))
                        for key, value in sorted(doc.blocks.chunks.items()))})


class ConcretePaletteReceipt(object):
    def __init__(self, target):
        self.target = target
    def __getattr__(self, name):
        return getattr(self.target, name)
    def DeserializeBlockPalette(self, data):
        record = {'phase': 'Deserialize', 'fixture': getattr(sys, '_blueprint_qa_identity', None),
            'nonce': getattr(sys, '_blueprint_qa_nonce', None), 'palette_id': id(self.target),
            'editor_id': id(s.editor), 'document_id': id(s.editor.document),
            'native_input': concrete_wire(data), 'logical_document': concrete_document(s.editor.document)}
        sys._concrete_v3_observer['records'].append(record)
        result = self.target.DeserializeBlockPalette(data)
        record['result'] = result
        record['native_serialized_after'] = concrete_wire(self.target.SerializeBlockPalette())
        return result


class ConcreteBlockReceipt(object):
    def __init__(self, target):
        self.target = target
    def __getattr__(self, name):
        return getattr(self.target, name)
    def GetBlankBlockPalette(self):
        palette = self.target.GetBlankBlockPalette()
        return ConcretePaletteReceipt(palette) if palette is not None else None


class ConcreteGeometryReceipt(object):
    def __init__(self, target):
        self.target = target
    def __getattr__(self, name):
        return getattr(self.target, name)
    def CombineBlockPaletteToGeometry(self, palette, name, mode=0):
        target = palette.target if isinstance(palette, ConcretePaletteReceipt) else palette
        record = {'phase': 'Combine', 'fixture': getattr(sys, '_blueprint_qa_identity', None),
            'nonce': getattr(sys, '_blueprint_qa_nonce', None), 'palette_id': id(target),
            'editor_id': id(s.editor), 'document_id': id(s.editor.document),
            'name': name, 'mode': mode, 'native_serialized': concrete_wire(target.SerializeBlockPalette()),
            'logical_document': concrete_document(s.editor.document)}
        sys._concrete_v3_observer['records'].append(record)
        result = self.target.CombineBlockPaletteToGeometry(target, name, mode)
        record['result'] = result
        return result


class ConcreteFactoryReceipt(object):
    def __init__(self, target):
        self.target = target
    def __getattr__(self, name):
        return getattr(self.target, name)
    def CreateBlock(self, level):
        return ConcreteBlockReceipt(self.target.CreateBlock(level))
    def CreateBlockGeometry(self, level):
        return ConcreteGeometryReceipt(self.target.CreateBlockGeometry(level))


def concrete_install():
    assert not hasattr(sys, '_concrete_v3_observer')
    sys._concrete_v3_observer = {'factory': b.factory, 'records': []}
    b.factory = ConcreteFactoryReceipt(b.factory)


def concrete_retire():
    saved = sys._concrete_v3_observer
    assert isinstance(b.factory, ConcreteFactoryReceipt)
    records = list(saved['records'])
    b.factory = saved['factory']
    del sys._concrete_v3_observer
    return records
