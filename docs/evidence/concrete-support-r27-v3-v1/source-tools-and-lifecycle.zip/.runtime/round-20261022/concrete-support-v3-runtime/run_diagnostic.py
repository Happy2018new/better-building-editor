"""Run the unchanged OB-10 capture with exact ownership and restore-aware gates."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(ROOT / 'tools'), str(ROOT / '.agents/skills/pyreact-debugging/scripts')]
import lifecycle
import diagnose_concrete_color_r23 as diagnostic
from verify_debug_blueprints import CLIENT
from _session import load_session
from run_snow_holdout_r20 import signal_finally


class Gate:
    def __init__(self, folder, row, variant):
        self.folder, self.bound, self.variant = folder, row, variant
        self.restoring, self.previous = False, {}
        self.report = {'binding': {key: row[key] for key in (
            'id', 'owner', 'project', 'session_file', 'game_pid', 'game_identity', 'mcdk_pid', 'mcdk_identity')},
            'restore_mode': False, 'boundaries': [], 'RPCs': [], 'captures': []}

    def save(self):
        lifecycle.write(self.folder / 'gate.json', self.report)

    def begin_restore(self):
        self.restoring = True
        self.report['restore_mode'] = True
        self.save()

    def boundary(self, phase):
        current = load_session(self.bound['session_file'], self.bound['owner'], live=True)
        assert all(current[key] == self.bound[key] for key in (
            'id', 'project', 'game_pid', 'game_identity', 'mcdk_pid', 'mcdk_identity'))
        sample = lifecycle.snapshot(current)
        sample.update(phase=phase, restoring=self.restoring)
        self.report['boundaries'].append(sample)
        self.save()
        if self.restoring:
            return
        assert datetime.now(timezone.utc) < datetime(2026, 10, 21, 23, 30, tzinfo=timezone.utc)
        assert sample['memory']['commit_available_bytes'] >= 6 * 1024 ** 3, 'Available commit below 6 GiB'
        for name in ('game', 'mcdk'):
            value = sample[name]['handles']
            assert value is not None and value < 250000
            assert name not in self.previous or value - self.previous[name] < 10000
            self.previous[name] = value
        version = 'v3' if self.variant == 'candidate' else 'v1'
        watch = json.loads((HERE / ('launch-' + self.variant + '-' + version) / 'assert-watch/status.json').read_bytes())
        assert not watch['errors'] and not watch['other_assertions'], watch
        assert (datetime.now(timezone.utc) - datetime.fromisoformat(watch['checked_at'])).total_seconds() < 60


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=('base', 'candidate'), required=True)
    parser.add_argument('--material', choices=diagnostic.MATERIALS, default='white_concrete')
    parser.add_argument('--tag', default='white-product-v1')
    args = parser.parse_args()
    version = 'v3' if args.variant == 'candidate' else 'v1'
    launch = json.loads((HERE / ('launch-' + args.variant + '-' + version) / 'launch.json').read_bytes())
    row = load_session(launch['session_file'], launch['owner'], live=True)
    project = Path(launch['project'])
    lifecycle.runtime_matches(project, args.variant)
    capture = ROOT / '.runtime/worktree-archive-r7/p0-blueprint-qa-r3/files/.runtime/native_wgc/build/Release/native_wgc_capture.exe'
    capture_sha = 'cb9122a6713e9c627ee9ea7658e7610e7f72d7b451412b0c6331a5bb1fbcb5a8'
    assert hashlib.sha256(capture.read_bytes()).hexdigest() == capture_sha
    folder = HERE / (args.variant + '-' + args.tag)
    folder.mkdir(parents=True, exist_ok=False)
    gate = Gate(folder, row, args.variant)
    original = diagnostic.SignCheck
    original_main = diagnostic.main

    class GuardedCheck(original):
        def run(self, code):
            gate.boundary('rpc')
            number = len(gate.report['RPCs']) + 1
            raw = (CLIENT + code).encode('utf8')
            (folder / ('rpc-%04d.py' % number)).write_bytes(raw)
            item = {'number': number, 'sha256': hashlib.sha256(raw).hexdigest(),
                    'restoring': gate.restoring, 'dispatched': True}
            gate.report['RPCs'].append(item)
            gate.save()
            started = time.monotonic()
            try:
                result = super().run(code)
                lifecycle.write(folder / ('rpc-%04d-result.json' % number), result)
                item['acknowledged'] = True
                return result
            except Exception as error:
                item['error'] = '%s: %s' % (type(error).__name__, error)
                raise
            finally:
                item['seconds'] = time.monotonic() - started
                gate.save()

        def capture(self, label, tree=None):
            gate.boundary('capture:' + label)
            result = super().capture(label, tree)
            gate.report['captures'].append({'label': label, 'record': result})
            gate.save()
            return result

    diagnostic.SignCheck = GuardedCheck
    # Only signal restoration entry. The original cleanup body is unchanged.
    signal_finally(diagnostic, 'main', 'actions', gate)
    sys.argv = [str(Path(diagnostic.__file__)), '--output', str(folder / 'report.json'),
        '--project', str(project), '--session', row['session_file'], '--owner', row['owner'],
        '--native-capture-exe', str(capture),
        '--material', args.material, '--opacity', 'opaque', '--opacity', 'default']
    host_rows = []
    for module in tuple(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name:
            path = Path(name)
            if path.is_file() and path.resolve().is_relative_to(ROOT.resolve()):
                host_rows.append({'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    lifecycle.write(folder / 'host-inputs.json', {'files': host_rows, 'variant': args.variant,
                                                'capture_executable': str(capture), 'capture_sha256': capture_sha,
                                                'raw_main_sha256': hashlib.sha256(Path(diagnostic.__file__).read_bytes()).hexdigest()})
    try:
        return diagnostic.main()
    finally:
        diagnostic.SignCheck, diagnostic.main = original, original_main
        lifecycle.runtime_matches(project, args.variant)
        gate.report['runtime_unchanged'] = True
        gate.report['host_files_unchanged'] = all(hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'] for item in host_rows)
        gate.save()


if __name__ == '__main__':
    raise SystemExit(main())
