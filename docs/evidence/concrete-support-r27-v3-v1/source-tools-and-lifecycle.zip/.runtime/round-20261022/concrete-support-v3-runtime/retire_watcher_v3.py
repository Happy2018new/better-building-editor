import argparse
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / '.agents/skills/pyreact-debugging/scripts'))
from _session import process_identity, terminate_owned

parser = argparse.ArgumentParser()
parser.add_argument('--variant', choices=('base', 'candidate'), required=True)
args = parser.parse_args()
version = 'v3' if args.variant == 'candidate' else 'v1'
folder = HERE / ('launch-' + args.variant + '-' + version)
stop = json.loads((folder / 'stop.json').read_bytes())
assert not stop['still_live'] and stop['registry_state'] == 'stopped'
assert all(row[key]['actual_identity'] is None for row in stop['states'][-1:] for key in ('game', 'mcdk'))
owner = 'concrete-r27-support-' + args.variant + '-' + version
watch = json.loads((folder / 'watcher-start.json').read_bytes())
pid, identity = watch['watcher_pid'], watch['watcher_identity']
row = json.loads(subprocess.check_output(['powershell.exe', '-NoProfile', '-Command',
    'Get-CimInstance Win32_Process -Filter "ProcessId=%d" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress' % pid],
    encoding='utf8'))
assert row['ProcessId'] == pid and '--owner ' + owner in row['CommandLine']
assert 'watch_owned_disabled_skin_assert_r20.py' in row['CommandLine']
assert process_identity(pid) == identity
terminate_owned(pid, identity)
assert process_identity(pid) is None
report = {'retired': True, 'owner': owner, 'watcher_pid': pid,
          'watcher_identity': identity, 'expected_termination_code': 1,
          'exact_identity_absent': True, 'game_touched': False,
          'ordinary_game_stop_only': True}
(folder / 'watcher-retired.json').write_text(json.dumps(report, indent=2) + '\n', encoding='ascii')
print(json.dumps(report))
