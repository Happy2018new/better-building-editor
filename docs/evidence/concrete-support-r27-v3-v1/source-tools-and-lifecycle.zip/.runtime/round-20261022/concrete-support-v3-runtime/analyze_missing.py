"""Bind each actual missing submission to the frozen v3 CPU palette and source."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PROJECT=ROOT/'.runtime/projects/concrete-r27-support-candidate-v3'
sys.path.insert(0,str(PROJECT/'behavior_pack/modern_projection'))
from projection.cell import thaw, make_cell, AIR
from projection.model import Document
from projection.render_context import prepare_context_batches


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(wire):
    assert wire['codec']=='cell.freeze-repr-utf8-base64'
    raw=base64.b64decode(wire['base64'],validate=True)
    assert len(raw)==wire['bytes'] and hashlib.sha256(raw).hexdigest()==wire['host_sha256']
    assert b'IntegerBuffer object at' not in raw
    return thaw(ast.literal_eval(raw.decode('utf8')))


def normal(value):
    if isinstance(value,bytes):return value.decode('utf8')
    if isinstance(value,dict):return {normal(key):normal(child) for key,child in value.items()}
    if isinstance(value,list):return [normal(child) for child in value]
    if isinstance(value,tuple):return tuple(normal(child) for child in value)
    return value


def palette(value):
    value=normal(value)
    for layer in ('common','extra'):
        value[layer]={key:sorted(indices) for key,indices in value[layer].items()}
    return value


def main():
    source=PROJECT/'behavior_pack/modern_projection/projection/render_context.py'
    assert sha(source)=='966e2f35cba67d7810854fdcde7aed970dc2cea7c35ed1e26c497376ac17a1c0'
    folder=HERE/'candidate-missing-v1'
    result=json.loads((folder/'report.json').read_bytes())
    receipts=json.loads((folder/'complete-native-receipts.json').read_bytes())['records']
    assert result['completed'] and result['restored'] and not result['cleanup_errors']
    assert len(receipts)%2==0
    pairs=[]
    for i in range(0,len(receipts),2):
        before,combine=receipts[i:i+2]
        assert before['phase']=='Deserialize' and combine['phase']=='Combine'
        assert before['result'] and combine['result']
        assert all(before[key]==combine[key] for key in ('palette_id','fixture','nonce','editor_id','document_id'))
        assert before['native_serialized_after']==combine['native_serialized']
        assert before['logical_document']==combine['logical_document']
        for key in ('native_input','native_serialized_after','logical_document'):decode(before[key])
        decode(combine['native_serialized'])
        pairs.append((before,combine))
    summary={'schema':'concrete-v3-actual-missing-source-review','passed':False,
        'source_sha256':sha(source),'report_sha256':sha(folder/'report.json'),
        'receipts_sha256':sha(folder/'complete-native-receipts.json'),
        'actual_Deserialize_Combine_pairs':len(pairs),'typed_native_values_preserved':True,
        'IntegerBuffer_values_expanded':True,'host_only_SHA':True,'cases':[],
        'GPU_qualified':False,'manual_closures':0,
        'scope':'Controlled GetBlock air/occupied reads in a fresh private world; no real world placement. Default liquid_profile is None, so wet visual cases cover the actual native path only.'}
    for sequence in result['sequences']:
        item=sequence['input']
        actual=[pair for pair in pairs if pair[0]['fixture']==item['id']]
        assert len(actual)==len(sequence['stages'])==5,(item['id'],len(actual))
        doc=Document(tuple(item['size']),{tuple(pos):make_cell(tuple(front),tuple(back))
            for pos,front,back in item['cells']},item['id'])
        prior_source=None
        for stage,(before,combine) in zip(sequence['stages'],actual):
            state=stage['state']
            assert state['liquid_profile'] is None
            assert all(state[key] for key in ('source_current','cache_current','origin_current','idle','active','ready'))
            assert all(before[key]==state[key] for key in ('fixture','nonce','editor_id','document_id'))
            assert combine['name'] in [row[0] for row in state['parts']]
            occupied={tuple(pos) for pos in state['occupied']}
            expected=prepare_context_batches(doc,doc.palette_data(lambda pos:pos not in occupied))
            batches=expected['_context_batches']
            assert len(batches)==1 and batches[0][1]
            expected_palette=palette(batches[0][2])
            actual_palette=palette(decode(before['native_input']))
            assert actual_palette==expected_palette,(item['id'],stage['stage'])
            logical=decode(before['logical_document'])
            if prior_source is None:prior_source=logical
            assert logical==prior_source
            common=actual_palette['common']
            # Each remaining wire retains its own target center at its local
            # context slot; the full palette match also checks every neighbor.
            wire_indices=set(common[('minecraft:redstone_wire',0)])
            for x,z in ((0,1),(2,1),(1,0),(1,2)):
                center=(4+4*x,8,4+4*z)
                index=(center[1]*64+center[0])*64+center[2]
                assert index in wire_indices,('wire own target missing',item['id'],stage['stage'],x,z)
            summary['cases'].append({'kind':sequence['kind'],'stage':stage['stage'],
                'actual_input_matches_frozen_v3_palette':True,
                'native_serialized_after_equals_Combine_bytes':True,
                'same_complete_logical_source':True,'all_four_wire_own_targets_present':True,
                'native_input_sha256':before['native_input']['host_sha256'],
                'logical_document_sha256':before['logical_document']['host_sha256'],
                'reference_signal_pixels':stage['regions']['reference_corner']['actor_signal_pixels_above_12'],
                'target_front_signal_pixels':stage['regions']['target_front']['actor_signal_pixels_above_12'],
                'target_left_signal_pixels':stage['regions']['target_left']['actor_signal_pixels_above_12']})
    assert len(summary['cases'])==20
    summary['passed']=True
    destination=HERE/'actual-missing-source-review-v1.json'
    destination.write_bytes((json.dumps(summary,indent=2)+'\n').encode('ascii'))
    print(json.dumps({'passed':True,'cases':20,'pairs':len(pairs),'source_sha256':sha(source),'report_sha256':sha(destination)}))


if __name__=='__main__':main()
