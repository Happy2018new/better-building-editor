"""Run the original full diagnostic, adding delegating complete input receipts."""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(HERE), str(ROOT / 'tools'), str(ROOT / '.agents/skills/pyreact-debugging/scripts')]
import lifecycle
import run_diagnostic
import diagnose_concrete_color_r23 as diagnostic
from verify_debug_blueprints import Client, BlueprintCheck, CLIENT
from _session import load_session


def host_wires(value):
    if isinstance(value, dict):
        if value.get('codec') == 'cell.freeze-repr-utf8-base64':
            raw = base64.b64decode(value['base64'], validate=True)
            assert len(raw) == value['bytes'] and b'IntegerBuffer object at' not in raw
            value['host_sha256'] = hashlib.sha256(raw).hexdigest()
        else:
            for child in value.values():
                host_wires(child)
    elif isinstance(value, list):
        for child in value:
            host_wires(child)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--material', choices=diagnostic.MATERIALS, required=True)
    parser.add_argument('--tag', required=True)
    parser.add_argument('--alias', action='store_true')
    args = parser.parse_args()
    launch = json.loads((HERE / 'launch-candidate-v3/launch.json').read_bytes())
    row = load_session(launch['session_file'], launch['owner'], live=True)
    folder = HERE / ('candidate-' + args.tag)
    assert not folder.exists()
    observer = (HERE / 'observer_client_v2.py').read_bytes()
    assert b'hashlib' not in observer
    install = '''import types,base64
assert not hasattr(sys,'_concrete_v3_observer_module')
module=types.ModuleType('concrete_v3_readonly_observer')
module.__dict__.update(s=s,b=b)
eval(compile(base64.b64decode(%r),'<concrete-v3-observer>','exec'),module.__dict__)
sys._concrete_v3_observer_module=module
module.concrete_install()
''' % base64.b64encode(observer).decode('ascii')
    restore = '''
module=sys._concrete_v3_observer_module
records=module.concrete_retire()
sys._concrete_v3_last_receipts=records
del sys._concrete_v3_observer_module
_result=True
'''
    original_install, original_restore, original_fixture = diagnostic.INSTALL_PROBE, diagnostic.RESTORE, diagnostic.fixture
    diagnostic.INSTALL_PROBE = install + original_install
    diagnostic.RESTORE = original_restore + restore
    if args.alias:
        from projection.block_registry import canonical
        target = ('minecraft:' + args.material, 0)
        alias = next(('minecraft:concrete', aux) for aux in range(16)
                     if canonical(('minecraft:concrete', aux)) == target)
        def fixture(material, above=False):
            result = original_fixture(material, above)
            result['cells'] = [(position, alias if value == target else value)
                               for position, value in result['cells']]
            result['id'] += '.archived_alias'
            return result
        diagnostic.fixture = fixture
    inputs = {'observer_sha256': hashlib.sha256(observer).hexdigest(),
        'original_diagnostic_sha256': hashlib.sha256(Path(diagnostic.__file__).read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'alias_input': args.alias, 'instrumentation': 'Delegating Deserialize and Combine; complete actual inputs; host SHA only.'}
    (HERE / (args.tag + '-observer-binding.json')).write_bytes((json.dumps(inputs, indent=2) + '\n').encode('ascii'))
    sys.argv = [str(HERE / 'run_diagnostic.py'), '--variant', 'candidate', '--material', args.material, '--tag', args.tag]
    try:
        return run_diagnostic.main()
    finally:
        diagnostic.INSTALL_PROBE, diagnostic.RESTORE, diagnostic.fixture = original_install, original_restore, original_fixture
        with Client(timeout=30) as client:
            check = BlueprintCheck(client, HERE / 'unused.json', 30)
            receipts = check.run('''records=getattr(sys,'_concrete_v3_last_receipts',None)
if records is None and hasattr(sys,'_concrete_v3_observer_module'):
 module=sys._concrete_v3_observer_module
 if b.factory is module.sys._concrete_v3_observer['factory']:
  records=list(module.sys._concrete_v3_observer['records'])
 else:
  records=module.concrete_retire()
 del sys._concrete_v3_observer_module
if hasattr(sys,'_concrete_v3_last_receipts'):del sys._concrete_v3_last_receipts
_result=json.dumps({'records':records,'observer_removed':not hasattr(sys,'_concrete_v3_observer'),
 'module_removed':not hasattr(sys,'_concrete_v3_observer_module')})
''')
            host_wires(receipts)
            destination = folder / 'complete-native-receipts.json'
            destination.write_bytes((json.dumps(receipts, indent=2) + '\n').encode('ascii'))
            assert receipts['observer_removed'] and receipts['module_removed']
        lifecycle.runtime_matches(Path(row['project']), 'candidate')


if __name__ == '__main__':
    raise SystemExit(main())
