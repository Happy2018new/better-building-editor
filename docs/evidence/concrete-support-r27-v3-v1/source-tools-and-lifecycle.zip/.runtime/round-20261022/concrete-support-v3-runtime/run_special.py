"""Bounded editor and controlled occupancy visual evidence on one frozen source."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from PIL import Image, ImageChops, ImageStat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(HERE), str(ROOT / 'tools'), str(ROOT / '.agents/skills/pyreact-debugging/scripts')]
import lifecycle
from run_diagnostic import Gate
from run_full_observed import host_wires
import diagnose_concrete_color_r23 as full
from _session import load_session
from verify_debug_blueprints import Client, BlueprintCheck, CLIENT, INSTALL_PROBE, RESTORE, STATUS
from verify_debug_visuals import SAVE_VISUAL, PROJECTION_STATUS, camera_restore_code
from verify_sign_visuals import SignCheck, center_editor, capture_editor
from verify_shulker_orientations import viewport_crop, wait_camera_pose


LOAD_EDITOR = '''from modern_projection.projection.model import Document
from modern_projection.projection.cell import make_cell
item=%r
doc=Document(tuple(item['size']),name=item['id'])
for position,front,back in item['cells']:
 doc.blocks[tuple(position)]=make_cell(tuple(front),tuple(back))
sys._blueprint_qa_identity=item['id']
sys._blueprint_qa_nonce+=1
s._loaded(doc)
sys._blueprint_qa_expected={'metadata':{'name':doc.name,'size':doc.size,'blocks':len(doc.blocks)},
 'editor_id':id(s.editor),'document_id':id(doc),'previous_document_id':None}
s.grid=False
s.emit()
owner.open_workspace()
_result=json.dumps({'metadata':sys._blueprint_qa_expected['metadata'],'editor_id':id(s.editor),
 'document_id':id(doc),'logical_document':sys._concrete_v3_observer_module.concrete_document(doc)})
'''

LOAD_MISSING = '''from modern_projection.projection.model import Document,Editor
from modern_projection.projection.cell import make_cell
item=%r
b.stop_projection()
doc=Document(tuple(item['size']),name=item['id'])
for position,front,back in item['cells']:
 doc.blocks[tuple(position)]=make_cell(tuple(front),tuple(back))
s.editor=Editor(doc)
s.section=s.solo_layer=False
s.focused=None
s.name=doc.name
sys._blueprint_qa_identity=item['id']
sys._blueprint_qa_nonce+=1
sys._concrete_color_r23['document']=doc.blocks.copy()
s.origin=sys._concrete_color_r23['origin']
s.opacity=.45
s.projection_missing=True
s.projection_outline=False
sys._concrete_v3_occupancy['occupied']=()
b.project()
_result=json.dumps({'fixture':item['id'],'editor_id':id(s.editor),'document_id':id(doc),
 'nonce':sys._blueprint_qa_nonce,'document':sys._concrete_v3_observer_module.concrete_document(doc)})
'''

OCCUPANCY_INSTALL = '''assert not hasattr(sys,'_concrete_v3_occupancy')
sys._concrete_v3_occupancy={'factory':b.factory,'occupied':(),'reads':[],'origin':None,'size':(3,2,3)}
class ConcreteControlledInfo(object):
 def __init__(self,target):self.target=target
 def __getattr__(self,name):return getattr(self.target,name)
 def GetBlock(self,position):
  saved=sys._concrete_v3_occupancy
  origin=saved['origin']
  if origin is not None:
   local=tuple(position[i]-origin[i] for i in range(3))
   if all(0<=local[i]<saved['size'][i] for i in range(3)):
    occupied=local in saved['occupied']
    value=('minecraft:stone',0) if occupied else ('minecraft:air',0)
    saved['reads'].append((tuple(position),local,value))
    return value
  return self.target.GetBlock(position)
class ConcreteControlledFactory(object):
 def __init__(self,target):self.target=target
 def __getattr__(self,name):return getattr(self.target,name)
 def CreateBlockInfo(self,level):return ConcreteControlledInfo(self.target.CreateBlockInfo(level))
b.factory=ConcreteControlledFactory(b.factory)
_result=True
'''

OCCUPANCY_STATE = '''o=b.projection_occupancy
work=b.projection_work
doc=s.editor.document
model=b.projection_mesh[1] if b.projection_mesh else None
parts=b.context_models.get(model,())
_result=json.dumps({'fixture':sys._blueprint_qa_identity,'nonce':sys._blueprint_qa_nonce,
 'editor_id':id(s.editor),'document_id':id(doc),'serial':b.projection_serial,
 'active':bool(o is not None and o.active()),'failed':o.failed if o is not None else None,
 'ready':bool(work is not None and work.ready),'work_error':work.error if work is not None else None,
 'model':model,'occupancy_model':o.model if o is not None else None,
 'source_current':bool(o is not None and o.document.blocks==doc.blocks and work.document.blocks==doc.blocks),
 'cache_current':bool(o is not None and model==o.shader.names[o.shader.bank] and parts and
   all(name in o.shader.parts[o.shader.bank] for name,origin,context in parts)),
 'origin_current':bool(o is not None and tuple(o.origin)==tuple(s.origin) and b.projection_mesh is not None and
   tuple(b.projection_mesh[2])==tuple(s.origin)),
 'idle':bool(o is not None and o.build is None and o.pending_model is None and o.pending_pair is None and
   not o.changed and not o.after_build and not o.attaching),
 'occupied':list(sys._concrete_v3_occupancy['occupied']),
 'state':list(o.state) if o is not None else None,'rendered':list(o.rendered) if o is not None else None,
 'builds':o.builds if o is not None else None,'commits':o.commits if o is not None else None,
 'parts':parts,'actor':b.entity,'actor_position':b.factory.CreatePos(b.entity).GetFootPos() if b.entity else None,
 'camera':b.factory.CreateCamera(b.level).GetPosition(),'rotation':b.factory.CreateCamera(b.level).GetCameraRotation(),
 'player':b.player_position.GetFootPos(),'liquid_profile':getattr(s.liquid_profile,'identity',None)})
'''


def fixture(kind, above=True, wire=False):
    concrete = ('minecraft:concrete', 0) if kind == 'alias' else ('minecraft:white_concrete', 0)
    air, water = ('minecraft:air', 0), ('minecraft:water', 0)
    cells = [((x, 0, z), concrete, water if kind == 'wet_support' and (x,z)==(1,1) else air)
             for x in range(3) for z in range(3)]
    if above:
        cells.append(((1,1,1), ('minecraft:lever', 5), water if kind == 'wet_lever' else air))
    if wire:
        cells.extend(((x,1,z), ('minecraft:redstone_wire',0), air)
                     for x,z in ((0,1),(2,1),(1,0),(1,2)))
    return {'id':'concrete-v3.'+kind+('.above' if above else '.empty')+('.wire' if wire else ''),
            'size':(3,2,3),'cells':cells}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--path',choices=('editor','missing'),required=True)
    parser.add_argument('--tag',required=True)
    args=parser.parse_args()
    launch=json.loads((HERE/'launch-candidate-v3/launch.json').read_bytes())
    row=load_session(launch['session_file'],launch['owner'],live=True)
    project=Path(row['project'])
    lifecycle.runtime_matches(project,'candidate')
    os.environ.update(MCDEV_SESSION_FILE=row['session_file'],MCDEV_OWNER=row['owner'],
        MCDEV_MCP_URL=row['mcp_url'],MCDEV_GAME_PID=str(row['game_pid']),
        MCDEV_NATIVE_CAPTURE_EXE=str(ROOT/'.runtime/worktree-archive-r7/p0-blueprint-qa-r3/files/.runtime/native_wgc/build/Release/native_wgc_capture.exe'))
    folder=HERE/('candidate-'+args.tag)
    folder.mkdir(exist_ok=False)
    gate=Gate(folder,row,'candidate')
    observer=(HERE/'observer_client_v2.py').read_bytes()
    report={'path':args.path,'completed':False,'restored':False,'world_writes':False,
        'controlled_occupancy_only':args.path=='missing','real_world_placement_verified':False,
        'runtime_source_sha256':'966e2f35cba67d7810854fdcde7aed970dc2cea7c35ed1e26c497376ac17a1c0',
        'observer_sha256':hashlib.sha256(observer).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sequences':[],'cleanup_errors':[],'GPU_qualified':False,'manual_closures':0}

    def save():
        lifecycle.write(folder/'report.json',report)

    class Check(SignCheck):
        def run(self,code):
            gate.boundary('rpc')
            number=len(gate.report['RPCs'])+1
            raw=(CLIENT+code).encode('utf8')
            (folder/('rpc-%04d.py'%number)).write_bytes(raw)
            item={'number':number,'sha256':hashlib.sha256(raw).hexdigest(),'restoring':gate.restoring}
            gate.report['RPCs'].append(item);gate.save()
            try:
                result=super().run(code)
                host_wires(result)
                lifecycle.write(folder/('rpc-%04d-result.json'%number),result)
                item['acknowledged']=True
                return result
            except Exception as error:
                item['error']='%s: %s'%(type(error).__name__,error)
                raise
            finally:gate.save()
        def capture(self,label,tree=None):
            gate.boundary('capture:'+label)
            result=super().capture(label,tree)
            gate.report['captures'].append({'label':label,'record':result});gate.save()
            return result

    installed=visual=observed=controlled=False
    with Client(timeout=30) as client:
        check=Check(client,folder/'report.json',60,native_resolution=True,background_only=True,
            native_capture_helper=ROOT/'tools/capture_native_window.py')
        try:
            check.run(INSTALL_PROBE);installed=True
            check.run(SAVE_VISUAL);visual=True
            check.run("sys._concrete_v3_saved_grid=s.grid\n_result=True")
            install='''import types,base64
module=types.ModuleType('concrete_v3_readonly_observer')
module.__dict__.update(s=s,b=b)
eval(compile(base64.b64decode(%r),'<concrete-v3-observer>','exec'),module.__dict__)
sys._concrete_v3_observer_module=module
module.concrete_install()
_result=True
'''%base64.b64encode(observer).decode('ascii')
            check.run(install);observed=True
            report['setup']=check.run(full.BEGIN%__import__('projection.block_registry',fromlist=['fingerprint']).fingerprint())
            if args.path=='editor':
                fixed_crop=None
                baseline=None
                for stage in ('blank','empty','above','restored','alias'):
                    item=fixture('alias' if stage=='alias' else 'canonical',stage in ('above','alias'))
                    if stage=='blank':item['cells']=[];item['id']+='.blank'
                    loaded=check.run(LOAD_EDITOR%(item,))
                    check.editor_preview(stage,loaded['metadata'],loaded['editor_id'],loaded['document_id'])
                    camera=center_editor(check,(1,0,1),{'editor':(35.,35.,.45)})
                    shot=capture_editor(check,stage,camera)
                    crop=viewport_crop(check,shot)
                    if fixed_crop is None:fixed_crop=crop
                    assert crop==fixed_crop,'Editor viewport changed'
                    state=check.run(STATUS)
                    entry={'stage':stage,'input':item,'loaded':loaded,'state':state,'shot':shot,'crop':crop}
                    report['sequences'].append(entry)
                    if stage=='blank':baseline=shot
                    else:
                        with Image.open(shot['path']) as shown,Image.open(baseline['path']) as blank:
                            difference=ImageChops.difference(shown.convert('RGB').crop(crop),blank.convert('RGB').crop(crop))
                            maximum=ImageChops.lighter(ImageChops.lighter(difference.getchannel('R'),difference.getchannel('G')),difference.getchannel('B'))
                            entry['scene_pixels_above_12']=sum(maximum.histogram()[13:])
                        assert entry['scene_pixels_above_12']>=16,'Natural editor blank; stop this path'
                    save()
            else:
                if check.navigation()['open']:
                    check.run('navigator.pop()\n_result=True')
                    check.wait('workspace closed',lambda value:not value['open'] and not value['transition'],check.navigation)
                check.run(OCCUPANCY_INSTALL);controlled=True
                check.run("sys._concrete_v3_occupancy['origin']=tuple(sys._concrete_color_r23['origin'])\n_result=True")
                pose=check.run(full.CAMERA%(full.FOCUS,full.OFFSET));wait_camera_pose(check,pose)
                report['camera']=pose
                fixed_screen=None
                for kind in ('canonical','alias','wet_lever','wet_support'):
                    sequence={'kind':kind,'input':fixture(kind,wire=True),'stages':[]}
                    report['sequences'].append(sequence)
                    expected=check.run(LOAD_MISSING%(sequence['input'],))
                    check.wait('initial missing actor',full.ready,lambda:check.run(PROJECTION_STATUS))
                    for label,occupied in (('air',()),('support_occupied',((1,0,1),)),
                                            ('support_restored',()),('lever_occupied',((1,1,1),)),('lever_restored',())):
                        check.run("sys._concrete_v3_occupancy['occupied']=%r\n_result=True"%(occupied,))
                        def ready(state):
                            if state['work_error'] or state['failed']:raise RuntimeError(state)
                            exact=all(state['state'][(p[1]*3+p[0])*3+p[2]]==(2 if p in occupied else 1)
                                      for p,unused_front,unused_back in sequence['input']['cells'])
                            return bool(state['active'] and state['ready'] and state['idle'] and exact and
                                state['source_current'] and state['cache_current'] and state['origin_current'])
                        state=check.wait('controlled occupancy '+label,ready,lambda:check.run(OCCUPANCY_STATE))
                        assert all(state[key]==expected[key] for key in ('fixture','nonce','editor_id','document_id'))
                        time.sleep(.35)
                        screen=check.run(full.SCREEN%(full.ROI_POINTS,))
                        if fixed_screen is None:fixed_screen=screen
                        assert full.screen_matches(screen,fixed_screen),'Fixed world ROI changed'
                        shown=check.capture(kind+'_'+label+'_shown')
                        try:
                            check.run('assert b.factory.CreateActorRender(b.entity).SetNotRenderAtAll(True)\n_result=True')
                            time.sleep(.35)
                            hidden=check.capture(kind+'_'+label+'_hidden')
                        finally:check.run('assert b.factory.CreateActorRender(b.entity).SetNotRenderAtAll(False)\n_result=True')
                        after=check.run(OCCUPANCY_STATE)
                        for key in ('fixture','nonce','serial','model','state','rendered','source_current','cache_current','origin_current','camera','rotation','player'):
                            assert state[key]==after[key],('changed during shown/hidden',key)
                        with Image.open(shown['path']) as first,Image.open(hidden['path']) as second:
                            masks=full.masks_for_regions(first.size,fixed_screen)
                            metrics=full.region_metrics(first.convert('RGB'),second.convert('RGB'),masks)
                        assert metrics['reference_corner']['actor_signal_pixels_above_12']>=16,'Missing path has no actor signal'
                        sequence['stages'].append({'stage':label,'state':state,'screen':screen,'shown':shown,'hidden':hidden,'regions':metrics})
                        save()
                    check.run('b.stop_projection()\n_result=True')
            report['completed']=True
        except Exception as error:
            report['error']='%s: %s'%(type(error).__name__,error)
            raise
        finally:
            gate.begin_restore()
            actions=[('stop_projection','b.stop_projection()\n_result=True')]
            if controlled:actions.append(('controlled_factory',"b.factory=sys._concrete_v3_occupancy['factory']\ndel sys._concrete_v3_occupancy\n_result=True"))
            if observed:actions.append(('observer',"records=sys._concrete_v3_observer_module.concrete_retire()\ndel sys._concrete_v3_observer_module\n_result=json.dumps({'records':records})"))
            if visual:actions.extend((('camera',camera_restore_code(False)),('visual',"saved=sys._blueprint_visual_saved\ns.origin=saved['origin']\ns.opacity=saved['opacity']\ns.projection_missing=saved['missing']\ns.projection_outline=saved['outline']\ndel sys._blueprint_visual_saved\n_result=True")))
            if installed:actions.extend((('grid',"s.grid=sys._concrete_v3_saved_grid\ndel sys._concrete_v3_saved_grid\n_result=True"),('workspace_state','_result=sys._blueprint_qa_saved["workspace"]'),('document',RESTORE)))
            actions.append(('diagnostic_marker',"if hasattr(sys,'_concrete_color_r23'):del sys._concrete_color_r23\n_result=True"))
            was_open=False
            for label,code in actions:
                try:
                    result=check.run(code)
                    if label=='observer':lifecycle.write(folder/'complete-native-receipts.json',result)
                    elif label=='workspace_state':was_open=result
                except Exception as error:report['cleanup_errors'].append({'step':label,'error':'%s: %s'%(type(error).__name__,error)})
            try:
                check.run('owner.open_workspace()\n_result=True' if was_open else 'if navigator.top is not None:navigator.pop()\n_result=True')
            except Exception as error:report['cleanup_errors'].append({'step':'workspace','error':str(error)})
            report['restored']=installed and not report['cleanup_errors']
            lifecycle.runtime_matches(project,'candidate')
            report['runtime_unchanged']=True
            save();gate.save()
            if report['cleanup_errors']:raise RuntimeError(report['cleanup_errors'])
    print(json.dumps({'path':args.path,'completed':report['completed'],'restored':report['restored'],'sequences':len(report['sequences'])}))


if __name__=='__main__':
    raise SystemExit(main())
