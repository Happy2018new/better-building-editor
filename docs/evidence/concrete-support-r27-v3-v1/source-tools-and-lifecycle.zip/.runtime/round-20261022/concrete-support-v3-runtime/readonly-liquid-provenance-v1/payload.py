import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
from modern_projection.projection import liquid_render_target_data as target
from modern_projection.projection import liquid_product_qualification_data as qualification
from modern_projection.projection import liquid_resource_data as native_qualification
from modern_projection.projection import liquid_render_ownership
saved=sys._concrete_r27_independent
profile=s.liquid_profile
renderer=getattr(profile,'renderer_factory',None)
markers=[name for name in dir(sys) if name.startswith('_concrete_v3_')]
assert not markers, markers
assert profile is saved['profiles']['liquid_profile']
_result=json.dumps({'engine_version':b.engine_version,'api_engine_version':api.GetEngineVersion(),
 'target_engine_version':target.TARGET_ENGINE_VERSION,'profile_is_none':profile is None,
 'profile_id':id(profile),'profile_type_module':type(profile).__module__,
 'profile_type_name':type(profile).__name__,
 'supported_names':sorted(getattr(profile,'supported_names',())),
 'ownership_identity':liquid_render_ownership.identity(profile),
 'renderer_factory_module':getattr(renderer,'__module__',None),
 'renderer_factory_name':getattr(renderer,'__name__',None),
 'qualification':dict((name,getattr(qualification,name)) for name in dir(qualification)
   if name.isupper() and not isinstance(getattr(qualification,name),dict)),
 'native_PRODUCTION_QUALIFIED':native_qualification.PRODUCTION_QUALIFIED,
 'profile_same_as_before_all':profile is saved['profiles']['liquid_profile'],
 'custom_markers':markers,'independent_marker_present':hasattr(sys,'_concrete_r27_independent'),
 'production_profile_called':False,'profile_reassigned':False})
