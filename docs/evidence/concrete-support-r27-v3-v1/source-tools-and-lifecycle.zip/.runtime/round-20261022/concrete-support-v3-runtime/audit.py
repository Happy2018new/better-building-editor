"""Independent, read-only restoration audit around the unchanged OB-10 tool."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(HERE), str(ROOT / 'tools'),
                str(ROOT / '.agents/skills/pyreact-debugging/scripts')]
import lifecycle
from _session import load_session
from verify_debug_blueprints import Client, BlueprintCheck, CLIENT

FIELDS = ('page', 'name', 'view', 'focus_view', 'section', 'solo_layer',
          'focused', 'box_anchor', 'canvas_x', 'canvas_z', 'paste_origin',
          'paste_pinned', 'camera_pose', 'camera_yaw', 'camera_pitch', 'zoom',
          'camera_pan', 'camera_pivot', 'camera_depth', 'camera_depth_pose',
          'camera_focus_request', 'camera_reset_animated', 'progress',
          'direct_mode', 'origin', 'opacity', 'projection_missing', 'projection_outline')
PROFILES = ('liquid_profile', 'item_profile', 'native_render_profile',
            'cauldron_profile', 'spawner_profile', 'portal_profile', 'book_profile')
MARKERS = ('_blueprint_qa_saved', '_blueprint_qa_identity', '_blueprint_qa_nonce',
           '_blueprint_qa_expected', '_blueprint_qa_records',
           '_blueprint_visual_saved', '_concrete_color_r23')
BEGIN = '''from copy import deepcopy
assert not hasattr(sys, '_concrete_r27_independent')
assert not s.projection_active and not b.preparing_entity and not b.entity and not b.projection_entities
assert not s.busy and s.edit_job is None and s.io_job is None
assert not any(hasattr(sys, name) for name in %r)
sys._concrete_r27_independent = {
 'session':s, 'editor':s.editor, 'document':s.editor.document,
 'data':deepcopy(s.editor.document.to_data()), 'factory':b.factory,
 'fields':dict((key,deepcopy(getattr(s,key))) for key in %r),
 'profiles':dict((key,getattr(s,key)) for key in %r),
 'workspace':navigator.contains('modern_projection_workspace'),
 'foot':tuple(b.player_position.GetFootPos())}
_result=json.dumps({'saved':True,'editor_id':id(s.editor),'document_id':id(s.editor.document)})
''' % (MARKERS, FIELDS, PROFILES)
CHECK = '''saved=sys._concrete_r27_independent
changed=[]
if s is not saved['session']:changed.append('session')
if s.editor is not saved['editor']:changed.append('editor')
if s.editor.document is not saved['document']:changed.append('document')
if s.editor.document.to_data()!=saved['data']:changed.append('complete_document_data')
if b.factory is not saved['factory']:changed.append('factory')
changed.extend(key for key,value in saved['fields'].items() if getattr(s,key)!=value)
changed.extend(key for key,value in saved['profiles'].items() if getattr(s,key) is not value)
if navigator.contains('modern_projection_workspace')!=saved['workspace']:changed.append('workspace')
if tuple(b.player_position.GetFootPos())!=saved['foot']:changed.append('player_foot')
markers=[name for name in %r if hasattr(sys,name)]
actors=len(b.projection_entities)+int(bool(b.entity))
jobs=bool(s.busy or s.edit_job is not None or s.io_job is not None or b.preparing_entity)
ready=bool(s.ready and not s.preview_pending and not s.tiles.running and not s.tiles.dirty)
restored=not changed and not markers and not actors and not jobs and not s.projection_active and ready
_result=json.dumps({'restored':restored,'changed_keys':changed,'markers':markers,
 'actor_count':actors,'jobs':jobs,'preview_ready':ready,
 'editor_id':id(s.editor),'document_id':id(s.editor.document),
 'workspace':navigator.contains('modern_projection_workspace'),
 'profile_same_objects':not any(key in changed for key in %r)})
''' % (MARKERS, PROFILES)
RETIRE = CHECK + '''assert restored, changed
del sys._concrete_r27_independent
assert not hasattr(sys,'_concrete_r27_independent')
_result=json.dumps({'retired':True,'restored_before_retirement':True})
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=('begin', 'check', 'retire'))
    parser.add_argument('--variant', choices=('base', 'candidate'), required=True)
    parser.add_argument('--tag', required=True)
    args = parser.parse_args()
    version = 'v3' if args.variant == 'candidate' else 'v1'
    launch = json.loads((HERE / ('launch-' + args.variant + '-' + version) / 'launch.json').read_bytes())
    row = load_session(launch['session_file'], launch['owner'], live=True)
    lifecycle.runtime_matches(Path(row['project']), args.variant)
    folder = HERE / ('audit-' + args.variant + '-' + args.tag)
    folder.mkdir(exist_ok=False)
    code = {'begin': BEGIN, 'check': CHECK, 'retire': RETIRE}[args.operation]
    raw = (CLIENT + code).encode('utf8')
    (folder / 'payload.py').write_bytes(raw)
    lifecycle.write(folder / 'binding.json', {
        'operation': args.operation, 'payload_sha256': hashlib.sha256(raw).hexdigest(),
        'owner': row['owner'], 'project': row['project'],
        'game_pid': row['game_pid'], 'game_identity': row['game_identity'],
        'session_file': row['session_file']})
    os.environ.update(MCDEV_SESSION_FILE=row['session_file'], MCDEV_OWNER=row['owner'],
                      MCDEV_MCP_URL=row['mcp_url'], MCDEV_GAME_PID=str(row['game_pid']))
    results = []
    with Client(timeout=30) as client:
        check = BlueprintCheck(client, folder / 'unused.json', 30)
        deadline = time.monotonic() + 30
        while True:
            result = check.run(code)
            results.append(result)
            lifecycle.write(folder / 'result.json', {'samples': results})
            if args.operation != 'check' or result['restored']:
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('Independent restoration did not settle: ' + repr(result))
            time.sleep(.3)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
