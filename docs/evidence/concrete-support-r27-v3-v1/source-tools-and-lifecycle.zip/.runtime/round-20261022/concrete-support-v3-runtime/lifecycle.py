"""Bound one private cold test to its runtime bytes and exact process owners."""
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
TOOLS = ROOT / 'tools'
SCRIPTS = ROOT / '.agents/skills/pyreact-debugging/scripts'
sys.path[:0] = [str(TOOLS), str(SCRIPTS)]
from _session import process_identity, registry_dir, load_session
from census_intrinsic_glint_ui_r21 import commit_at_boundary


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n', encoding='ascii')


def handle_count(pid):
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessHandleCount.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        value = wintypes.DWORD()
        if not kernel.GetProcessHandleCount(handle, ctypes.byref(value)):
            raise ctypes.WinError(ctypes.get_last_error())
        return value.value
    finally:
        kernel.CloseHandle(handle)


def runtime_matches(project, variant):
    manifest = json.loads((HERE / 'project-manifest-v3.json').read_bytes())
    expected = {row['path']: row['sha256'] for row in manifest['source_files']}
    if variant == 'candidate':
        delta = manifest['only_candidate_delta']
        expected[delta['path']] = delta['sha256']
    actual = {path.relative_to(project).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
              for name in ('behavior_pack', 'resource_pack') for path in (project / name).rglob('*')
              if path.is_file() and path.suffix not in ('.pyc', '.pyo') and '__pycache__' not in path.parts}
    actual['.mcdev.json'] = hashlib.sha256((project / '.mcdev.json').read_bytes()).hexdigest()
    assert actual == expected, 'Cold runtime sources changed'
    return manifest


def snapshot(row):
    result = {'at': datetime.now().astimezone().isoformat(), 'memory': commit_at_boundary()}
    for name in ('game', 'mcdk'):
        pid, expected = row.get(name + '_pid'), row.get(name + '_identity')
        actual = process_identity(pid) if pid else None
        assert actual is None or actual == expected, 'Creation identity changed'
        result[name] = {'pid': pid, 'expected_identity': expected, 'actual_identity': actual,
                        'handles': handle_count(pid) if actual else None}
    return result


def stop(folder, owner):
    report = json.loads((folder / 'launch.json').read_bytes())
    session_file = Path(report['session_file'])
    row = json.loads(session_file.read_bytes())
    assert row['owner'] == owner
    assert Path(row['project']).resolve() == Path(report['project']).resolve()
    before = snapshot(row)
    command = [sys.executable, '-B', '-X', 'utf8', str(SCRIPTS / 'instances.py'),
               'stop', '--session', str(session_file), '--owner', owner]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=40)
    (folder / 'stop.stdout').write_bytes(result.stdout)
    (folder / 'stop.stderr').write_bytes(result.stderr)
    states = []
    until = time.monotonic() + 45
    while True:
        state = snapshot(row)
        states.append(state)
        if all(state[name]['actual_identity'] is None for name in ('game', 'mcdk')):
            break
        if time.monotonic() >= until:
            write(folder / 'stop.json', {'before': before, 'ordinary_returncode': result.returncode,
                                        'states': states, 'force_executed': False, 'still_live': True})
            raise RuntimeError('Exact process remains after ordinary stop; inspect before any next action')
        time.sleep(.5)
    # Registry bookkeeping only, after both exact processes are known absent.
    if json.loads(session_file.read_bytes()).get('state') != 'stopped':
        final = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=40)
        (folder / 'finalize.stdout').write_bytes(final.stdout)
        (folder / 'finalize.stderr').write_bytes(final.stderr)
    write(folder / 'stop.json', {'before': before, 'ordinary_returncode': result.returncode,
                                'states': states, 'force_executed': False, 'still_live': False,
                                'registry_state': json.loads(session_file.read_bytes())['state']})
    print(json.dumps({'stopped': True, 'ordinary_returncode': result.returncode, 'force_executed': False}))


def start(folder, project, owner, variant):
    folder.mkdir(parents=True, exist_ok=False)
    manifest = runtime_matches(project, variant)
    config = json.loads((project / '.mcdev.json').read_bytes())
    assert all(config[key] is False for key in ('auto_hot_reload_mods', 'auto_hot_reload_ui',
                                               'auto_hot_reload_shaders', 'auto_hot_reload_materials'))
    assert commit_at_boundary()['commit_available_bytes'] >= 6 * 1024 ** 3
    assert not any(json.loads(path.read_bytes()).get('owner') == owner for path in registry_dir().glob('*/session.json'))
    raw = subprocess.check_output(['powershell.exe', '-NoProfile', '-Command',
        '@(Get-Process -Name Minecraft.Windows -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id) | ConvertTo-Json -Compress'], text=True).strip()
    pids = json.loads(raw) if raw else []
    if isinstance(pids, int):
        pids = [pids]
    assert len([pid for pid in pids if process_identity(pid)]) < 5
    executable = ROOT / '.runtime/mcdk-retry-r11/build-ipc-framing-r11/tools/mcdk/mcdk.exe'
    guard = ROOT / 'docs/evidence/background-focus-r13-v1/inputs/native_focus_guard.dll'
    exe_sha = 'b8eb8959f97a4348006837bb7897d1e5cb957855d1746145974d8f37c00be9f9'
    guard_sha = '04b073e1aea6fe16a70573e64c6aac31940431409ac90c79f250e02f35a3ec93'
    assert hashlib.sha256(executable.read_bytes()).hexdigest() == exe_sha
    assert hashlib.sha256(guard.read_bytes()).hexdigest() == guard_sha
    watcher_folder = folder / 'assert-watch'
    watcher = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(TOOLS / 'watch_owned_disabled_skin_assert_r20.py'),
        '--owner', owner, '--until', '2026-10-22T07:45:00+08:00', '--output', str(watcher_folder), '--detach'],
        cwd=ROOT, capture_output=True, check=True)
    (folder / 'watcher-start.json').write_bytes(watcher.stdout)
    deadline = time.monotonic() + 15
    while not (watcher_folder / 'status.json').is_file():
        assert time.monotonic() < deadline
        time.sleep(.2)
    command = [sys.executable, '-B', '-X', 'utf8', str(SCRIPTS / 'instances.py'), 'start',
        '--project', str(project), '--owner', owner, '--name', owner, '--preset', 'ui', '--wait', '180',
        '--mcdk', str(executable), '--noactivate-dll', str(guard), '--noactivate-sha256', guard_sha,
        '--noactivate-mcdk-sha256', exe_sha]
    report = {'owner': owner, 'project': str(project), 'head': manifest['head'], 'variant': variant,
              'started_at': datetime.now().astimezone().isoformat(), 'command': command, 'samples': []}
    with (folder / 'stdout.json').open('wb') as out, (folder / 'stderr.txt').open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
            env=dict(os.environ, OPENBLAS_NUM_THREADS='1', MCDEV_ALLOW_USER_FOREGROUND='0'),
            creationflags=subprocess.CREATE_NO_WINDOW)
    report.update(launcher_pid=process.pid, launcher_identity=process_identity(process.pid))
    write(folder / 'launch.json', report)
    previous = {}
    observer = False
    while process.poll() is None:
        paths = []
        for path in registry_dir().glob('*/session.json'):
            try:
                data = json.loads(path.read_bytes())
            except (OSError, ValueError):
                continue
            if data.get('owner') == owner:
                paths.append((path, data))
        assert len(paths) <= 1
        if paths:
            path, row = paths[0]
            report['session_file'] = str(path)
            sample = snapshot(row)
            report['samples'].append(sample)
            write(folder / 'launch.json', report)
            if row.get('game_identity') and not observer:
                with (folder / 'observer.out').open('wb') as out, (folder / 'observer.err').open('wb') as err:
                    proc = subprocess.Popen([sys.executable, '-B', '-X', 'utf8',
                        str(ROOT / '.runtime/round-20261019/watch_exact_start.py'), '--session', str(path),
                        '--owner', owner, '--project', str(project), '--output', str(folder / 'exact-exit.json')],
                        cwd=ROOT, stdin=subprocess.DEVNULL, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
                report.update(observer_pid=proc.pid, observer_identity=process_identity(proc.pid))
                observer = True
            watch = json.loads((watcher_folder / 'status.json').read_bytes())
            invalid = sample['memory']['commit_available_bytes'] < 6 * 1024 ** 3 or watch['errors'] or watch['other_assertions']
            for name in ('game', 'mcdk'):
                value = sample[name]['handles']
                if value is not None:
                    invalid = invalid or value >= 250000 or name in previous and value - previous[name] >= 10000
                    previous[name] = value
            if invalid:
                report['guard_failure'] = {'sample': sample, 'watcher': watch}
                write(folder / 'launch.json', report)
                stop(folder, owner)
                raise RuntimeError('Cold start resource or assertion guard stopped the owned session')
        time.sleep(.75)
    report['launcher_returncode'] = process.returncode
    if process.returncode == 0:
        report['result'] = json.loads((folder / 'stdout.json').read_bytes())
    write(folder / 'launch.json', report)
    assert process.returncode == 0, report.get('session_file')
    runtime_matches(project, variant)
    print(json.dumps({'session_file': report['session_file'], 'owner': owner, 'ready': True}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=('start', 'stop', 'check'))
    parser.add_argument('--variant', choices=('base', 'candidate'), required=True)
    args = parser.parse_args()
    version = 'v3' if args.variant == 'candidate' else 'v1'
    owner = 'concrete-r27-support-' + args.variant + '-' + version
    project = ROOT / '.runtime/projects' / owner
    folder = HERE / ('launch-' + args.variant + '-' + version)
    if args.operation == 'start':
        start(folder, project, owner, args.variant)
    elif args.operation == 'stop':
        stop(folder, owner)
    else:
        report = json.loads((folder / 'launch.json').read_bytes())
        row = load_session(report['session_file'], owner, live=True)
        print(json.dumps(snapshot(row)))
