import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
saved=sys._books_wire_independent
changed=[]
if s is not saved['session']:changed.append('session')
if s.editor is not saved['editor']:changed.append('editor')
if s.editor.document is not saved['document']:changed.append('document')
if s.editor.document.to_data()!=saved['data']:changed.append('complete_document_data')
if b.factory is not saved['factory']:changed.append('factory')
changed.extend(key for key,value in saved['fields'].items() if getattr(s,key)!=value)
changed.extend(key for key,value in saved['profiles'].items() if getattr(s,key) is not value)
if navigator.contains('modern_projection_workspace')!=saved['workspace']:changed.append('workspace')
if tuple(b.player_position.GetFootPos())!=saved['foot']:changed.append('player_foot')
markers=[name for name in ('_blueprint_qa_saved', '_blueprint_qa_identity', '_blueprint_qa_nonce', '_blueprint_qa_expected', '_blueprint_qa_records', '_blueprint_visual_saved', '_concrete_color_r23') if hasattr(sys,name)]
actors=len(b.projection_entities)+int(bool(b.entity))
jobs=bool(s.busy or s.edit_job is not None or s.io_job is not None or b.preparing_entity)
ready=bool(s.ready and not s.preview_pending and not s.tiles.running and not s.tiles.dirty)
restored=not changed and not markers and not actors and not jobs and not s.projection_active and ready
_result=json.dumps({'restored':restored,'changed_keys':changed,'markers':markers,
 'actor_count':actors,'jobs':jobs,'preview_ready':ready,
 'editor_id':id(s.editor),'document_id':id(s.editor.document),
 'workspace':navigator.contains('modern_projection_workspace'),
 'profile_same_objects':not any(key in changed for key in ('liquid_profile', 'item_profile', 'native_render_profile', 'cauldron_profile', 'spawner_profile', 'portal_profile', 'book_profile'))})
result=json.loads(_result)
saved=sys._books_wire_independent
from modern_projection.projection import render_context as wire_context
result['helper_same_objects']=all(getattr(wire_context,key) is value for key,value in saved['helpers'].items())
result['geometry_same_function']=getattr(type(b).geometry,'im_func',type(b).geometry) is saved['geometry_function']
result['geometry_instance_override_same']=('geometry' in b.__dict__)==saved['geometry_instance_override']
result['context_writer_same_function']=getattr(wire_context._ContextWriter.put,'im_func',wire_context._ContextWriter.put) is saved['context_writer_function']
result['cache_same_objects']=all(getattr(b,key) is value for key,value in saved['cache_objects'].items())
result['cache_same_values']=all(getattr(b,key)==value for key,value in saved['cache_values'].items())
result['wire_markers']=[key for key in dir(sys) if key.startswith('_books_wire_') and key!='_books_wire_independent']
result['restored']=result['restored'] and all(result[key] for key in
 ('helper_same_objects','geometry_same_function','geometry_instance_override_same',
 'context_writer_same_function','cache_same_objects','cache_same_values')) and not result['wire_markers']
_result=json.dumps(result)
