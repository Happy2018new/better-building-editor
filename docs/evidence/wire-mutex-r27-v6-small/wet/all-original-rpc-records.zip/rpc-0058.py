import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
if hasattr(sys,'_books_wire_observer_module'):
 module=sys._books_wire_observer_module
 try:
  receipt=module.concrete_retire()
 finally:
  del sys._books_wire_observer_module
 receipt['module_removed']=not hasattr(sys,'_books_wire_observer_module')
 _result=json.dumps(receipt)
 assert len(_result.encode('ascii'))<=8192,'Final observer retirement payload exceeds eight KiB'
else:_result={'skipped_missing_marker':True}