import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
if hasattr(sys,'_blueprint_visual_saved'):
 saved=sys._blueprint_visual_saved
 cam=b.factory.CreateCamera(b.level)
 cam.ResetCameraPos()
 cam.UnDepartCamera()
 assert cam.SetCameraRotation(saved['camera_rot'])
 cam.LockModCameraPitch(saved['pitch_lock'])
 cam.LockModCameraYaw(saved['yaw_lock'])
 _result=True
else:_result={'skipped_missing_marker':True}