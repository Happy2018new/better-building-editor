import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
from modern_projection.projection.model import Document,Editor
from modern_projection.projection.cell import make_cell
item,opacity,phase_key={'id': 'wire-r27.negative-wet-wire', 'name': 'negative-wet-wire', 'size': (32, 32, 32), 'target': (3, 2, 3), 'origin_shift': (-2, -1, -2), 'cells': [((2, 1, 2), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((2, 1, 3), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((2, 1, 4), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((2, 2, 3), ('minecraft:redstone_wire', 15), ('minecraft:water', 0)), ((3, 1, 2), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((3, 1, 3), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((3, 1, 4), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((3, 2, 2), ('minecraft:redstone_wire', 15), ('minecraft:water', 0)), ((3, 2, 3), ('minecraft:redstone_wire', 15), ('minecraft:water', 0)), ((3, 2, 4), ('minecraft:redstone_wire', 15), ('minecraft:water', 0)), ((4, 1, 2), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((4, 1, 3), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((4, 1, 4), ('minecraft:white_concrete', 0), ('minecraft:air', 0)), ((4, 2, 3), ('minecraft:redstone_wire', 15), ('minecraft:water', 0))], 'wire_positions': [(3, 2, 3), (2, 2, 3), (4, 2, 3), (3, 2, 2), (3, 2, 4)], 'wire_bounds_points': [(3.02, 2.0, 3.02), (3.02, 2.0, 3.98), (3.02, 2.15, 3.02), (3.02, 2.15, 3.98), (3.98, 2.0, 3.02), (3.98, 2.0, 3.98), (3.98, 2.15, 3.02), (3.98, 2.15, 3.98), (2.02, 2.0, 3.02), (2.02, 2.0, 3.98), (2.02, 2.15, 3.02), (2.02, 2.15, 3.98), (2.98, 2.0, 3.02), (2.98, 2.0, 3.98), (2.98, 2.15, 3.02), (2.98, 2.15, 3.98), (4.02, 2.0, 3.02), (4.02, 2.0, 3.98), (4.02, 2.15, 3.02), (4.02, 2.15, 3.98), (4.98, 2.0, 3.02), (4.98, 2.0, 3.98), (4.98, 2.15, 3.02), (4.98, 2.15, 3.98), (3.02, 2.0, 2.02), (3.02, 2.0, 2.98), (3.02, 2.15, 2.02), (3.02, 2.15, 2.98), (3.98, 2.0, 2.02), (3.98, 2.0, 2.98), (3.98, 2.15, 2.02), (3.98, 2.15, 2.98), (3.02, 2.0, 4.02), (3.02, 2.0, 4.98), (3.02, 2.15, 4.02), (3.02, 2.15, 4.98), (3.98, 2.0, 4.02), (3.98, 2.0, 4.98), (3.98, 2.15, 4.02), (3.98, 2.15, 4.98)], 'focus': (3.5, 2.05, 3.5), 'poses': {'top': (0.0, 4.5, -5.5), 'grazing': (4.0, 1.25, -4.0)}, 'color_regions': {'target_corner': [(3.08, 2, 3.08), (3.3, 2, 3.08), (3.3, 2, 3.3), (3.08, 2, 3.3)], 'reference_corner': [(2.08, 2, 2.08), (2.3, 2, 2.08), (2.3, 2, 2.3), (2.08, 2, 2.3)]}, 'world_writes': False, 'negative': True},1.0,'wire-r27.negative-wet-wire:opaque:top:base'
b.stop_projection()
doc=Document(tuple(item['size']),name=item['id'])
for position,front,back in item['cells']:doc.blocks[tuple(position)]=make_cell(tuple(front),tuple(back))
s.editor=Editor(doc)
s.section=s.solo_layer=False
s.focused=None
s.name=doc.name
sys._blueprint_qa_identity=item['id']
sys._blueprint_qa_nonce+=1
sys._concrete_color_r23['document']=doc.blocks.copy()
s.origin=tuple(sys._concrete_color_r23['origin'][i]+item['origin_shift'][i] for i in range(3))
s.opacity=opacity
s.projection_missing=False
s.projection_outline=False
hook=sys._books_wire_hook
hook['phase_key']=phase_key
hook['module']._wire_phase_key=phase_key
hook['module']._wire_call_counts={}
hook['module']._wire_calls=[]
b.project()
work=b.projection_work
assert work is not None and work.document is not doc
assert work.document.blocks==doc.blocks
sys._books_wire_observer['retained_phase_objects'].append((s.editor,doc,work,work.document))
_result=json.dumps({'fixture':item['id'],'editor_id':id(s.editor),'document_id':id(doc),
 'nonce':sys._blueprint_qa_nonce,'logical_document':sys._books_wire_observer_module.concrete_document(doc),
 'origin':s.origin,'opacity':s.opacity,'mode':hook['mode'],'phase_key':phase_key,
 'work_id':id(work),'work_document_id':id(work.document),'serial':work.serial,
 'size':doc.size,'profile_id':id(s.liquid_profile)})
