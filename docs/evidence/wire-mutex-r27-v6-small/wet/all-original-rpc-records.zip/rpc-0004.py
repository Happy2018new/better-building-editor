import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
assert not s.busy and s.edit_job is None and s.io_job is None
assert not s.projection_active and not b.preparing_entity, 'Stop the previous projection first'
assert s.pending_confirm is None and s.pending_rename is None and not s.sharing.opened
assert not navigator.is_transitioning, 'Wait for navigation to settle'
assert navigator.top is None or navigator.top.key=='modern_projection_workspace'
assert not hasattr(sys,'_blueprint_qa_saved'), 'A previous blueprint probe needs cleanup'
fields=('page','name','view','focus_view','section','solo_layer','focused','box_anchor',
 'canvas_x','canvas_z','paste_origin','paste_pinned','camera_pose','camera_yaw',
 'camera_pitch','zoom','camera_pan','camera_pivot','camera_depth','camera_depth_pose',
 'camera_focus_request','camera_reset_animated','progress','direct_mode')
sys._blueprint_qa_saved={'editor':s.editor,'fields':dict((key,getattr(s,key)) for key in fields),
 'factory':b.factory,'workspace':navigator.contains('modern_projection_workspace')}
sys._blueprint_qa_records=[]
sys._blueprint_qa_identity=None
sys._blueprint_qa_nonce=0
sys._blueprint_qa_expected=None
class BlueprintNativeGeometryProbe(object):
 def __init__(self,target):self.target=target
 def __getattr__(self,name):return getattr(self.target,name)
 def CombineBlockPaletteToGeometry(self,palette,name,mode=0):
  data=palette.SerializeBlockPalette()
  record={'fixture':sys._blueprint_qa_identity,'name':name,'mode':mode,
   'nonce':sys._blueprint_qa_nonce,'editor_id':id(s.editor),
   'document_id':id(s.editor.document),
   'volume':data.get('volume'),'common_cells':sum(len(v) for v in data.get('common',{}).values()),
   'extra_cells':sum(len(v) for v in data.get('extra',{}).values()),
   'actor_cells':sum(len(v) for v in data.get('actor',{}).values()),
   'common_materials':len(data.get('common',{})),'extra_materials':len(data.get('extra',{})),
   'submitted_materials':[{'material':value,'indices':list(indices)}
    for value,indices in data.get('common',{}).items()],
   'frame_materials':[{'material':value,'indices':list(indices)}
    for value,indices in data.get('common',{}).items()
    if value[0] in ('minecraft:frame','minecraft:glow_frame') or
       value[0].startswith('modern_projection:preview_item_')],
   'actor_names':sorted(data.get('actor',{})),
   'states':len(data.get('states',{})),'extra_states':len(data.get('extraStates',{}))}
  started=time.time()
  try:
   result=self.target.CombineBlockPaletteToGeometry(palette,name,mode)
   record['result']=result
   return result
  except Exception as error:
   record['error']=str(error)
   raise
  finally:
   record['seconds']=time.time()-started
   sys._blueprint_qa_records.append(record)
class BlueprintGeometryFactoryProbe(object):
 def __init__(self,target):self.target=target
 def __getattr__(self,name):return getattr(self.target,name)
 def CreateBlockGeometry(self,level):
  return BlueprintNativeGeometryProbe(self.target.CreateBlockGeometry(level))
b.factory=BlueprintGeometryFactoryProbe(b.factory)
_result=True
