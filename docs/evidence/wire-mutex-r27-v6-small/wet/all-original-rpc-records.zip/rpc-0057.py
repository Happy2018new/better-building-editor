import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
if hasattr(sys,'_books_wire_hook'):
 from modern_projection.projection import render_context as wire_context
 saved=sys._books_wire_independent
 hook=sys._books_wire_hook
 for key,value in saved['helpers'].items():setattr(wire_context,key,value)
 assert all(getattr(wire_context,key) is value for key,value in saved['helpers'].items())
 assert dict((key,id(value)) for key,value in wire_context.__dict__.items()
  if key not in saved['helpers'])==hook['nonhelpers']
 del sys._books_wire_hook
 _result=json.dumps({'helpers_restored_original_objects':True,'other_context_objects_unchanged':True})
else:_result={'skipped_missing_marker':True}