import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
saved=sys._books_wire_independent
assert not s.projection_active and not b.entity and not b.projection_entities and not b.preparing_entity
assert s.ready and not s.preview_pending and not s.tiles.running and not s.tiles.dirty
for key,original in saved['cache_objects'].items():
 assert getattr(b,key) is original
 original.clear()
 original.update(saved['cache_values'][key])
_result=json.dumps({'python_cache_maps_restored':True,'native_resources_reclaimed':False,
 'note':'Unique diagnostic native geometry is reclaimed by the subsequent ordinary owned-process stop.'})
