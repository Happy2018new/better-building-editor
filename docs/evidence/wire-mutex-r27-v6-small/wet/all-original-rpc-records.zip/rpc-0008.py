import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
from modern_projection.projection import liquid_render_ownership
profile=s.liquid_profile
_result=json.dumps({'profile_is_none':profile is None,'profile_id':id(profile),
 'type_module':type(profile).__module__,'type_name':type(profile).__name__,
 'owned_names':liquid_render_ownership.identity(profile),
 'renderer_factory':getattr(getattr(profile,'renderer_factory',None),'__name__',None),
 'bridge_engine':b.engine_version,'api_engine':api.GetEngineVersion(),
 'same_as_initial':profile is sys._books_wire_independent['profiles']['liquid_profile'],
 'all_profile_ids':dict((key,id(getattr(s,key))) for key in sys._books_wire_independent['profiles']),
 'all_profiles_same_objects':all(getattr(s,key) is value for key,value in sys._books_wire_independent['profiles'].items())})
