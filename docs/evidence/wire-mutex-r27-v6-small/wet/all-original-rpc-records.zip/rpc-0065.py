import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
_result=json.dumps({'ready':s.ready and not s.preview_pending and not s.tiles.running and not s.tiles.dirty and not navigator.is_transitioning})