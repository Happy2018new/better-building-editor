import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
if hasattr(sys,'_blueprint_qa_saved'):
 saved=sys._blueprint_qa_saved
 b.factory=saved['factory']
 s.tiles.cancel()
 s.editor=saved['editor']
 for key,value in saved['fields'].items():setattr(s,key,value)
 s.pending_confirm=None
 s.model_revision=None
 s.camera_reset_revision+=1
 s.refresh_preview()
 s.emit()
 del sys._blueprint_qa_saved
 del sys._blueprint_qa_identity
 del sys._blueprint_qa_nonce
 del sys._blueprint_qa_expected
 del sys._blueprint_qa_records
 _result=True
else:_result={'skipped_missing_marker':True}