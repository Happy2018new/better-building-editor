import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
saved=sys._books_wire_observer
export=saved['phase_export']
expected={'phase_key': 'wire-r27.negative-wet-wire:opaque:top:base', 'bytes': 1224607, 'chunks': 5, 'crc32': '7c83f903', 'chunk_bytes': 262144, 'schema': 'wire-complete-phase-byte-export-v5-crc32'}
assert export['meta']==expected and export['next']==expected['chunks']
assert len(export['raw'])==expected['bytes'] and '%08x' % (zlib.crc32(export['raw']) & 0xffffffff)==expected['crc32']
del saved['phase_export']
_result=json.dumps({'released':True,'phase_key':expected['phase_key'],
 'bytes':expected['bytes'],'crc32':expected['crc32']})
