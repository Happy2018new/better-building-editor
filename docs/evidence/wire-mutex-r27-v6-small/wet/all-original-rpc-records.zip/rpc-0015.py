import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
work=b.projection_work
model=b.projection_mesh[1] if b.projection_mesh else None
parts=b.context_models.get(model,())
scales=[b.factory.CreateActorRender(b.entity).GetActorBlockGeometryScale(name) for name,origin,context in parts] if b.entity else []
_result=json.dumps({'active':s.projection_active,'actor':b.entity,
 'actors':len(b.projection_entities)+int(bool(b.entity)),
 'preparing':bool(b.preparing_entity),'ready':work is None or work.ready,
 'error':work.error if work is not None else None,'message':s.editor.message,
 'mesh':b.projection_mesh,'origin':s.origin,
 'scale':scales[0] if scales and all(scale is not None for scale in scales) else None,
 'part_scales':scales,'parts':parts,
 'camera':b.factory.CreateCamera(b.level).GetPosition(),
 'rotation':b.factory.CreateCamera(b.level).GetCameraRotation(),
 'player':b.player_position.GetFootPos()})
