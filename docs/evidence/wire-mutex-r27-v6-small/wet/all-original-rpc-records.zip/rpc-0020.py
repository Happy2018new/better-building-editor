import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
from modern_projection.projection.bridge import coordinate
work=b.projection_work
doc=s.editor.document
model=b.projection_mesh[1] if b.projection_mesh else None
parts=b.context_models.get(model,())
_result=json.dumps({'editor_id':id(s.editor),'document_id':id(doc),'fixture':sys._blueprint_qa_identity,
 'nonce':sys._blueprint_qa_nonce,'serial':b.projection_serial,
 'work_current':work is not None and work.serial==b.projection_serial and work.ready and
  work.model==model and work.document.size==doc.size and work.document.blocks==doc.blocks,
 'path':'incremental','cache_model':model,'model':model,
 'cache_current':model is not None and work is not None and model==work.shader.names[work.shader.bank]
  and bool(parts) and all(name in work.shader.parts[work.shader.bank] for name,origin,context in parts),
 'origin_current':b.projection_mesh is not None and
  tuple(b.projection_mesh[2])==tuple(coordinate(s.origin)) and work is not None and
  tuple(work.origin)==tuple(coordinate(s.origin)),
 'missing':s.projection_missing,'parts':parts})
