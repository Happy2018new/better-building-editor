import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
import zlib
checksum=zlib.crc32('123456789') & 0xffffffff
assert checksum==3421780262,'Game zlib.crc32 known-answer preflight failed'
_result=json.dumps({'schema':'wire-game-crc32-known-answer-v1','input':'123456789',
 'crc32':'%08x'%checksum,'engine':api.GetEngineVersion(),'game_SHA256_required':False})
