import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
_result=json.dumps({"transition":navigator.is_transitioning,"open":navigator.contains("modern_projection_workspace"),"top":navigator.top.key if navigator.top else None})