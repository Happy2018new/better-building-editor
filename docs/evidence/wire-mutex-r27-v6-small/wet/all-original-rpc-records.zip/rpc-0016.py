import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
assert not s.projection_active and not b.preparing_entity and not b.entity and not b.projection_entities
from modern_projection.projection import render_context as wire_context
saved=sys._books_wire_independent
hook=sys._books_wire_hook
mode='base'
assert mode in ('base','repeat','candidate','restored')
assert dict((key,id(value)) for key,value in wire_context.__dict__.items()
 if key not in saved['helpers'])==hook['nonhelpers']
for key,value in saved['helpers'].items():
 setattr(wire_context,key,getattr(hook['module'],key) if mode=='candidate' else value)
hook['mode']=mode
_result=json.dumps({'mode':mode,'helper_ids':dict((key,id(getattr(wire_context,key))) for key in saved['helpers']),
 'other_module_objects_unchanged':True})
