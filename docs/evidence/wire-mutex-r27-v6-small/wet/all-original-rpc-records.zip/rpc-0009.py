import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
assert not hasattr(sys,'_concrete_color_r23')
foot=b.player_origin()
sys._concrete_color_r23={'origin':tuple(int(foot[i]+(6,20,6)[i]) for i in range(3)),
 'player':b.player_position.GetFootPos(),'document':None}
from modern_projection.projection import block_registry as registry
assert registry.fingerprint()=='6b2d9e961e934a745f5ab30d697cf22fb463fd3792d371a6dd42cb4342062f01'
_result=json.dumps({'origin':sys._concrete_color_r23['origin'],
 'player':sys._concrete_color_r23['player'],'runtime':api.GetMinecraftVersion(),
 'registry_version':registry.source_version(),'palette_sha256':registry.fingerprint(),
 'world_writes':False})
