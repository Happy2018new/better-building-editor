import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
from copy import deepcopy
assert not hasattr(sys, '_books_wire_independent')
assert not s.projection_active and not b.preparing_entity and not b.entity and not b.projection_entities
assert not s.busy and s.edit_job is None and s.io_job is None
assert not any(hasattr(sys, name) for name in ('_blueprint_qa_saved', '_blueprint_qa_identity', '_blueprint_qa_nonce', '_blueprint_qa_expected', '_blueprint_qa_records', '_blueprint_visual_saved', '_concrete_color_r23'))
sys._books_wire_independent = {
 'session':s, 'editor':s.editor, 'document':s.editor.document,
 'data':deepcopy(s.editor.document.to_data()), 'factory':b.factory,
 'fields':dict((key,deepcopy(getattr(s,key))) for key in ('page', 'name', 'view', 'focus_view', 'section', 'solo_layer', 'focused', 'box_anchor', 'canvas_x', 'canvas_z', 'paste_origin', 'paste_pinned', 'camera_pose', 'camera_yaw', 'camera_pitch', 'zoom', 'camera_pan', 'camera_pivot', 'camera_depth', 'camera_depth_pose', 'camera_focus_request', 'camera_reset_animated', 'progress', 'direct_mode', 'origin', 'opacity', 'projection_missing', 'projection_outline')),
 'profiles':dict((key,getattr(s,key)) for key in ('liquid_profile', 'item_profile', 'native_render_profile', 'cauldron_profile', 'spawner_profile', 'portal_profile', 'book_profile')),
 'workspace':navigator.contains('modern_projection_workspace'),
 'foot':tuple(b.player_position.GetFootPos())}
_result=json.dumps({'saved':True,'editor_id':id(s.editor),'document_id':id(s.editor.document)})
from modern_projection.projection import render_context as wire_context
saved=sys._books_wire_independent
saved['helpers']=dict((key,getattr(wire_context,key)) for key in
 ('_mark_floor_support','_mark_palette_floor_support','_hidden_neighbor'))
saved['geometry_function']=getattr(type(b).geometry,'im_func',type(b).geometry)
saved['context_writer_function']=getattr(wire_context._ContextWriter.put,'im_func',wire_context._ContextWriter.put)
saved['cache_objects']=dict((key,getattr(b,key)) for key in ('models','context_models','model_layouts'))
saved['cache_values']=dict((key,dict(value)) for key,value in saved['cache_objects'].items())
assert not any('modern_projection_buffer_' in str(key) for key in b.context_models), 'Fresh instance required: native resource names already used'
saved['geometry_instance_override']='geometry' in b.__dict__
_result=json.dumps({'saved':True,'helper_ids':dict((key,id(value)) for key,value in saved['helpers'].items()),
 'geometry_function_id':id(saved['geometry_function']),
 'cache_ids':dict((key,id(value)) for key,value in saved['cache_objects'].items()),
 'cache_sizes':dict((key,len(value)) for key,value in saved['cache_objects'].items())})
