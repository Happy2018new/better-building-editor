import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
cam=b.factory.CreateCamera(b.level)
sys._blueprint_visual_saved={'origin':s.origin,'opacity':s.opacity,
 'missing':s.projection_missing,'outline':s.projection_outline,
 'camera_pos':cam.GetPosition(),'camera_rot':cam.GetCameraRotation(),
 'pitch_lock':cam.IsModCameraLockPitch(),'yaw_lock':cam.IsModCameraLockYaw(),
 'player':b.player_position.GetFootPos()}
_result=True
