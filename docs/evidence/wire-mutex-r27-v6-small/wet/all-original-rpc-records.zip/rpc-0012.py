import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
cam=b.factory.CreateCamera(b.level)
_result=json.dumps({"position":cam.GetPosition(),"rotation":cam.GetCameraRotation()})