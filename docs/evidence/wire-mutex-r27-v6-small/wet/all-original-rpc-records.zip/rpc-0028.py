import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
_result=json.dumps({'camera':b.factory.CreateCamera(b.level).GetPosition(),
 'rotation':b.factory.CreateCamera(b.level).GetCameraRotation(),
 'player':b.player_position.GetFootPos(),'actor':b.entity,'serial':b.projection_serial,
 'origin':s.origin,'opacity':s.opacity,'missing':s.projection_missing,
 'document_preserved':s.editor.document.blocks==sys._concrete_color_r23['document'],
 'snapshot_preserved':b.projection_work is not None and
  b.projection_work.document.blocks==sys._concrete_color_r23['document'],
 'actor_position':b.factory.CreatePos(b.entity).GetFootPos() if b.entity else None})
