import json,sys,time
import mod.client.extraClientApi as api
from modern_projection.pyreact import navigator
owner=api.GetSystem('ModernProjection','ModernProjectionClientSystem')
assert owner is not None and owner.session is not None, 'Workspace is not initialized'
s=owner.session
b=owner.bridge
if hasattr(sys,'_blueprint_visual_saved'):
 saved=sys._blueprint_visual_saved
 s.origin=saved['origin']
 s.opacity=saved['opacity']
 s.projection_missing=saved['missing']
 s.projection_outline=saved['outline']
 del sys._blueprint_visual_saved
 _result=True
else:_result={'skipped_missing_marker':True}