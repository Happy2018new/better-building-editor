"""Retain owner-bound item-plane captures with sanitized replayable reports."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n', encoding='ascii')


def sanitize(value, secret):
    if isinstance(value, dict):
        return {key: sanitize(data, secret) for key, data in value.items() if key.lower() != 'token'}
    if isinstance(value, list):
        return [sanitize(data, secret) for data in value]
    if secret and isinstance(value, str):
        return value.replace(secret, '[REDACTED]')
    return value


def retain_captures(value, destination, secret, retained):
    if isinstance(value, dict):
        path = value.get('path')
        if isinstance(path, str) and path.lower().endswith('.png') and 'sha256' in value:
            source = Path(value['path'])
            assert digest(source) == value['sha256'], 'Changed capture: ' + str(source)
            target = destination / 'captures' / source.name
            if source in retained:
                assert target == retained[source]
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                receipt = sanitize(json.loads(source.with_suffix('.capture.json').read_bytes()), secret)
                receipt['path'] = str(target.resolve())
                save(target.with_suffix('.capture.json'), receipt)
                retained[source] = target
            value['path'] = str(target.resolve())
        for child in value.values():
            retain_captures(child, destination, secret, retained)
    elif isinstance(value, list):
        for child in value:
            retain_captures(child, destination, secret, retained)


def pack(captures, output):
    output.mkdir(parents=True, exist_ok=False)
    summary = {'schema': 1, 'production_qualified': False, 'captures': {},
        'scope': 'Frozen flat-item front-plane candidate; individual poses retain independent gates',
        'owner_boundary': {'frame_layout_0': 'Uses the mesh front plane',
            'shelf_layout_1_3': 'Existing shader overrides point.z with 0.3125',
            'campfire_layout_4_7': 'Existing shader overrides point.z with 0.05',
            'lectern': 'No flat-item plan; handled by the independently gated book owner'}}
    for specification in captures:
        label, path = specification.split('=', 1)
        if not label or any(character not in 'abcdefghijklmnopqrstuvwxyz0123456789-_' for character in label):
            raise ValueError('Capture labels must be simple directory names')
        source = Path(path)
        raw = json.loads(source.read_bytes())
        if not raw['completed'] or raw['cleanup_errors'] or not raw['source_unchanged']:
            raise ValueError('Only completed, restored, stable-source reports can enter this package')
        destination = output / label
        report = sanitize(copy.deepcopy(raw), raw['session'].get('token'))
        retained = {}
        retain_captures(report, destination, raw['session'].get('token'), retained)
        report_path = destination / 'report.json'
        save(report_path, report)
        command = [sys.executable, '-X', 'utf8', str(ROOT / 'tools/analyze_visible_items_r16.py'),
                   str(report_path), str(destination / 'analysis'), '--world-plain-only']
        result = subprocess.run(command, cwd=str(ROOT), check=True, capture_output=True,
                                text=True, encoding='utf8')
        (destination / 'analysis.stdout.txt').write_text(result.stdout, encoding='utf8')
        analysis = json.loads((destination / 'analysis/analysis.json').read_bytes())
        if not analysis['evidence_valid']:
            raise ValueError('Rebased evidence failed validity: ' + label)
        summary['captures'][label] = {'original_report_sha256': digest(source),
            'retained_report_sha256': digest(report_path), 'retained_images': len(retained),
            'source_snapshot_sha256': raw['launch_sources_sha256'],
            'resource_contract': raw['resource_contract'],
            'view_configuration': raw['view_configuration'],
            'requested_cases': analysis['requested_cases'],
            'completed_cases': analysis['completed_cases'],
            'all_bodies_passed': analysis['all_bodies_passed'],
            'all_native_bodies_passed': analysis['all_native_bodies_passed'],
            'all_native_edges_passed': analysis['all_native_edges_passed'],
            'static_pose_accepted': analysis['static_pose_accepted']}
    for relative in ('tools/generate_item_icon_catalog.py', 'tools/analyze_visible_items_r16.py',
        'tools/analyze_item_sprite_sides.py', 'tools/item_sprite_edge_pixels.py',
        'tools/data/item_icon_catalog_nemc_3.10.0.420447.json',
        'behavior_pack/modern_projection/projection/item_icon_data.py',
        'resource_pack/models/modern_projection/item_icons/cf75a6e96b2d3e06_mesh.json',
        'resource_pack/textures/models/modern_projection/item_icons/cf75a6e96b2d3e06.png',
        'resource_pack/shaders/glsl/modern_projection_item_icon.vertex',
        'resource_pack/shaders/glsl/modern_projection_item_icon_world.vertex',
        'resource_pack/shaders/glsl/modern_projection_item_icon.fragment'):
        target = output / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
    save(output / 'summary.json', summary)
    files = {path.relative_to(output).as_posix(): {'sha256': digest(path), 'bytes': path.stat().st_size}
             for path in sorted(output.rglob('*')) if path.is_file()}
    save(output / 'manifest.json', {'schema': 1, 'production_qualified': False, 'files': files})
    print(json.dumps({'files': len(files), 'bytes': sum(row['bytes'] for row in files.values()),
        'poses': sum(len(row['completed_cases']) for row in summary['captures'].values()),
        'all_static_poses_accepted': all(row['static_pose_accepted'] for row in summary['captures'].values()),
        'production_qualified': False}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', action='append', required=True, help='label=absolute-report-path')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    pack(args.capture, args.output.resolve())
