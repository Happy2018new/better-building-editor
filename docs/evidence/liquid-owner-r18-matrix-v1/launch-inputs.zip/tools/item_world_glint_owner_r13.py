"""Supervise one world capability test; no production projection is invoked."""
from pathlib import Path

from isolated_diagnostic_module import load
import execute_item_world_glint_r13 as runtime
import prepare_item_world_glint_r13 as candidate

previous=load('item_server_skeleton_owner_r13')

shared=previous.shared
shared.runtime=runtime
shared.ENTRYPOINT=Path(__file__).resolve()
shared.PREFIX='item-world-glint-r13-v3'
old_contract=shared.owner_contract


def contract():
    value=old_contract()
    value.pop('resource_or_shader_or_player_or_world_or_inventory_mutation',None)
    value.update(wgc_dispatches=len(candidate.STATES)*2,native_world_only=True,projection_tested=False,
                 diagnostic_server_world_entity_created=True,resources_or_shaders_mutated_during_probe=False,
                 player_or_inventory_or_existing_entities_mutated=False,explicit_server_absence_readback=True,
                 ui_positive_control_before_world_item_binding=True,item_scale=candidate.ITEM_SCALE)
    return value


shared.owner_contract=contract


if __name__=='__main__':
    previous.route.configure()
    candidate.EXACT_PLAN_SHA256=shared.PLAN_HASH
    raise SystemExit(shared.main())
