"""Bind T07 offline results to source bytes; keep earlier diagnostic failures explicit."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'behavior_pack/modern_projection'))
from projection.debug_blueprints import build as build_source, entries
from projection.debug_transform_acceptance import CASES, PREFIX, build
from projection.cell import foreground, background, actor_data
from projection.nbt_spatial import root_payload
from projection.visible_actor import entity_nbt
from projection import block_registry as registry

sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda rel: json.loads((HERE / rel).read_bytes())
assert read('py2.json') == read('py3.json')
assert read('test-final.json')['final_poll']['exit_code'] == 0
review = json.loads(read('mcp-review.json')['content'][0]['text'])
assert review['files_scanned'] == 1 and review['findings_total'] == 0
assert PREFIX + 't07' in [row[0] for row in entries()]
document = build(PREFIX + 't07')
rows = []
sources = {identity: build_source(identity) for identity in
           ('test.layers.water', 'test.layers.snow', 'test.entities.signs')}
for label, identity, source, target in CASES[PREFIX + 't07']['subjects']:
    value = sources[identity].get(source)
    actual = document.get(target)
    assert foreground(value) == foreground(actual) and background(value) == background(actual)
    root = root_payload(entity_nbt(actor_data(actual)))
    rows.append({'label': label, 'source_fixture': identity, 'source': source, 'target': target,
                 'foreground': foreground(actual), 'background': background(actual),
                 'foreground_states': registry.states(foreground(actual)),
                 'background_states': registry.states(background(actual)), 'tagged_root': root})
production = ['behavior_pack/modern_projection/projection/debug_transform_acceptance.py',
              'tests/test_transform_acceptance.py']
dependencies = ['debug_blueprints.py', 'debug_snow_blueprints.py', 'debug_sign_blueprints.py',
                'native_sign_data.py', 'cell.py', 'model.py', 'storage.py', 'state_transform.py',
                'block_groups.py', 'nbt_spatial.py', 'visible_actor.py', 'block_registry.py']
paths = production + ['behavior_pack/modern_projection/projection/' + name for name in dependencies]
report = {'created_at': datetime.now(timezone.utc).isoformat(), 'scope': 'Offline T07 data and transactions only',
          'manual_issues_closed': 0, 'editor_or_projection_runtime_executed': False,
          'snow_or_water_render_qualification_changed': False,
          'fixture': PREFIX + 't07', 'document_size': document.size, 'cells': len(document.blocks),
          'selection': CASES[PREFIX + 't07']['selection'], 'source_samples': rows,
          'registry_version': registry.source_version(), 'registry_fingerprint': registry.fingerprint(),
          'head_at_finalization': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'worktree_source_sha256': {rel: sha((ROOT / rel).read_bytes()) for rel in paths},
          'source_binding_scope': 'Two changed files and data dependencies observed at finalization; worktree has not been committed or used for a cold MC run.',
          'focused_tests_passed': 19, 'mcp_review_files_scanned': 1, 'mcp_review_findings': 0,
          'true_python2_compile_passed': True, 'dual_host_json_equal': True,
          'dual_host_raw_bytes_equal': (HERE / 'py2.json').read_bytes() == (HERE / 'py3.json').read_bytes(),
          'dual_host_raw_sha256': {name: sha((HERE / name).read_bytes()) for name in ('py2.json', 'py3.json')},
          'earlier_diagnostics': [
              {'stage': 'first focused test run', 'returncode': 1,
               'test': 'test_candidates_are_independent_legal_native_documents_with_palette_preflight',
               'error_excerpt': 'AssertionError: Tuples differ: (32, 32, 10) != (32, 32, 266)',
               'resolution': 'Existing covered-plant overlay band extends render volume by 256. T07 now explicitly expects (32,32,266), logical document unchanged. No renderer edit.'},
              {'stage': 'first Python2 compile command', 'returncode': 1,
               'error_excerpt': 'SyntaxError: encoding declaration in Unicode string',
               'resolution': 'Compile original UTF8 source bytes; succeeded, no source edit needed.'},
              {'stage': 'review scope selection', 'result': 'Several initial invocations scanned zero files; these are not qualified reviews.',
               'resolution': 'Final scope modern_projection/projection/debug_transform_acceptance scanned one file, no findings.'}],
          'original_r27_cold_source_and_evidence_unchanged': True}
(HERE / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
out = ROOT / 'docs/evidence/transform-t07-offline-r27-v1'
assert not out.exists()
(out / 'records').mkdir(parents=True)
index = {'schema': 1, 'fixture': report['fixture'], 'manual_issues_closed': 0,
         'per_file_limit_bytes': 300000, 'records': []}
for source in sorted(HERE.glob('*')):
    if source.suffix not in ('.py', '.json'):
        continue
    raw = source.read_bytes()
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    assert gzip.decompress(packed) == raw and len(packed) < 300000
    target = out / 'records' / (source.name + '.gz')
    target.write_bytes(packed)
    index['records'].append({'source': source.relative_to(ROOT).as_posix(), 'raw_sha256': sha(raw),
                             'raw_bytes': len(raw), 'archived': target.relative_to(out).as_posix(),
                             'archive_sha256': sha(packed), 'archive_bytes': len(packed),
                             'archive_decoded_sha256': sha(raw), 'archive_decodes_to_original_raw': True})
for rel in production:
    raw = (ROOT / rel).read_bytes()
    target = out / 'records' / (Path(rel).name + '.gz')
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    target.write_bytes(packed)
    index['records'].append({'source': rel, 'raw_sha256': sha(raw), 'raw_bytes': len(raw),
                             'archived': target.relative_to(out).as_posix(), 'archive_sha256': sha(packed),
                             'archive_bytes': len(packed), 'archive_decoded_sha256': sha(raw),
                             'archive_decodes_to_original_raw': True})
(out / 'summary.json').write_bytes((HERE / 'summary.json').read_bytes())
index['summary_sha256'] = sha((out / 'summary.json').read_bytes())
(out / 'index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
files = [x for x in out.rglob('*') if x.is_file()]
assert all(x.stat().st_size < 300000 for x in files)
print(json.dumps({'output': str(out), 'dual_host_json_equal': report['dual_host_json_equal'],
                  'raw_bytes_equal': report['dual_host_raw_bytes_equal'],
                  'records': len(index['records']), 'largest_file_bytes': max(x.stat().st_size for x in files),
                  'total_bytes': sum(x.stat().st_size for x in files),
                  'index_sha256': sha((out / 'index.json').read_bytes())}))
